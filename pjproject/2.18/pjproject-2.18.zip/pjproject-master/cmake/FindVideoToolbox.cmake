# VideoToolbox H.264 codec backend (macOS and iOS)
#
# Defines the imported target `VideoToolbox::VideoToolbox` when every framework is found.
# The framework list follows the one the autotools build links (aconfigure.ac).

set(_videotoolbox_frameworks VideoToolbox CoreMedia CoreVideo Foundation)
if(CMAKE_SYSTEM_NAME STREQUAL "Darwin")
  list(APPEND _videotoolbox_frameworks AppKit)
else()
  list(APPEND _videotoolbox_frameworks UIKit)
endif()

set(_videotoolbox_libs)
foreach(_videotoolbox_lib IN LISTS _videotoolbox_frameworks)
  string(TOUPPER "VideoToolbox_LIBRARY_${_videotoolbox_lib}" _videotoolbox_lib_var)
  list(APPEND _videotoolbox_required_vars ${_videotoolbox_lib_var})

  find_library(${_videotoolbox_lib_var} "${_videotoolbox_lib}")
  mark_as_advanced(${_videotoolbox_lib_var})
  if(${_videotoolbox_lib_var})
    list(APPEND _videotoolbox_libs "${${_videotoolbox_lib_var}}")
  endif()
endforeach()
unset(_videotoolbox_lib)
unset(_videotoolbox_lib_var)
unset(_videotoolbox_frameworks)

include(FindPackageHandleStandardArgs)
find_package_handle_standard_args(VideoToolbox
  REQUIRED_VARS
    ${_videotoolbox_required_vars}
)

if(VideoToolbox_FOUND)
  set(VideoToolbox_LIBRARIES ${_videotoolbox_libs})

  # IMPORTED, so the target never has to belong to an export set when a
  # library that links it is installed.
  if(NOT TARGET VideoToolbox::VideoToolbox)
    add_library(VideoToolbox::VideoToolbox INTERFACE IMPORTED GLOBAL)
    set_target_properties(VideoToolbox::VideoToolbox PROPERTIES
      INTERFACE_LINK_LIBRARIES "${VideoToolbox_LIBRARIES}"
    )
  endif()
endif()

unset(_videotoolbox_libs)
unset(_videotoolbox_required_vars)
