/* 
 * Copyright (C) 2008-2011 Teluu Inc. (http://www.teluu.com)
 * Copyright (C) 2003-2008 Benny Prijono <benny@prijono.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
#include <pjlib-util.h>
#include <pjlib.h>
#include "test.h"


#define THIS_FILE   "resolver_test.c"

////////////////////////////////////////////////////////////////////////////
/*
 * TODO: create various invalid DNS packets.
 */


////////////////////////////////////////////////////////////////////////////


#define ACTION_REPLY    0
#define ACTION_IGNORE   -1
#define ACTION_CB       -2

#undef s6_addr32
#define s6_addr32(addr, idx) *((pj_uint32_t *)(addr.s6_addr + idx*4))

static struct server_t
{
    pj_sock_t        sock;
    pj_uint16_t      port;
    pj_thread_t     *thread;

    /* Action:
     *  0:    reply with the response in resp.
     * -1:    ignore query (to simulate timeout).
     * other: reply with that error
     */
    int             action;

    pj_dns_parsed_packet    resp;
    void                  (*action_cb)(const pj_dns_parsed_packet *pkt,
                                       pj_dns_parsed_packet **p_res);

    unsigned        pkt_count;

} g_server[2];

static pj_pool_t *pool;
static pj_mutex_t *mutex;
static pj_dns_resolver *resolver;
static pj_bool_t thread_quit;
static pj_timer_heap_t *timer_heap;
static pj_ioqueue_t *ioqueue;
static pj_thread_t *poll_thread;
static pj_sem_t *sem;
static pj_dns_settings set;
static volatile pj_bool_t destroy_done;
static volatile pj_bool_t cb_after_destroy;
static pj_dns_resolver *start_during_destroy_res;
static pj_status_t start_during_destroy_status;
static pj_dns_async_query *start_during_destroy_query;
static int cancel_in_cb_count;
static pj_dns_async_query *cancel_in_cb_query;
static pj_bool_t cancel_in_cb_cancelled;
static int cancel_in_tocb_count;
static pj_dns_async_query *cancel_in_tocb_query;
static pj_bool_t cancel_in_tocb_cancelled;
static pj_status_t cancel_in_tocb_status;
static int cancel_child_parent_count;
static int cancel_child_child_count;
static pj_dns_async_query *cancel_child_query;
static pj_bool_t cancel_child_cancelled;
static pj_status_t cancel_child_status;
static pj_dns_resolver *cancel_unlocked_res;
static pj_sem_t *cancel_unlocked_entered;
static pj_sem_t *cancel_unlocked_probed;
static pj_bool_t cancel_unlocked_probe_seen;
static int cancel_unlocked_count;

#define MAX_LABEL   32

struct label_tab
{
    unsigned count;

    struct {
        unsigned pos;
        pj_str_t label;
    } a[MAX_LABEL];
};

static void lock()
{
    pj_mutex_lock(mutex);
}

static void unlock()
{
    pj_mutex_unlock(mutex);
}

static void write16(pj_uint8_t *p, pj_uint16_t val)
{
    p[0] = (pj_uint8_t)(val >> 8);
    p[1] = (pj_uint8_t)(val & 0xFF);
}

static void write32(pj_uint8_t *p, pj_uint32_t val)
{
    val = pj_htonl(val);
    pj_memcpy(p, &val, 4);
}

static int print_name(pj_uint8_t *pkt, int size,
                      pj_uint8_t *pos, const pj_str_t *name,
                      struct label_tab *tab)
{
    pj_uint8_t *p = pos;
    const char *endlabel, *endname;
    unsigned i;
    pj_str_t label;

    /* Check if name is in the table */
    for (i=0; i<tab->count; ++i) {
        if (pj_strcmp(&tab->a[i].label, name)==0)
            break;
    }

    if (i != tab->count) {
        write16(p, (pj_uint16_t)(tab->a[i].pos | (0xc0 << 8)));
        return 2;
    } else {
        if (tab->count < MAX_LABEL) {
            tab->a[tab->count].pos = (unsigned)(p-pkt);
            tab->a[tab->count].label.ptr = (char*)(p+1);
            tab->a[tab->count].label.slen = name->slen;
            ++tab->count;
        }
    }

    endlabel = name->ptr;
    endname = name->ptr + name->slen;

    label.ptr = (char*)name->ptr;

    while (endlabel != endname) {

        while (endlabel != endname && *endlabel != '.')
            ++endlabel;

        label.slen = (endlabel - label.ptr);

        if (size < label.slen+1)
            return -1;

        *p = (pj_uint8_t)label.slen;
        pj_memcpy(p+1, label.ptr, label.slen);

        size -= (int)(label.slen+1);
        p += (label.slen+1);

        if (endlabel != endname && *endlabel == '.')
            ++endlabel;
        label.ptr = (char*)endlabel;
    }

    if (size == 0)
        return -1;

    *p++ = '\0';

    return (int)(p-pos);
}

static int print_rr(pj_uint8_t *pkt, int size, pj_uint8_t *pos,
                    const pj_dns_parsed_rr *rr, struct label_tab *tab)
{
    pj_uint8_t *p = pos;
    int len;

    len = print_name(pkt, size, pos, &rr->name, tab);
    if (len < 0)
        return -1;

    p += len;
    size -= len;

    if (size < 8)
        return -1;

    PJ_TEST_EQ(rr->dnsclass, 1, NULL, return -1);

    write16(p+0, (pj_uint16_t)rr->type);        /* type     */
    write16(p+2, (pj_uint16_t)rr->dnsclass);    /* class    */
    write32(p+4, rr->ttl);                      /* TTL      */

    p += 8;
    size -= 8;

    if (rr->type == PJ_DNS_TYPE_A) {

        if (size < 6)
            return -1;

        /* RDLEN is 4 */
        write16(p, 4);

        /* Address */
        pj_memcpy(p+2, &rr->rdata.a.ip_addr, 4);

        p += 6;
        size -= 6;

    } else if (rr->type == PJ_DNS_TYPE_AAAA) {

        if (size < 18)
            return -1;

        /* RDLEN is 16 */
        write16(p, 16);

        /* Address */
        pj_memcpy(p+2, &rr->rdata.aaaa.ip_addr, 16);

        p += 18;
        size -= 18;

    } else if (rr->type == PJ_DNS_TYPE_CNAME ||
               rr->type == PJ_DNS_TYPE_NS ||
               rr->type == PJ_DNS_TYPE_PTR) {

        if (size < 4)
            return -1;

        len = print_name(pkt, size-2, p+2, &rr->rdata.cname.name, tab);
        if (len < 0)
            return -1;

        write16(p, (pj_uint16_t)len);

        p += (len + 2);
        size -= (len + 2);

    } else if (rr->type == PJ_DNS_TYPE_SRV) {

        if (size < 10)
            return -1;

        write16(p+2, rr->rdata.srv.prio);   /* Priority */
        write16(p+4, rr->rdata.srv.weight); /* Weight */
        write16(p+6, rr->rdata.srv.port);   /* Port */

        /* Target */
        len = print_name(pkt, size-8, p+8, &rr->rdata.srv.target, tab);
        if (len < 0)
            return -1;

        /* RDLEN */
        write16(p, (pj_uint16_t)(len + 6));

        p += (len + 8);
        size -= (len + 8);

    } else {
        pj_assert(!"Not supported");
        return -1;
    }

    return (int)(p-pos);
}

static int print_packet(const pj_dns_parsed_packet *rec, pj_uint8_t *pkt,
                        int size)
{
    pj_uint8_t *p = pkt;
    struct label_tab tab;
    int i, len;

    tab.count = 0;

#if 0
    pj_enter_critical_section();
    PJ_LOG(3,(THIS_FILE, "Sending response:"));
    pj_dns_dump_packet(rec);
    pj_leave_critical_section();
#endif

    pj_assert(sizeof(pj_dns_hdr)==12);
    if (size < (int)sizeof(pj_dns_hdr))
        return -1;

    /* Initialize header. This mock server only serializes responses, so set
     * the QR bit as a real server would.
     */
    write16(p+0,  rec->hdr.id);
    write16(p+2,  (pj_uint16_t)(rec->hdr.flags | PJ_DNS_SET_QR(1)));
    write16(p+4,  rec->hdr.qdcount);
    write16(p+6,  rec->hdr.anscount);
    write16(p+8,  rec->hdr.nscount);
    write16(p+10, rec->hdr.arcount);

    p = pkt + sizeof(pj_dns_hdr);
    size -= sizeof(pj_dns_hdr);

    /* Print queries */
    for (i=0; i<rec->hdr.qdcount; ++i) {

        len = print_name(pkt, size, p, &rec->q[i].name, &tab);
        if (len < 0)
            return -1;

        p += len;
        size -= len;

        if (size < 4)
            return -1;

        /* Set type */
        write16(p+0, (pj_uint16_t)rec->q[i].type);

        /* Set class (IN=1) */
        pj_assert(rec->q[i].dnsclass == 1);
        write16(p+2, rec->q[i].dnsclass);

        p += 4;
    }

    /* Print answers */
    for (i=0; i<rec->hdr.anscount; ++i) {
        len = print_rr(pkt, size, p, &rec->ans[i], &tab);
        if (len < 0)
            return -1;

        p += len;
        size -= len;
    }

    /* Print NS records */
    for (i=0; i<rec->hdr.nscount; ++i) {
        len = print_rr(pkt, size, p, &rec->ns[i], &tab);
        if (len < 0)
            return -1;

        p += len;
        size -= len;
    }

    /* Print additional records */
    for (i=0; i<rec->hdr.arcount; ++i) {
        len = print_rr(pkt, size, p, &rec->arr[i], &tab);
        if (len < 0)
            return -1;

        p += len;
        size -= len;
    }

    return (int)(p - pkt);
}


static int server_thread(void *p)
{
    struct server_t *srv = (struct server_t*)p;

    while (!thread_quit) {
        pj_fd_set_t rset;
        pj_time_val timeout = {0, 500};
        pj_sockaddr src_addr;
        pj_dns_parsed_packet *req;
        char pkt[1024];
        pj_ssize_t pkt_len;
        int rc, src_len;

        PJ_FD_ZERO(&rset);
        PJ_FD_SET(srv->sock, &rset);

        rc = pj_sock_select((int)(srv->sock+1), &rset, NULL, NULL, &timeout);
        if (rc != 1)
            continue;

        src_len = sizeof(src_addr);
        pkt_len = sizeof(pkt);
        rc = pj_sock_recvfrom(srv->sock, pkt, &pkt_len, 0, 
                              &src_addr, &src_len);
        if (rc != 0) {
            app_perror("Server error receiving packet", rc);
            continue;
        }

        PJ_LOG(5,(THIS_FILE, "Server %ld processing packet", srv - &g_server[0]));

        lock();
        rc = pj_dns_parse_packet(pool, pkt, (unsigned)pkt_len, &req);
        unlock();
        if (rc != PJ_SUCCESS) {
            app_perror("server error parsing packet", rc);
            continue;
        }

        srv->pkt_count++;

        /* Verify packet */
        if (req->hdr.qdcount != 1) {
            PJ_LOG(5,(THIS_FILE, "server receive multiple queries in a packet"));
            continue;
        }

        if (req->q[0].dnsclass != 1) {
            PJ_LOG(5,(THIS_FILE, "server receive query with invalid DNS class"));
            continue;
        }

        /* Simulate network RTT */
        pj_thread_sleep(50);

        if (srv->action == ACTION_IGNORE) {
            continue;
        } else if (srv->action == ACTION_REPLY) {
            srv->resp.hdr.id = req->hdr.id;
            pkt_len = print_packet(&srv->resp, (pj_uint8_t*)pkt, sizeof(pkt));
            pj_sock_sendto(srv->sock, pkt, &pkt_len, 0, &src_addr, src_len);
        } else if (srv->action == ACTION_CB) {
            pj_dns_parsed_packet *resp;
            (*srv->action_cb)(req, &resp);
            resp->hdr.id = req->hdr.id;
            pkt_len = print_packet(resp, (pj_uint8_t*)pkt, sizeof(pkt));
            pj_sock_sendto(srv->sock, pkt, &pkt_len, 0, &src_addr, src_len);
        } else if (srv->action > 0) {
            req->hdr.flags |= PJ_DNS_SET_RCODE(srv->action);
            pkt_len = print_packet(req, (pj_uint8_t*)pkt, sizeof(pkt));
            pj_sock_sendto(srv->sock, pkt, &pkt_len, 0, &src_addr, src_len);
        }
    }

    return 0;
}

static int poll_worker_thread(void *p)
{
    PJ_UNUSED_ARG(p);

    while (!thread_quit) {
        pj_time_val delay = {0, 10};
        pj_timer_heap_poll(timer_heap, NULL);
        pj_ioqueue_poll(ioqueue, &delay);
    }

    return 0;
}

static void destroy(void);

static int init(pj_bool_t use_ipv6)
{
    pj_str_t nameservers[2];
    pj_uint16_t ports[2];
    int i;

    if (use_ipv6) {
        nameservers[0] = pj_str("::1");
        nameservers[1] = pj_str("::1");
    } else {
        nameservers[0] = pj_str("127.0.0.1");
        nameservers[1] = pj_str("127.0.0.1");
    }

    pool = pj_pool_create(mem, NULL, 2000, 2000, NULL);

    PJ_TEST_SUCCESS(pj_mutex_create_simple(pool, "resolver_test", &mutex),
                    NULL, return -3);
    PJ_TEST_SUCCESS(pj_sem_create(pool, NULL, 0, 2, &sem), NULL, return -5);

    thread_quit = PJ_FALSE;

    for (i=0; i<2; ++i) {
        pj_sockaddr addr;
        int namelen;

        PJ_TEST_SUCCESS(pj_sock_socket(
                            (use_ipv6? pj_AF_INET6() : pj_AF_INET()),
                            pj_SOCK_DGRAM(), 0, &g_server[i].sock),
                        NULL, return -10);

        pj_sockaddr_init((use_ipv6? pj_AF_INET6() : pj_AF_INET()),
                         &addr, NULL, 0);

        PJ_TEST_SUCCESS(pj_sock_bind(g_server[i].sock, &addr,
                                     pj_sockaddr_get_len(&addr)),
                        NULL, return -20);

        namelen = sizeof(addr);
        PJ_TEST_SUCCESS(pj_sock_getsockname(g_server[i].sock, &addr,
                                            &namelen),
                        NULL, return -25);
        g_server[i].port = ports[i] = pj_sockaddr_get_port(&addr);

        PJ_TEST_SUCCESS(pj_thread_create(pool, NULL, &server_thread,
                                         &g_server[i],
                                         0, 0, &g_server[i].thread),
                        NULL, return -30);
    }

    PJ_TEST_SUCCESS(pj_timer_heap_create(pool, 16, &timer_heap), NULL, return -31);
    PJ_TEST_SUCCESS(pj_ioqueue_create(pool, 16, &ioqueue), NULL, return -32);
    PJ_TEST_SUCCESS(pj_dns_resolver_create(mem, NULL, 0, timer_heap, ioqueue, &resolver),
                    NULL, return -40);

    pj_dns_resolver_get_settings(resolver, &set);
    set.good_ns_ttl = 10;
    set.bad_ns_ttl = 10;
    pj_dns_resolver_set_settings(resolver, &set);

    PJ_TEST_SUCCESS(pj_dns_resolver_set_ns(resolver, 2, nameservers, ports),
                    NULL, return -41);
    PJ_TEST_SUCCESS(pj_thread_create(pool, NULL, &poll_worker_thread, NULL, 0, 0, &poll_thread),
                    NULL, return -42);

    return 0;
}


static void destroy(void)
{
    /* note: need to set global vars back to zero since test can be
     * repeated for IPv6
     */
    int i;

    thread_quit = PJ_TRUE;

    for (i=0; i<2; ++i) {
        pj_thread_join(g_server[i].thread);
        pj_sock_close(g_server[i].sock);
    }

    pj_thread_join(poll_thread);
    poll_thread = NULL;
    thread_quit = PJ_FALSE;

    pj_dns_resolver_destroy(resolver, PJ_FALSE);
    resolver = NULL;
    pj_ioqueue_destroy(ioqueue);
    ioqueue = NULL;
    pj_timer_heap_destroy(timer_heap);
    timer_heap = NULL;

    pj_sem_destroy(sem);
    sem = NULL;
    pj_mutex_destroy(mutex);
    mutex = NULL;
    pj_pool_release(pool);
    pool = NULL;

    pj_bzero(g_server, sizeof(g_server));
}


////////////////////////////////////////////////////////////////////////////
/* DNS A parser tests */
static int a_parser_test(void)
{
    pj_dns_parsed_packet pkt;
    pj_dns_a_record rec;

    PJ_LOG(3,(THIS_FILE, "  DNS A record parser tests"));

    pkt.q = PJ_POOL_ZALLOC_T(pool, pj_dns_parsed_query);
    pkt.ans = (pj_dns_parsed_rr*)
              pj_pool_calloc(pool, 32, sizeof(pj_dns_parsed_rr));

    /* Simple answer with direct A record, but with addition of
     * a CNAME and another A to confuse the parser.
     */
    PJ_LOG(3,(THIS_FILE, "    A RR with duplicate CNAME/A"));
    pkt.hdr.flags = 0;
    pkt.hdr.qdcount = 1;
    pkt.q[0].type = PJ_DNS_TYPE_A;
    pkt.q[0].dnsclass = 1;
    pkt.q[0].name = pj_str("ahost");
    pkt.hdr.anscount = 3;

    /* This is the RR corresponding to the query */
    pkt.ans[0].name = pj_str("ahost");
    pkt.ans[0].type = PJ_DNS_TYPE_A;
    pkt.ans[0].dnsclass = 1;
    pkt.ans[0].ttl = 1;
    pkt.ans[0].rdata.a.ip_addr.s_addr = 0x01020304;

    /* CNAME to confuse the parser */
    pkt.ans[1].name = pj_str("ahost");
    pkt.ans[1].type = PJ_DNS_TYPE_CNAME;
    pkt.ans[1].dnsclass = 1;
    pkt.ans[1].ttl = 1;
    pkt.ans[1].rdata.cname.name = pj_str("bhost");

    /* DNS A RR to confuse the parser */
    pkt.ans[2].name = pj_str("bhost");
    pkt.ans[2].type = PJ_DNS_TYPE_A;
    pkt.ans[2].dnsclass = 1;
    pkt.ans[2].ttl = 1;
    pkt.ans[2].rdata.a.ip_addr.s_addr = 0x0203;


    PJ_TEST_SUCCESS(pj_dns_parse_a_response(&pkt, &rec), NULL, return -100)
    PJ_TEST_EQ(pj_strcmp2(&rec.name, "ahost"), 0, NULL, return -110);
    PJ_TEST_EQ(rec.alias.slen, 0, NULL, return -112);
    PJ_TEST_EQ(rec.addr_count, 1, NULL, return -114);
    PJ_TEST_EQ(rec.addr[0].s_addr, 0x01020304, NULL, return -116);

    /* Answer with the target corresponds to a CNAME entry, but not
     * as the first record, and with additions of some CNAME and A
     * entries to confuse the parser.
     */
    PJ_LOG(3,(THIS_FILE, "    CNAME RR with duplicate CNAME/A"));
    pkt.hdr.flags = 0;
    pkt.hdr.qdcount = 1;
    pkt.q[0].type = PJ_DNS_TYPE_A;
    pkt.q[0].dnsclass = 1;
    pkt.q[0].name = pj_str("ahost");
    pkt.hdr.anscount = 4;

    /* This is the DNS A record for the alias */
    pkt.ans[0].name = pj_str("ahostalias");
    pkt.ans[0].type = PJ_DNS_TYPE_A;
    pkt.ans[0].dnsclass = 1;
    pkt.ans[0].ttl = 1;
    pkt.ans[0].rdata.a.ip_addr.s_addr = 0x02020202;

    /* CNAME entry corresponding to the query */
    pkt.ans[1].name = pj_str("ahost");
    pkt.ans[1].type = PJ_DNS_TYPE_CNAME;
    pkt.ans[1].dnsclass = 1;
    pkt.ans[1].ttl = 1;
    pkt.ans[1].rdata.cname.name = pj_str("ahostalias");

    /* Another CNAME to confuse the parser */
    pkt.ans[2].name = pj_str("ahost");
    pkt.ans[2].type = PJ_DNS_TYPE_CNAME;
    pkt.ans[2].dnsclass = 1;
    pkt.ans[2].ttl = 1;
    pkt.ans[2].rdata.cname.name = pj_str("ahostalias2");

    /* Another DNS A to confuse the parser */
    pkt.ans[3].name = pj_str("ahostalias2");
    pkt.ans[3].type = PJ_DNS_TYPE_A;
    pkt.ans[3].dnsclass = 1;
    pkt.ans[3].ttl = 1;
    pkt.ans[3].rdata.a.ip_addr.s_addr = 0x03030303;

    PJ_TEST_SUCCESS(pj_dns_parse_a_response(&pkt, &rec), NULL, return -120);
    PJ_TEST_EQ(pj_strcmp2(&rec.name, "ahost"), 0, NULL, return -122);
    PJ_TEST_EQ(pj_strcmp2(&rec.alias, "ahostalias"), 0, NULL, return -124);
    PJ_TEST_EQ(rec.addr_count, 1, NULL, return -126);
    PJ_TEST_EQ(rec.addr[0].s_addr, 0x02020202, NULL, return -128);

    /*
     * No query section.
     */
    PJ_LOG(3,(THIS_FILE, "    No query section"));
    pkt.hdr.qdcount = 0;
    pkt.hdr.anscount = 0;

    PJ_TEST_EQ(pj_dns_parse_a_response(&pkt, &rec), PJLIB_UTIL_EDNSINANSWER,
               NULL, return -130);

    /*
     * No answer section.
     */
    PJ_LOG(3,(THIS_FILE, "    No answer section"));
    pkt.hdr.flags = 0;
    pkt.hdr.qdcount = 1;
    pkt.q[0].type = PJ_DNS_TYPE_A;
    pkt.q[0].dnsclass = 1;
    pkt.q[0].name = pj_str("ahost");
    pkt.hdr.anscount = 0;

    PJ_TEST_EQ(pj_dns_parse_a_response(&pkt, &rec), PJLIB_UTIL_EDNSNOANSWERREC,
               NULL, return -140);

    /*
     * Answer doesn't match query.
     */
    PJ_LOG(3,(THIS_FILE, "    Answer doesn't match query"));
    pkt.hdr.flags = 0;
    pkt.hdr.qdcount = 1;
    pkt.q[0].type = PJ_DNS_TYPE_A;
    pkt.q[0].dnsclass = 1;
    pkt.q[0].name = pj_str("ahost");
    pkt.hdr.anscount = 1;

    /* An answer that doesn't match the query */
    pkt.ans[0].name = pj_str("ahostalias");
    pkt.ans[0].type = PJ_DNS_TYPE_A;
    pkt.ans[0].dnsclass = 1;
    pkt.ans[0].ttl = 1;
    pkt.ans[0].rdata.a.ip_addr.s_addr = 0x02020202;

    PJ_TEST_EQ(pj_dns_parse_a_response(&pkt, &rec), PJLIB_UTIL_EDNSNOANSWERREC,
               NULL, return -150);


    /*
     * DNS CNAME that doesn't have corresponding DNS A.
     */
    PJ_LOG(3,(THIS_FILE, "    CNAME with no matching DNS A RR (1)"));
    pkt.hdr.flags = 0;
    pkt.hdr.qdcount = 1;
    pkt.q[0].type = PJ_DNS_TYPE_A;
    pkt.q[0].dnsclass = 1;
    pkt.q[0].name = pj_str("ahost");
    pkt.hdr.anscount = 1;

    /* The CNAME */
    pkt.ans[0].name = pj_str("ahost");
    pkt.ans[0].type = PJ_DNS_TYPE_CNAME;
    pkt.ans[0].dnsclass = 1;
    pkt.ans[0].ttl = 1;
    pkt.ans[0].rdata.cname.name = pj_str("ahostalias");

    PJ_TEST_EQ(pj_dns_parse_a_response(&pkt, &rec), PJLIB_UTIL_EDNSNOANSWERREC,
               NULL, return -160);


    /*
     * DNS CNAME that doesn't have corresponding DNS A.
     */
    PJ_LOG(3,(THIS_FILE, "    CNAME with no matching DNS A RR (2)"));
    pkt.hdr.flags = 0;
    pkt.hdr.qdcount = 1;
    pkt.q[0].type = PJ_DNS_TYPE_A;
    pkt.q[0].dnsclass = 1;
    pkt.q[0].name = pj_str("ahost");
    pkt.hdr.anscount = 2;

    /* The CNAME */
    pkt.ans[0].name = pj_str("ahost");
    pkt.ans[0].type = PJ_DNS_TYPE_CNAME;
    pkt.ans[0].dnsclass = 1;
    pkt.ans[0].ttl = 1;
    pkt.ans[0].rdata.cname.name = pj_str("ahostalias");

    /* DNS A record, but the name doesn't match */
    pkt.ans[1].name = pj_str("ahost");
    pkt.ans[1].type = PJ_DNS_TYPE_A;
    pkt.ans[1].dnsclass = 1;
    pkt.ans[1].ttl = 1;
    pkt.ans[1].rdata.a.ip_addr.s_addr = 0x01020304;

    PJ_TEST_EQ(pj_dns_parse_a_response(&pkt, &rec), PJLIB_UTIL_EDNSNOANSWERREC,
               NULL, return -170);

    return 0;
}


////////////////////////////////////////////////////////////////////////////
/* DNS A/AAAA parser tests */
static int addr_parser_test(void)
{
    pj_dns_parsed_packet pkt;
    pj_dns_addr_record rec;

    PJ_LOG(3,(THIS_FILE, "  DNS A/AAAA record parser tests"));

    pkt.q = PJ_POOL_ZALLOC_T(pool, pj_dns_parsed_query);
    pkt.ans = (pj_dns_parsed_rr*)
              pj_pool_calloc(pool, 32, sizeof(pj_dns_parsed_rr));

    /* Simple answer with direct A record, but with addition of
     * a CNAME and another A to confuse the parser.
     */
    PJ_LOG(3,(THIS_FILE, "    A RR with duplicate CNAME/A"));
    pkt.hdr.flags = 0;
    pkt.hdr.qdcount = 1;
    pkt.q[0].type = PJ_DNS_TYPE_A;
    pkt.q[0].dnsclass = 1;
    pkt.q[0].name = pj_str("ahost");
    pkt.hdr.anscount = 4;

    /* This is the RR corresponding to the query */
    pkt.ans[0].name = pj_str("ahost");
    pkt.ans[0].type = PJ_DNS_TYPE_A;
    pkt.ans[0].dnsclass = 1;
    pkt.ans[0].ttl = 1;
    pkt.ans[0].rdata.a.ip_addr.s_addr = 0x01020304;

    /* CNAME to confuse the parser */
    pkt.ans[1].name = pj_str("ahost");
    pkt.ans[1].type = PJ_DNS_TYPE_CNAME;
    pkt.ans[1].dnsclass = 1;
    pkt.ans[1].ttl = 1;
    pkt.ans[1].rdata.cname.name = pj_str("bhost");

    /* DNS A RR to confuse the parser */
    pkt.ans[2].name = pj_str("bhost");
    pkt.ans[2].type = PJ_DNS_TYPE_A;
    pkt.ans[2].dnsclass = 1;
    pkt.ans[2].ttl = 1;
    pkt.ans[2].rdata.a.ip_addr.s_addr = 0x0203;

    /* Additional RR corresponding to the query, DNS AAAA RR */
    pkt.ans[3].name = pj_str("ahost");
    pkt.ans[3].type = PJ_DNS_TYPE_AAAA;
    pkt.ans[3].dnsclass = 1;
    pkt.ans[3].ttl = 1;
    s6_addr32(pkt.ans[3].rdata.aaaa.ip_addr, 0) = 0x01020304;


    PJ_TEST_SUCCESS(pj_dns_parse_addr_response(&pkt, &rec), NULL, return -200);
    PJ_TEST_EQ(pj_strcmp2(&rec.name, "ahost"), 0, NULL, return -210);
    PJ_TEST_EQ(rec.alias.slen, 0, NULL, return -212);
    PJ_TEST_EQ(rec.addr_count, 2, NULL, return -214);
    PJ_TEST_EQ(rec.addr[0].af, pj_AF_INET(), NULL, return -220);
    PJ_TEST_EQ(rec.addr[0].ip.v4.s_addr, 0x01020304, NULL, return -222);
    PJ_TEST_EQ(rec.addr[1].af, pj_AF_INET6(), NULL, return -230);
    PJ_TEST_EQ(s6_addr32(rec.addr[1].ip.v6, 0), 0x01020304, NULL, return -232);

    /* Answer with the target corresponds to a CNAME entry, but not
     * as the first record, and with additions of some CNAME and A
     * entries to confuse the parser.
     */
    PJ_LOG(3,(THIS_FILE, "    CNAME RR with duplicate CNAME/A"));
    pkt.hdr.flags = 0;
    pkt.hdr.qdcount = 1;
    pkt.q[0].type = PJ_DNS_TYPE_A;
    pkt.q[0].dnsclass = 1;
    pkt.q[0].name = pj_str("ahost");
    pkt.hdr.anscount = 4;

    /* This is the DNS A record for the alias */
    pkt.ans[0].name = pj_str("ahostalias");
    pkt.ans[0].type = PJ_DNS_TYPE_A;
    pkt.ans[0].dnsclass = 1;
    pkt.ans[0].ttl = 1;
    pkt.ans[0].rdata.a.ip_addr.s_addr = 0x02020202;

    /* CNAME entry corresponding to the query */
    pkt.ans[1].name = pj_str("ahost");
    pkt.ans[1].type = PJ_DNS_TYPE_CNAME;
    pkt.ans[1].dnsclass = 1;
    pkt.ans[1].ttl = 1;
    pkt.ans[1].rdata.cname.name = pj_str("ahostalias");

    /* Another CNAME to confuse the parser */
    pkt.ans[2].name = pj_str("ahost");
    pkt.ans[2].type = PJ_DNS_TYPE_CNAME;
    pkt.ans[2].dnsclass = 1;
    pkt.ans[2].ttl = 1;
    pkt.ans[2].rdata.cname.name = pj_str("ahostalias2");

    /* Another DNS A to confuse the parser */
    pkt.ans[3].name = pj_str("ahostalias2");
    pkt.ans[3].type = PJ_DNS_TYPE_A;
    pkt.ans[3].dnsclass = 1;
    pkt.ans[3].ttl = 1;
    pkt.ans[3].rdata.a.ip_addr.s_addr = 0x03030303;

    PJ_TEST_SUCCESS(pj_dns_parse_addr_response(&pkt, &rec), NULL, return -240);
    PJ_TEST_EQ(pj_strcmp2(&rec.name, "ahost"), 0, NULL, return -242);
    PJ_TEST_EQ(pj_strcmp2(&rec.alias, "ahostalias"), 0, NULL, return -244);
    PJ_TEST_EQ(rec.addr_count, 1, NULL, return -246);
    PJ_TEST_EQ(rec.addr[0].ip.v4.s_addr, 0x02020202, NULL, return -248);

    /*
     * No query section.
     */
    PJ_LOG(3,(THIS_FILE, "    No query section"));
    pkt.hdr.qdcount = 0;
    pkt.hdr.anscount = 0;

    PJ_TEST_EQ(pj_dns_parse_addr_response(&pkt, &rec),
               PJLIB_UTIL_EDNSINANSWER, NULL, return -245);

    /*
     * No answer section.
     */
    PJ_LOG(3,(THIS_FILE, "    No answer section"));
    pkt.hdr.flags = 0;
    pkt.hdr.qdcount = 1;
    pkt.q[0].type = PJ_DNS_TYPE_A;
    pkt.q[0].dnsclass = 1;
    pkt.q[0].name = pj_str("ahost");
    pkt.hdr.anscount = 0;

    PJ_TEST_EQ(pj_dns_parse_addr_response(&pkt, &rec),
               PJLIB_UTIL_EDNSNOANSWERREC, NULL, return -250);

    /*
     * Answer doesn't match query.
     */
    PJ_LOG(3,(THIS_FILE, "    Answer doesn't match query"));
    pkt.hdr.flags = 0;
    pkt.hdr.qdcount = 1;
    pkt.q[0].type = PJ_DNS_TYPE_A;
    pkt.q[0].dnsclass = 1;
    pkt.q[0].name = pj_str("ahost");
    pkt.hdr.anscount = 1;

    /* An answer that doesn't match the query */
    pkt.ans[0].name = pj_str("ahostalias");
    pkt.ans[0].type = PJ_DNS_TYPE_A;
    pkt.ans[0].dnsclass = 1;
    pkt.ans[0].ttl = 1;
    pkt.ans[0].rdata.a.ip_addr.s_addr = 0x02020202;

    PJ_TEST_EQ(pj_dns_parse_addr_response(&pkt, &rec),
               PJLIB_UTIL_EDNSNOANSWERREC, NULL, return -260);


    /*
     * DNS CNAME that doesn't have corresponding DNS A.
     */
    PJ_LOG(3,(THIS_FILE, "    CNAME with no matching DNS A RR (1)"));
    pkt.hdr.flags = 0;
    pkt.hdr.qdcount = 1;
    pkt.q[0].type = PJ_DNS_TYPE_A;
    pkt.q[0].dnsclass = 1;
    pkt.q[0].name = pj_str("ahost");
    pkt.hdr.anscount = 1;

    /* The CNAME */
    pkt.ans[0].name = pj_str("ahost");
    pkt.ans[0].type = PJ_DNS_TYPE_CNAME;
    pkt.ans[0].dnsclass = 1;
    pkt.ans[0].ttl = 1;
    pkt.ans[0].rdata.cname.name = pj_str("ahostalias");

    PJ_TEST_EQ(pj_dns_parse_addr_response(&pkt, &rec),
               PJLIB_UTIL_EDNSNOANSWERREC, NULL, return -270);


    /*
     * DNS CNAME that doesn't have corresponding DNS A.
     */
    PJ_LOG(3,(THIS_FILE, "    CNAME with no matching DNS A RR (2)"));
    pkt.hdr.flags = 0;
    pkt.hdr.qdcount = 1;
    pkt.q[0].type = PJ_DNS_TYPE_A;
    pkt.q[0].dnsclass = 1;
    pkt.q[0].name = pj_str("ahost");
    pkt.hdr.anscount = 2;

    /* The CNAME */
    pkt.ans[0].name = pj_str("ahost");
    pkt.ans[0].type = PJ_DNS_TYPE_CNAME;
    pkt.ans[0].dnsclass = 1;
    pkt.ans[0].ttl = 1;
    pkt.ans[0].rdata.cname.name = pj_str("ahostalias");

    /* DNS A record, but the name doesn't match */
    pkt.ans[1].name = pj_str("ahost");
    pkt.ans[1].type = PJ_DNS_TYPE_A;
    pkt.ans[1].dnsclass = 1;
    pkt.ans[1].ttl = 1;
    pkt.ans[1].rdata.a.ip_addr.s_addr = 0x01020304;

    PJ_TEST_EQ(pj_dns_parse_addr_response(&pkt, &rec),
               PJLIB_UTIL_EDNSNOANSWERREC, NULL, return -280);

    return 0;
}


////////////////////////////////////////////////////////////////////////////
/* Simple DNS test */
#define IP_ADDR0    0x00010203

static void dns_callback(void *user_data,
                         pj_status_t status,
                         pj_dns_parsed_packet *resp)
{
    PJ_UNUSED_ARG(user_data);

    pj_sem_post(sem);

    PJ_ASSERT_ON_FAIL(status == PJ_SUCCESS, return);
    PJ_ASSERT_ON_FAIL(resp, return);
    PJ_ASSERT_ON_FAIL(resp->hdr.anscount == 1, return);
    PJ_ASSERT_ON_FAIL(resp->ans[0].type == PJ_DNS_TYPE_A, return);
    PJ_ASSERT_ON_FAIL(resp->ans[0].rdata.a.ip_addr.s_addr == IP_ADDR0, return);

}


static int simple_test(void)
{
    pj_str_t name = pj_str("helloworld");
    pj_dns_parsed_packet *r;

    PJ_LOG(3,(THIS_FILE, "  simple successful test"));

    g_server[0].pkt_count = 0;
    g_server[1].pkt_count = 0;

    g_server[0].action = ACTION_REPLY;
    r = &g_server[0].resp;
    r->hdr.qdcount = 1;
    r->hdr.anscount = 1;
    r->q = PJ_POOL_ZALLOC_T(pool, pj_dns_parsed_query);
    r->q[0].type = PJ_DNS_TYPE_A;
    r->q[0].dnsclass = 1;
    r->q[0].name = name;
    r->ans = PJ_POOL_ZALLOC_T(pool, pj_dns_parsed_rr);
    r->ans[0].type = PJ_DNS_TYPE_A;
    r->ans[0].dnsclass = 1;
    r->ans[0].name = name;
    r->ans[0].rdata.a.ip_addr.s_addr = IP_ADDR0;

    g_server[1].action = ACTION_REPLY;
    r = &g_server[1].resp;
    r->hdr.qdcount = 1;
    r->hdr.anscount = 1;
    r->q = PJ_POOL_ZALLOC_T(pool, pj_dns_parsed_query);
    r->q[0].type = PJ_DNS_TYPE_A;
    r->q[0].dnsclass = 1;
    r->q[0].name = name;
    r->ans = PJ_POOL_ZALLOC_T(pool, pj_dns_parsed_rr);
    r->ans[0].type = PJ_DNS_TYPE_A;
    r->ans[0].dnsclass = 1;
    r->ans[0].name = name;
    r->ans[0].rdata.a.ip_addr.s_addr = IP_ADDR0;

    PJ_TEST_SUCCESS(pj_dns_resolver_start_query(
                        resolver, &name, PJ_DNS_TYPE_A, 0,
                        &dns_callback, NULL, NULL),
                    NULL, return -300);

    pj_sem_wait(sem);
    pj_thread_sleep((unsigned)(set.qretr_delay * 1.2));


    /* Both servers must get packet */
    PJ_TEST_EQ(g_server[0].pkt_count, 1, NULL, return -310);
    PJ_TEST_EQ(g_server[1].pkt_count, 1, NULL, return -320);

    return 0;
}


////////////////////////////////////////////////////////////////////////////
/* DNS nameserver fail-over test */

static void dns_callback_1b(void *user_data,
                            pj_status_t status,
                            pj_dns_parsed_packet *resp)
{
    PJ_UNUSED_ARG(user_data);
    PJ_UNUSED_ARG(resp);

    pj_sem_post(sem);

    PJ_TEST_EQ(status, PJ_STATUS_FROM_DNS_RCODE(PJ_DNS_RCODE_NXDOMAIN),
               NULL, return);
}




/* Callback for the destroy-with-pending-query test: flags any invocation
 * that happens after the resolver has been destroyed.
 */
static void dns_callback_destroy(void *user_data,
                                 pj_status_t status,
                                 pj_dns_parsed_packet *resp)
{
    PJ_UNUSED_ARG(user_data);
    PJ_UNUSED_ARG(status);
    PJ_UNUSED_ARG(resp);

    if (destroy_done)
        cb_after_destroy = PJ_TRUE;
}


/* Destroy the resolver while a query is still pending and the timer heap is
 * being polled by another thread. The query's retransmit timer must be
 * cancelled by pj_dns_resolver_destroy(); otherwise it fires after the
 * socket is closed and sends on a NULL udp_key (assert/abort), or, with
 * asserts disabled, invokes the callback after a destroy(notify=PJ_FALSE).
 */
static int dns_destroy_pending_test(void)
{
    pj_str_t name = pj_str("name_destroy");
    pj_str_t nameservers[2];
    pj_uint16_t ports[2];
    pj_dns_resolver *res;

    PJ_LOG(3,(THIS_FILE, "  destroy with pending query test"));

    destroy_done = PJ_FALSE;
    cb_after_destroy = PJ_FALSE;

    /* Servers ignore the query so it stays pending and keeps retransmitting. */
    g_server[0].action = ACTION_IGNORE;
    g_server[1].action = ACTION_IGNORE;

    /* Use a dedicated resolver over the shared, polled timer heap and
     * ioqueue, so destroying it does not disturb the test harness.
     */
    nameservers[0] = nameservers[1] = pj_str("127.0.0.1");
    ports[0] = g_server[0].port;
    ports[1] = g_server[1].port;

    PJ_TEST_SUCCESS(pj_dns_resolver_create(mem, NULL, 0, timer_heap, ioqueue,
                                           &res),
                    NULL, return -500);
    PJ_TEST_SUCCESS(pj_dns_resolver_set_ns(res, 2, nameservers, ports),
                    NULL, return -505);

    PJ_TEST_SUCCESS(pj_dns_resolver_start_query(
                        res, &name, PJ_DNS_TYPE_A, 0,
                        &dns_callback_destroy, NULL, NULL),
                    NULL, return -510);

    /* Destroy while the poll thread is still running. */
    destroy_done = PJ_TRUE;
    pj_dns_resolver_destroy(res, PJ_FALSE);

    /* Wait past the retransmit delay: a surviving timer would fire here. */
    pj_thread_sleep((unsigned)(set.qretr_delay * 2));

    PJ_TEST_EQ(cb_after_destroy, PJ_FALSE, NULL, return -520);

    return 0;
}


/* Callback for the start-during-destroy test: starts a new query from
 * inside the PJ_ECANCELLED notification delivered by
 * pj_dns_resolver_destroy(), the way the SRV resolver's fallback does.
 */
static void dns_callback_start_during_destroy(void *user_data,
                                              pj_status_t status,
                                              pj_dns_parsed_packet *resp)
{
    pj_str_t name = pj_str("name_restart");

    PJ_UNUSED_ARG(user_data);
    PJ_UNUSED_ARG(resp);

    if (status != PJ_ECANCELLED)
        return;

    /* Seed the out-pointer with a dummy, as the SRV resolver does, to
     * verify that a rejected start still writes it.
     */
    start_during_destroy_query = (pj_dns_async_query*)0x1;
    start_during_destroy_status =
        pj_dns_resolver_start_query(start_during_destroy_res, &name,
                                    PJ_DNS_TYPE_A, 0,
                                    &dns_callback_destroy, NULL,
                                    &start_during_destroy_query);
}


/* Start a query from inside destroy's cancel notification: the resolver
 * must reject it with PJ_EGONE, write the out-pointer, and leave no timer
 * armed past the teardown.
 */
static int dns_start_during_destroy_test(void)
{
    pj_str_t name = pj_str("name_sdd");
    pj_str_t nameservers[2];
    pj_uint16_t ports[2];

    PJ_LOG(3,(THIS_FILE, "  start query during destroy test"));

    destroy_done = PJ_FALSE;
    cb_after_destroy = PJ_FALSE;
    start_during_destroy_status = PJ_SUCCESS;
    start_during_destroy_query = NULL;

    /* Servers ignore the query so it stays pending. */
    g_server[0].action = ACTION_IGNORE;
    g_server[1].action = ACTION_IGNORE;

    nameservers[0] = nameservers[1] = pj_str("127.0.0.1");
    ports[0] = g_server[0].port;
    ports[1] = g_server[1].port;

    PJ_TEST_SUCCESS(pj_dns_resolver_create(mem, NULL, 0, timer_heap, ioqueue,
                                           &start_during_destroy_res),
                    NULL, return -720);
    PJ_TEST_SUCCESS(pj_dns_resolver_set_ns(start_during_destroy_res, 2,
                                           nameservers, ports),
                    NULL, return -725);

    PJ_TEST_SUCCESS(pj_dns_resolver_start_query(
                        start_during_destroy_res, &name, PJ_DNS_TYPE_A, 0,
                        &dns_callback_start_during_destroy, NULL, NULL),
                    NULL, return -730);

    destroy_done = PJ_TRUE;
    pj_dns_resolver_destroy(start_during_destroy_res, PJ_TRUE);

    /* The cancel notification must have run and its re-entrant start must
     * have been rejected with the out-pointer cleared.
     */
    PJ_TEST_EQ(start_during_destroy_status, PJ_EGONE, NULL, return -740);
    PJ_TEST_TRUE(start_during_destroy_query == NULL, NULL, return -745);

    /* Wait past the retransmit delay: a timer armed by the rejected start
     * would fire here.
     */
    pj_thread_sleep((unsigned)(set.qretr_delay * 2));

    PJ_TEST_EQ(cb_after_destroy, PJ_FALSE, NULL, return -750);

    return 0;
}


/* Callback for the cancel-in-callback test: on the first delivery it cancels
 * its own query with notify=PJ_TRUE. Before the callback is captured and
 * cleared under the group lock, the query still held a live cb, so cancel
 * delivered a second (PJ_ECANCELLED) callback for the same query.
 */
static void dns_callback_cancel_in_cb(void *user_data,
                                      pj_status_t status,
                                      pj_dns_parsed_packet *resp)
{
    PJ_UNUSED_ARG(user_data);
    PJ_UNUSED_ARG(status);
    PJ_UNUSED_ARG(resp);

    cancel_in_cb_count++;

    if (cancel_in_cb_count == 1 && cancel_in_cb_query) {
        pj_dns_async_query *q = cancel_in_cb_query;
        cancel_in_cb_query = NULL;
        cancel_in_cb_cancelled = PJ_TRUE;
        pj_dns_resolver_cancel_query(q, PJ_TRUE);
    }

    pj_sem_post(sem);
}


/* Cancelling a query from inside its own completion callback must not deliver
 * the callback a second time (the cb is captured and cleared under the lock
 * before it is invoked). Asserts the callback runs exactly once.
 */
static int dns_cancel_in_callback_test(void)
{
    pj_str_t name = pj_str("name_cancel_in_cb");

    PJ_LOG(3,(THIS_FILE, "  cancel query from within its callback test"));

    cancel_in_cb_count = 0;
    cancel_in_cb_query = NULL;
    cancel_in_cb_cancelled = PJ_FALSE;

    /* Servers answer so the query completes and the callback fires. */
    g_server[0].action = PJ_DNS_RCODE_NXDOMAIN;
    g_server[1].action = PJ_DNS_RCODE_NXDOMAIN;

    PJ_TEST_SUCCESS(pj_dns_resolver_start_query(
                        resolver, &name, PJ_DNS_TYPE_A, 0,
                        &dns_callback_cancel_in_cb, NULL, &cancel_in_cb_query),
                    NULL, return -670);

    pj_sem_wait(sem);

    /* Guard against a vacuous pass: the assertions below only pin the
     * behavior if the cancel actually ran inside the callback.
     */
    PJ_TEST_EQ(cancel_in_cb_cancelled, PJ_TRUE, NULL, return -672);
    PJ_TEST_EQ(cancel_in_cb_count, 1, NULL, return -674);

    return 0;
}


/* Same as dns_callback_cancel_in_cb, but for the timeout variant below. */
static void dns_callback_cancel_in_tocb(void *user_data,
                                        pj_status_t status,
                                        pj_dns_parsed_packet *resp)
{
    PJ_UNUSED_ARG(user_data);
    PJ_UNUSED_ARG(resp);

    cancel_in_tocb_count++;

    if (cancel_in_tocb_count == 1) {
        cancel_in_tocb_status = status;
        if (cancel_in_tocb_query) {
            pj_dns_async_query *q = cancel_in_tocb_query;
            cancel_in_tocb_query = NULL;
            cancel_in_tocb_cancelled = PJ_TRUE;
            pj_dns_resolver_cancel_query(q, PJ_TRUE);
        }
    }

    pj_sem_post(sem);
}


/* Same as dns_cancel_in_callback_test, but through the timeout path: the
 * servers do not respond, so the callback is delivered by on_timeout()
 * rather than on_read_complete(). Uses a dedicated resolver with short
 * retransmission settings to keep the timeout fast.
 */
static int dns_cancel_in_timeout_callback_test(void)
{
    pj_str_t name = pj_str("name_cancel_in_tocb");
    pj_str_t nameservers[2];
    pj_uint16_t ports[2];
    pj_dns_settings lset;
    pj_dns_resolver *res;

    PJ_LOG(3,(THIS_FILE, "  cancel query from within its timeout callback test"));

    cancel_in_tocb_count = 0;
    cancel_in_tocb_query = NULL;
    cancel_in_tocb_cancelled = PJ_FALSE;
    cancel_in_tocb_status = PJ_SUCCESS;

    /* Servers ignore the query so it times out. */
    g_server[0].action = ACTION_IGNORE;
    g_server[1].action = ACTION_IGNORE;

    nameservers[0] = nameservers[1] = pj_str("127.0.0.1");
    ports[0] = g_server[0].port;
    ports[1] = g_server[1].port;

    PJ_TEST_SUCCESS(pj_dns_resolver_create(mem, NULL, 0, timer_heap, ioqueue,
                                           &res),
                    NULL, return -650);
    PJ_TEST_SUCCESS(pj_dns_resolver_set_ns(res, 2, nameservers, ports),
                    NULL, return -651);

    pj_dns_resolver_get_settings(res, &lset);
    lset.qretr_delay = 200;
    lset.qretr_count = 1;
    PJ_TEST_SUCCESS(pj_dns_resolver_set_settings(res, &lset),
                    NULL, return -652);

    PJ_TEST_SUCCESS(pj_dns_resolver_start_query(
                        res, &name, PJ_DNS_TYPE_A, 0,
                        &dns_callback_cancel_in_tocb, NULL,
                        &cancel_in_tocb_query),
                    NULL, return -653);

    pj_sem_wait(sem);

    PJ_TEST_EQ(cancel_in_tocb_status, PJ_ETIMEDOUT, NULL, return -654);
    PJ_TEST_EQ(cancel_in_tocb_cancelled, PJ_TRUE, NULL, return -655);
    PJ_TEST_EQ(cancel_in_tocb_count, 1, NULL, return -656);

    pj_dns_resolver_destroy(res, PJ_FALSE);

    return 0;
}


static void dns_callback_cancel_child_parent(void *user_data,
                                             pj_status_t status,
                                             pj_dns_parsed_packet *resp)
{
    PJ_UNUSED_ARG(user_data);
    PJ_UNUSED_ARG(status);
    PJ_UNUSED_ARG(resp);

    cancel_child_parent_count++;

    pj_sem_post(sem);
}

/* Callback of the coalesced child query; cancels its own query on the first
 * delivery, like dns_callback_cancel_in_cb.
 */
static void dns_callback_cancel_child(void *user_data,
                                      pj_status_t status,
                                      pj_dns_parsed_packet *resp)
{
    PJ_UNUSED_ARG(user_data);
    PJ_UNUSED_ARG(resp);

    cancel_child_child_count++;

    if (cancel_child_child_count == 1) {
        cancel_child_status = status;
        if (cancel_child_query) {
            pj_dns_async_query *q = cancel_child_query;
            cancel_child_query = NULL;
            cancel_child_cancelled = PJ_TRUE;
            pj_dns_resolver_cancel_query(q, PJ_TRUE);
        }
    }

    pj_sem_post(sem);
}


/* Same again, but cancelling a coalesced CHILD query from inside its own
 * callback, to cover the child (ccb) capture loop. The servers ignore the
 * query, so the parent stays pending in the resolver's hash tables until
 * its timeout fires; the second start_query() below is therefore guaranteed
 * to join it as a child, and both callbacks are delivered by the same
 * on_timeout() pass.
 */
static int dns_cancel_child_in_callback_test(void)
{
    pj_str_t name = pj_str("name_cancel_child_tocb");
    pj_str_t nameservers[2];
    pj_uint16_t ports[2];
    pj_dns_settings lset;
    pj_dns_resolver *res;

    PJ_LOG(3,(THIS_FILE, "  cancel child query from within its callback test"));

    cancel_child_parent_count = 0;
    cancel_child_child_count = 0;
    cancel_child_query = NULL;
    cancel_child_cancelled = PJ_FALSE;
    cancel_child_status = PJ_SUCCESS;

    /* Servers ignore the query so it times out. */
    g_server[0].action = ACTION_IGNORE;
    g_server[1].action = ACTION_IGNORE;

    nameservers[0] = nameservers[1] = pj_str("127.0.0.1");
    ports[0] = g_server[0].port;
    ports[1] = g_server[1].port;

    PJ_TEST_SUCCESS(pj_dns_resolver_create(mem, NULL, 0, timer_heap, ioqueue,
                                           &res),
                    NULL, return -660);
    PJ_TEST_SUCCESS(pj_dns_resolver_set_ns(res, 2, nameservers, ports),
                    NULL, return -661);

    pj_dns_resolver_get_settings(res, &lset);
    lset.qretr_delay = 200;
    lset.qretr_count = 1;
    PJ_TEST_SUCCESS(pj_dns_resolver_set_settings(res, &lset),
                    NULL, return -662);

    PJ_TEST_SUCCESS(pj_dns_resolver_start_query(
                        res, &name, PJ_DNS_TYPE_A, 0,
                        &dns_callback_cancel_child_parent, NULL, NULL),
                    NULL, return -663);
    PJ_TEST_SUCCESS(pj_dns_resolver_start_query(
                        res, &name, PJ_DNS_TYPE_A, 0,
                        &dns_callback_cancel_child, NULL,
                        &cancel_child_query),
                    NULL, return -664);

    /* One delivery for the parent, one for the child. */
    pj_sem_wait(sem);
    pj_sem_wait(sem);

    PJ_TEST_EQ(cancel_child_status, PJ_ETIMEDOUT, NULL, return -665);
    PJ_TEST_EQ(cancel_child_cancelled, PJ_TRUE, NULL, return -666);
    PJ_TEST_EQ(cancel_child_child_count, 1, NULL, return -667);
    PJ_TEST_EQ(cancel_child_parent_count, 1, NULL, return -668);

    pj_dns_resolver_destroy(res, PJ_FALSE);

    return 0;
}



/* Probe thread for the cancel-unlocked test: once the callback signals that
 * it is running, take the resolver group lock through a read-only API. This
 * blocks until the callback returns if the callback still holds the lock.
 */
static int cancel_unlocked_probe_thread(void *arg)
{
    pj_dns_settings lset;

    PJ_UNUSED_ARG(arg);

    pj_sem_wait(cancel_unlocked_entered);
    pj_dns_resolver_get_settings(cancel_unlocked_res, &lset);
    pj_sem_post(cancel_unlocked_probed);

    return 0;
}


/* Callback delivered by pj_dns_resolver_cancel_query(): signals the probe
 * thread, then waits for it to acquire the resolver lock. The probe can only
 * succeed while this callback is running if the lock was released before the
 * callback was invoked.
 */
static void dns_callback_cancel_unlocked(void *user_data,
                                         pj_status_t status,
                                         pj_dns_parsed_packet *resp)
{
    unsigned i;

    PJ_UNUSED_ARG(user_data);
    PJ_UNUSED_ARG(status);
    PJ_UNUSED_ARG(resp);

    cancel_unlocked_count++;

    pj_sem_post(cancel_unlocked_entered);

    /* Bounded wait, so the test fails rather than hangs when the callback
     * is invoked under the lock.
     */
    for (i=0; i<500; ++i) {
        if (pj_sem_trywait(cancel_unlocked_probed) == PJ_SUCCESS) {
            cancel_unlocked_probe_seen = PJ_TRUE;
            break;
        }
        pj_thread_sleep(10);
    }
}


/* pj_dns_resolver_cancel_query() must invoke the application callback with
 * the group lock released, as every other delivery site does, so that a
 * callback re-entering the resolver or taking another lock cannot deadlock
 * or invert the lock order.
 */
static int dns_cancel_unlocked_test(void)
{
    pj_str_t name = pj_str("name_cancel_unlocked");
    pj_str_t nameservers[2];
    pj_uint16_t ports[2];
    pj_dns_async_query *q = NULL;
    pj_thread_t *probe = NULL;

    PJ_LOG(3,(THIS_FILE, "  cancel query delivers callback unlocked test"));

    cancel_unlocked_count = 0;
    cancel_unlocked_probe_seen = PJ_FALSE;

    /* Servers ignore the query so it stays pending until cancelled. */
    g_server[0].action = ACTION_IGNORE;
    g_server[1].action = ACTION_IGNORE;

    nameservers[0] = nameservers[1] = pj_str("127.0.0.1");
    ports[0] = g_server[0].port;
    ports[1] = g_server[1].port;

    PJ_TEST_SUCCESS(pj_dns_resolver_create(mem, NULL, 0, timer_heap, ioqueue,
                                           &cancel_unlocked_res),
                    NULL, return -760);
    PJ_TEST_SUCCESS(pj_dns_resolver_set_ns(cancel_unlocked_res, 2,
                                           nameservers, ports),
                    NULL, return -761);

    PJ_TEST_SUCCESS(pj_sem_create(pool, NULL, 0, 1, &cancel_unlocked_entered),
                    NULL, return -762);
    PJ_TEST_SUCCESS(pj_sem_create(pool, NULL, 0, 1, &cancel_unlocked_probed),
                    NULL, return -763);
    PJ_TEST_SUCCESS(pj_thread_create(pool, NULL, &cancel_unlocked_probe_thread,
                                     NULL, 0, 0, &probe),
                    NULL, return -764);

    PJ_TEST_SUCCESS(pj_dns_resolver_start_query(
                        cancel_unlocked_res, &name, PJ_DNS_TYPE_A, 0,
                        &dns_callback_cancel_unlocked, NULL, &q),
                    NULL, return -765);

    pj_dns_resolver_cancel_query(q, PJ_TRUE);

    pj_thread_join(probe);
    pj_thread_destroy(probe);
    pj_sem_destroy(cancel_unlocked_entered);
    pj_sem_destroy(cancel_unlocked_probed);
    pj_dns_resolver_destroy(cancel_unlocked_res, PJ_FALSE);

    /* The cancelled query was already on the wire. Let the servers consume it
     * while they are still ignoring, so that it is not mistaken for the first
     * query of whichever test installs an action_cb next.
     */
    pj_thread_sleep(1000);

    PJ_TEST_EQ(cancel_unlocked_count, 1, NULL, return -766);
    PJ_TEST_EQ(cancel_unlocked_probe_seen, PJ_TRUE, NULL, return -767);

    return 0;
}

/* DNS test */
static int dns_test(void)
{
    pj_str_t name = pj_str("name00");
    enum { D = 2 };

    PJ_LOG(3,(THIS_FILE, "  simple error response test"));

    g_server[0].pkt_count = 0;
    g_server[1].pkt_count = 0;

    g_server[0].action = PJ_DNS_RCODE_NXDOMAIN;
    g_server[1].action = PJ_DNS_RCODE_NXDOMAIN;

    PJ_TEST_SUCCESS(pj_dns_resolver_start_query(
                        resolver, &name, PJ_DNS_TYPE_A, 0,
                        &dns_callback_1b, NULL, NULL),
                    NULL, return -400);

    pj_sem_wait(sem);
    pj_thread_sleep(1000);

    /* Now only one of the servers should get packet, since both servers are
     * in STATE_ACTIVE state
     */
    PJ_TEST_EQ(g_server[0].pkt_count + g_server[1].pkt_count, 1,
               NULL, return -410);

    /* Wait to allow active period to complete and get into probing state */
    PJ_LOG(3,(THIS_FILE, "  waiting for active NS to expire (%d sec)",
                         set.good_ns_ttl));
    pj_thread_sleep((set.good_ns_ttl+D) * 1000);

    /* 
     * Fail-over test 
     */
    PJ_LOG(3,(THIS_FILE, "  failing server0"));
    g_server[0].action = ACTION_IGNORE;
    g_server[1].action = PJ_DNS_RCODE_NXDOMAIN;

    g_server[0].pkt_count = 0;
    g_server[1].pkt_count = 0;

    name = pj_str("name01");
    PJ_TEST_SUCCESS(pj_dns_resolver_start_query(
                            resolver, &name, PJ_DNS_TYPE_A, 0,
                            &dns_callback_1b, NULL, NULL),
                    NULL, return -420);

    pj_sem_wait(sem);

    /* Both servers must get packet as both are in probing state */
    PJ_TEST_GTE(g_server[0].pkt_count, 1, NULL, return -430);
    PJ_TEST_EQ(g_server[1].pkt_count, 1, NULL, return -435);

    /*
     * Check that both servers still receive requests, since they are
     * in probing & active state.
     */
    PJ_LOG(3,(THIS_FILE, "  checking both NS during probing period"));
    g_server[0].action = ACTION_IGNORE;
    g_server[1].action = PJ_DNS_RCODE_NXDOMAIN;

    g_server[0].pkt_count = 0;
    g_server[1].pkt_count = 0;

    name = pj_str("name02");
    PJ_TEST_SUCCESS(pj_dns_resolver_start_query(
                            resolver, &name, PJ_DNS_TYPE_A, 0,
                            &dns_callback_1b, NULL, NULL),
                    NULL, return -440);

    pj_sem_wait(sem);
    pj_thread_sleep(1000);

    /* Both servers must get packet as both are in probing & active state */
    PJ_TEST_GTE(g_server[0].pkt_count, 1, NULL, return -450);
    PJ_TEST_EQ(g_server[1].pkt_count, 1, NULL, return -454);

    /* Wait to allow probing period to complete, server 0 will be in bad state */
    PJ_LOG(3,(THIS_FILE, "  waiting for probing state to end (%d sec)",
                         set.qretr_delay * 
                         (set.qretr_count+2) / 1000));
    pj_thread_sleep(1000 + set.qretr_delay * (set.qretr_count + 2));


    /*
     * Now only server 1 should get requests.
     */
    PJ_LOG(3,(THIS_FILE, "  verifying only good NS is used"));
    g_server[0].action = PJ_DNS_RCODE_NXDOMAIN;
    g_server[1].action = PJ_DNS_RCODE_NXDOMAIN;

    g_server[0].pkt_count = 0;
    g_server[1].pkt_count = 0;

    name = pj_str("name03");
    PJ_TEST_SUCCESS(pj_dns_resolver_start_query(
                        resolver, &name, PJ_DNS_TYPE_A, 0,
                        &dns_callback_1b, NULL, NULL),
                    NULL, return -460);

    pj_sem_wait(sem);
    pj_thread_sleep(1000);

    /* Only server 1 get the request */
    PJ_TEST_EQ(g_server[0].pkt_count, 0, NULL, return -470);
    PJ_TEST_EQ(g_server[1].pkt_count, 1, NULL, return -474);

    /* Wait to allow active & bad period to complete, both will be in probing state */
    PJ_LOG(3,(THIS_FILE, "  waiting for active NS to expire (%d sec)",
                         set.good_ns_ttl));
    pj_thread_sleep((set.good_ns_ttl+D) * 1000);

    /*
     * Now fail server 1 to switch to server 0
     */
    g_server[0].action = PJ_DNS_RCODE_NXDOMAIN;
    g_server[1].action = ACTION_IGNORE;

    g_server[0].pkt_count = 0;
    g_server[1].pkt_count = 0;

    name = pj_str("name04");
    PJ_TEST_SUCCESS(pj_dns_resolver_start_query(
                        resolver, &name, PJ_DNS_TYPE_A, 0,
                        &dns_callback_1b, NULL, NULL),
                    NULL, return -480);

    pj_sem_wait(sem);

    /* Wait to allow probing period to complete, server 0 remains active, server 1 will be bad */
    PJ_LOG(3,(THIS_FILE, "  waiting for probing state (%d sec)",
                         set.qretr_delay * (set.qretr_count+2) / 1000));
    pj_thread_sleep(1000 + set.qretr_delay * (set.qretr_count + 2));

    /*
     * Now only server 0 should get requests.
     */
    PJ_LOG(3,(THIS_FILE, "  verifying good NS"));
    g_server[0].action = PJ_DNS_RCODE_NXDOMAIN;
    g_server[1].action = ACTION_IGNORE;

    g_server[0].pkt_count = 0;
    g_server[1].pkt_count = 0;

    name = pj_str("name05");
    PJ_TEST_SUCCESS(pj_dns_resolver_start_query(
                        resolver, &name, PJ_DNS_TYPE_A, 0,
                        &dns_callback_1b, NULL, NULL),
                    NULL, return -484);

    pj_sem_wait(sem);
    pj_thread_sleep(1000);

    /* Only good NS should get request */
    PJ_TEST_EQ(g_server[0].pkt_count, 1, NULL, return -486);
    PJ_TEST_EQ(g_server[1].pkt_count, 0, NULL, return -488);

    return 0;
}


////////////////////////////////////////////////////////////////////////////
/* Resolver test, normal, with CNAME */
#define IP_ADDR1    0x02030405
#define PORT1       50061

static void action1_1(const pj_dns_parsed_packet *pkt,
                      pj_dns_parsed_packet **p_res)
{
    pj_dns_parsed_packet *res;
    char *target = "sip.somedomain.com";

    lock();
    res = PJ_POOL_ZALLOC_T(pool, pj_dns_parsed_packet);

    if (res->q == NULL) {
        res->q = PJ_POOL_ZALLOC_T(pool, pj_dns_parsed_query);
    }
    if (res->ans == NULL) {
        res->ans = (pj_dns_parsed_rr*) 
                  pj_pool_calloc(pool, 4, sizeof(pj_dns_parsed_rr));
    }
    unlock();

    res->hdr.qdcount = 1;
    res->q[0].type = pkt->q[0].type;
    res->q[0].dnsclass = pkt->q[0].dnsclass;
    res->q[0].name = pkt->q[0].name;

    if (pkt->q[0].type == PJ_DNS_TYPE_SRV) {

        pj_assert(pj_strcmp2(&pkt->q[0].name, "_sip._udp.somedomain.com")==0);

        res->hdr.anscount = 1;
        res->ans[0].type = PJ_DNS_TYPE_SRV;
        res->ans[0].dnsclass = 1;
        res->ans[0].name = res->q[0].name;
        res->ans[0].ttl = 1;
        res->ans[0].rdata.srv.prio = 1;
        res->ans[0].rdata.srv.weight = 2;
        res->ans[0].rdata.srv.port = PORT1;
        res->ans[0].rdata.srv.target = pj_str(target);

    } else if (pkt->q[0].type == PJ_DNS_TYPE_A) {
        char *alias = "sipalias.somedomain.com";

        pj_assert(pj_strcmp2(&res->q[0].name, target)==0);

        res->hdr.anscount = 2;
        res->ans[0].type = PJ_DNS_TYPE_CNAME;
        res->ans[0].dnsclass = 1;
        res->ans[0].ttl = 1000; /* resolver should select minimum TTL */
        res->ans[0].name = res->q[0].name;
        res->ans[0].rdata.cname.name = pj_str(alias);

        res->ans[1].type = PJ_DNS_TYPE_A;
        res->ans[1].dnsclass = 1;
        res->ans[1].ttl = 1;
        res->ans[1].name = pj_str(alias);
        res->ans[1].rdata.a.ip_addr.s_addr = IP_ADDR1;

    } else if (pkt->q[0].type == PJ_DNS_TYPE_AAAA) {
        char *alias = "sipalias.somedomain.com";

        pj_assert(pj_strcmp2(&res->q[0].name, target)==0);

        res->hdr.anscount = 2;
        res->ans[0].type = PJ_DNS_TYPE_CNAME;
        res->ans[0].dnsclass = 1;
        res->ans[0].ttl = 1000; /* resolver should select minimum TTL */
        res->ans[0].name = res->q[0].name;
        res->ans[0].rdata.cname.name = pj_str(alias);

        res->ans[1].type = PJ_DNS_TYPE_AAAA;
        res->ans[1].dnsclass = 1;
        res->ans[1].ttl = 1;
        res->ans[1].name = pj_str(alias);
        s6_addr32(res->ans[1].rdata.aaaa.ip_addr, 0) = IP_ADDR1;
        s6_addr32(res->ans[1].rdata.aaaa.ip_addr, 1) = IP_ADDR1;
        s6_addr32(res->ans[1].rdata.aaaa.ip_addr, 2) = IP_ADDR1;
        s6_addr32(res->ans[1].rdata.aaaa.ip_addr, 3) = IP_ADDR1;
    }

    *p_res = res;
}

static void srv_cb_1(void *user_data,
                     pj_status_t status,
                     const pj_dns_srv_record *rec)
{
    PJ_UNUSED_ARG(user_data);

    pj_sem_post(sem);

    PJ_ASSERT_ON_FAIL(status == PJ_SUCCESS, return);
    PJ_ASSERT_ON_FAIL(rec->count == 1, return);
    PJ_ASSERT_ON_FAIL(rec->entry[0].priority == 1, return);
    PJ_ASSERT_ON_FAIL(rec->entry[0].weight == 2, return);
    PJ_ASSERT_ON_FAIL(pj_strcmp2(&rec->entry[0].server.name, "sip.somedomain.com")==0,
                      return);
    PJ_ASSERT_ON_FAIL(pj_strcmp2(&rec->entry[0].server.alias, "sipalias.somedomain.com")==0,
                      return);

    /* IPv4 only */
    PJ_ASSERT_ON_FAIL(rec->entry[0].server.addr_count == 1, return);
    PJ_ASSERT_ON_FAIL(rec->entry[0].server.addr[0].ip.v4.s_addr == IP_ADDR1, return);
    PJ_ASSERT_ON_FAIL(rec->entry[0].port == PORT1, return);

    
}


static void srv_cb_1b(void *user_data,
                      pj_status_t status,
                      const pj_dns_srv_record *rec)
{
    PJ_UNUSED_ARG(user_data);

    pj_sem_post(sem);

    PJ_ASSERT_ON_FAIL(status==PJ_STATUS_FROM_DNS_RCODE(PJ_DNS_RCODE_NXDOMAIN),
                      return);
    PJ_ASSERT_ON_FAIL(rec->count == 0, return);
}


static void srv_cb_1c(void *user_data,
                      pj_status_t status,
                      const pj_dns_srv_record *rec)
{
    PJ_UNUSED_ARG(user_data);

    pj_sem_post(sem);

    PJ_ASSERT_ON_FAIL(status == PJ_SUCCESS, return);
    PJ_ASSERT_ON_FAIL(rec->count == 1, return);
    PJ_ASSERT_ON_FAIL(rec->entry[0].priority == 1, return);
    PJ_ASSERT_ON_FAIL(rec->entry[0].weight == 2, return);

    PJ_ASSERT_ON_FAIL(pj_strcmp2(&rec->entry[0].server.name, "sip.somedomain.com")==0,
                      return);
    PJ_ASSERT_ON_FAIL(pj_strcmp2(&rec->entry[0].server.alias, "sipalias.somedomain.com")==0,
                      return);
    PJ_ASSERT_ON_FAIL(rec->entry[0].port == PORT1, return);

    /* IPv4 and IPv6 */
    PJ_ASSERT_ON_FAIL(rec->entry[0].server.addr_count == 2, return);
    PJ_ASSERT_ON_FAIL(rec->entry[0].server.addr[0].af == pj_AF_INET() &&
                      rec->entry[0].server.addr[0].ip.v4.s_addr == IP_ADDR1, return);
    PJ_ASSERT_ON_FAIL(rec->entry[0].server.addr[1].af == pj_AF_INET6() &&
                      s6_addr32(rec->entry[0].server.addr[1].ip.v6, 0) == IP_ADDR1, return);
}


static void srv_cb_1d(void *user_data,
                      pj_status_t status,
                      const pj_dns_srv_record *rec)
{
    PJ_UNUSED_ARG(user_data);

    pj_sem_post(sem);

    PJ_ASSERT_ON_FAIL(status == PJ_SUCCESS, return);
    PJ_ASSERT_ON_FAIL(rec->count == 1, return);
    PJ_ASSERT_ON_FAIL(rec->entry[0].priority == 1, return);
    PJ_ASSERT_ON_FAIL(rec->entry[0].weight == 2, return);

    PJ_ASSERT_ON_FAIL(pj_strcmp2(&rec->entry[0].server.name, "sip.somedomain.com")==0,
                      return);
    PJ_ASSERT_ON_FAIL(pj_strcmp2(&rec->entry[0].server.alias, "sipalias.somedomain.com")==0,
                      return);
    PJ_ASSERT_ON_FAIL(rec->entry[0].port == PORT1, return);

    /* IPv6 only */
    PJ_ASSERT_ON_FAIL(rec->entry[0].server.addr_count == 1, return);
    PJ_ASSERT_ON_FAIL(rec->entry[0].server.addr[0].af == pj_AF_INET6() &&
                      s6_addr32(rec->entry[0].server.addr[0].ip.v6, 0) == IP_ADDR1, return);
}


static int srv_resolver_test(void)
{
    pj_str_t domain = pj_str("somedomain.com");
    pj_str_t res_name = pj_str("_sip._udp.");

    /* Last servers state: server 0=active, server 1=bad*/

    /* Successful scenario */
    PJ_LOG(3,(THIS_FILE, "  srv_resolve(): success scenario"));

    g_server[0].action = ACTION_CB;
    g_server[0].action_cb = &action1_1;
    g_server[1].action = ACTION_CB;
    g_server[1].action_cb = &action1_1;

    g_server[0].pkt_count = 0;
    g_server[1].pkt_count = 0;

    PJ_TEST_SUCCESS(pj_dns_srv_resolve(
                        &domain, &res_name, 5061, pool, resolver, PJ_TRUE,
                        NULL, &srv_cb_1, NULL),
                    NULL, return -500);

    pj_sem_wait(sem);

    /* Because of previous tests, only NS 1 should get the request */
    PJ_TEST_EQ(g_server[0].pkt_count, 2, NULL, return -510);  /* 2 because of SRV and A resolution */
    PJ_TEST_EQ(g_server[1].pkt_count, 0, NULL, return -512);


    /* Wait until cache expires */
    PJ_LOG(3,(THIS_FILE, "  waiting for cache to expire (~1 secs).."));
    pj_thread_sleep(1000 + 100);


    /* DNS SRV option PJ_DNS_SRV_RESOLVE_AAAA */
    PJ_LOG(3,(THIS_FILE, "  srv_resolve(): option PJ_DNS_SRV_RESOLVE_AAAA"));

    g_server[0].action = ACTION_CB;
    g_server[0].action_cb = &action1_1;
    g_server[1].action = ACTION_CB;
    g_server[1].action_cb = &action1_1;

    g_server[0].pkt_count = 0;
    g_server[1].pkt_count = 0;

    PJ_TEST_SUCCESS(pj_dns_srv_resolve(
                        &domain, &res_name, 5061, pool, resolver,
                        PJ_DNS_SRV_RESOLVE_AAAA,
                        NULL, &srv_cb_1c, NULL),
                    NULL, return -520);

    pj_sem_wait(sem);
    pj_thread_sleep(1000);

    /* DNS SRV option PJ_DNS_SRV_RESOLVE_AAAA_ONLY */
    PJ_LOG(3,(THIS_FILE, "  srv_resolve(): option PJ_DNS_SRV_RESOLVE_AAAA_ONLY"));

    g_server[0].action = ACTION_CB;
    g_server[0].action_cb = &action1_1;
    g_server[1].action = ACTION_CB;
    g_server[1].action_cb = &action1_1;

    g_server[0].pkt_count = 0;
    g_server[1].pkt_count = 0;

    PJ_TEST_SUCCESS(pj_dns_srv_resolve(
                        &domain, &res_name, 5061, pool, resolver,
                        PJ_DNS_SRV_RESOLVE_AAAA_ONLY,
                        NULL, &srv_cb_1d, NULL),
                    NULL, return -530);

    pj_sem_wait(sem);
    pj_thread_sleep(1000);


    /* Successful scenario */
    PJ_LOG(3,(THIS_FILE, "  srv_resolve(): parallel queries"));
    g_server[0].pkt_count = 0;
    g_server[1].pkt_count = 0;

    PJ_TEST_SUCCESS(pj_dns_srv_resolve(
                        &domain, &res_name, 5061, pool, resolver, PJ_TRUE,
                        NULL, &srv_cb_1, NULL),
                    NULL, return -540);


    PJ_TEST_SUCCESS(pj_dns_srv_resolve(
                        &domain, &res_name, 5061, pool, resolver, PJ_TRUE,
                        NULL, &srv_cb_1, NULL),
                    NULL, return -550);

    pj_sem_wait(sem);
    pj_sem_wait(sem);

    /* Only server one should get a query */
    PJ_TEST_EQ(g_server[0].pkt_count, 2, NULL, return -554);  /* 2 because of SRV and A resolution */
    PJ_TEST_EQ(g_server[1].pkt_count, 0, NULL, return -556);

    /* Since TTL is one, subsequent queries should fail */
    PJ_LOG(3,(THIS_FILE, "  srv_resolve(): cache expires scenario"));

    pj_thread_sleep(1000 + 100);

    g_server[0].action = PJ_DNS_RCODE_NXDOMAIN;
    g_server[1].action = PJ_DNS_RCODE_NXDOMAIN;

    PJ_TEST_SUCCESS(pj_dns_srv_resolve(
                        &domain, &res_name, 5061, pool, resolver, PJ_TRUE,
                        NULL, &srv_cb_1b, NULL),
                    NULL, return -560);

    pj_sem_wait(sem);
    pj_thread_sleep(1000);

    return 0;
}


////////////////////////////////////////////////////////////////////////////
/* Fallback because there's no SRV in answer */
#define TARGET      "domain2.com"
#define IP_ADDR2    0x02030405
#define PORT2       50062

static void action2_1(const pj_dns_parsed_packet *pkt,
                      pj_dns_parsed_packet **p_res)
{
    pj_dns_parsed_packet *res;

    lock();
    res = PJ_POOL_ZALLOC_T(pool, pj_dns_parsed_packet);

    res->q = PJ_POOL_ZALLOC_T(pool, pj_dns_parsed_query);
    res->ans = (pj_dns_parsed_rr*) 
               pj_pool_calloc(pool, 4, sizeof(pj_dns_parsed_rr));
    unlock();

    res->hdr.qdcount = 1;
    res->q[0].type = pkt->q[0].type;
    res->q[0].dnsclass = pkt->q[0].dnsclass;
    res->q[0].name = pkt->q[0].name;

    if (pkt->q[0].type == PJ_DNS_TYPE_SRV) {

        pj_assert(pj_strcmp2(&pkt->q[0].name, "_sip._udp." TARGET)==0);

        res->hdr.anscount = 1;
        res->ans[0].type = PJ_DNS_TYPE_A;    // <-- this will cause the fallback
        res->ans[0].dnsclass = 1;
        res->ans[0].name = res->q[0].name;
        res->ans[0].ttl = 1;
        res->ans[0].rdata.srv.prio = 1;
        res->ans[0].rdata.srv.weight = 2;
        res->ans[0].rdata.srv.port = PORT2;
        res->ans[0].rdata.srv.target = pj_str("sip01." TARGET);

    } else if (pkt->q[0].type == PJ_DNS_TYPE_A) {
        char *alias = "sipalias01." TARGET;

        pj_assert(pj_strcmp2(&res->q[0].name, TARGET)==0);

        res->hdr.anscount = 2;
        res->ans[0].type = PJ_DNS_TYPE_CNAME;
        res->ans[0].dnsclass = 1;
        res->ans[0].name = res->q[0].name;
        res->ans[0].ttl = 1;
        res->ans[0].rdata.cname.name = pj_str(alias);

        res->ans[1].type = PJ_DNS_TYPE_A;
        res->ans[1].dnsclass = 1;
        res->ans[1].name = pj_str(alias);
        res->ans[1].ttl = 1;
        res->ans[1].rdata.a.ip_addr.s_addr = IP_ADDR2;

    } else if (pkt->q[0].type == PJ_DNS_TYPE_AAAA) {
        char *alias = "sipalias01." TARGET;

        pj_assert(pj_strcmp2(&res->q[0].name, TARGET)==0);

        res->hdr.anscount = 2;
        res->ans[0].type = PJ_DNS_TYPE_CNAME;
        res->ans[0].dnsclass = 1;
        res->ans[0].name = res->q[0].name;
        res->ans[0].ttl = 1;
        res->ans[0].rdata.cname.name = pj_str(alias);

        res->ans[1].type = PJ_DNS_TYPE_AAAA;
        res->ans[1].dnsclass = 1;
        res->ans[1].ttl = 1;
        res->ans[1].name = pj_str(alias);
        s6_addr32(res->ans[1].rdata.aaaa.ip_addr, 0) = IP_ADDR2;
        s6_addr32(res->ans[1].rdata.aaaa.ip_addr, 1) = IP_ADDR2;
        s6_addr32(res->ans[1].rdata.aaaa.ip_addr, 2) = IP_ADDR2;
        s6_addr32(res->ans[1].rdata.aaaa.ip_addr, 3) = IP_ADDR2;
    }

    *p_res = res;
}

#define SRV_CB_CHECK(cond, err) if(!(cond)) { *cb_err=err; goto on_return; }

static void srv_cb_2(void *user_data,
                     pj_status_t status,
                     const pj_dns_srv_record *rec)
{
    int *cb_err = (int*)user_data;

    SRV_CB_CHECK(status == PJ_SUCCESS, -10);
    SRV_CB_CHECK(rec->count == 1, -20);
    SRV_CB_CHECK(rec->entry[0].priority == 0, -30);
    SRV_CB_CHECK(rec->entry[0].weight == 0, -40);
    SRV_CB_CHECK(pj_strcmp2(&rec->entry[0].server.name, TARGET)==0, -50);
    SRV_CB_CHECK(pj_strcmp2(&rec->entry[0].server.alias,
                            "sipalias01." TARGET)==0, -60);
    SRV_CB_CHECK(rec->entry[0].port == PORT2, -70);

    /* IPv4 only */
    SRV_CB_CHECK(rec->entry[0].server.addr_count == 1, -80);
    SRV_CB_CHECK(rec->entry[0].server.addr[0].af == pj_AF_INET() &&
                 rec->entry[0].server.addr[0].ip.v4.s_addr == IP_ADDR2, -90);

on_return:
    pj_sem_post(sem);
}

static void srv_cb_2a(void *user_data,
                      pj_status_t status,
                      const pj_dns_srv_record *rec)
{
    int *cb_err = (int*)user_data;

    SRV_CB_CHECK(status == PJ_SUCCESS, -10);
    SRV_CB_CHECK(rec->count == 1, -20);
    SRV_CB_CHECK(rec->entry[0].priority == 0, -30);
    SRV_CB_CHECK(rec->entry[0].weight == 0, -40);
    SRV_CB_CHECK(pj_strcmp2(&rec->entry[0].server.name, TARGET)==0, -50);
    SRV_CB_CHECK(pj_strcmp2(&rec->entry[0].server.alias,
                            "sipalias01." TARGET)==0, -60);
    SRV_CB_CHECK(rec->entry[0].port == PORT2, -70);

    /* IPv4 and IPv6 */
    SRV_CB_CHECK(rec->entry[0].server.addr_count == 2, -80);
    SRV_CB_CHECK(rec->entry[0].server.addr[0].af == pj_AF_INET() &&
                 rec->entry[0].server.addr[0].ip.v4.s_addr == IP_ADDR2, -90);
    SRV_CB_CHECK(rec->entry[0].server.addr[1].af == pj_AF_INET6() &&
                 s6_addr32(rec->entry[0].server.addr[1].ip.v6, 0) == IP_ADDR2,
                 -100);

on_return:
    pj_sem_post(sem);
}

static void srv_cb_2b(void *user_data,
                      pj_status_t status,
                      const pj_dns_srv_record *rec)
{
    int *cb_err = (int*)user_data;

    SRV_CB_CHECK(status == PJ_SUCCESS, -10);
    SRV_CB_CHECK(rec->count == 1, -20);
    SRV_CB_CHECK(rec->entry[0].priority == 0, -30);
    SRV_CB_CHECK(rec->entry[0].weight == 0, -40);
    SRV_CB_CHECK(pj_strcmp2(&rec->entry[0].server.name, TARGET)==0, -50);
    SRV_CB_CHECK(pj_strcmp2(&rec->entry[0].server.alias,
                            "sipalias01." TARGET)==0, -60);
    SRV_CB_CHECK(rec->entry[0].port == PORT2, -70);

    /* IPv6 only */
    SRV_CB_CHECK(rec->entry[0].server.addr_count == 1, -80);
    SRV_CB_CHECK(rec->entry[0].server.addr[0].af == pj_AF_INET6() &&
                 s6_addr32(rec->entry[0].server.addr[0].ip.v6, 0) == IP_ADDR2,
                 -90);

on_return:
    pj_sem_post(sem);
}

static int srv_resolver_fallback_test(void)
{
    pj_str_t domain = pj_str(TARGET);
    pj_str_t res_name = pj_str("_sip._udp.");
    int cb_err = 0;

    /* Fallback test */
    PJ_LOG(3,(THIS_FILE, "  srv_resolve(): fallback test"));

    g_server[0].action = ACTION_CB;
    g_server[0].action_cb = &action2_1;
    g_server[1].action = ACTION_CB;
    g_server[1].action_cb = &action2_1;

    PJ_TEST_SUCCESS(pj_dns_srv_resolve(
                        &domain, &res_name, PORT2, pool, resolver, PJ_TRUE,
                        &cb_err, &srv_cb_2, NULL),
                    NULL, return -600);

    pj_sem_wait(sem);

    PJ_TEST_EQ(cb_err, 0, "srv_resolve cb error", return -605);

    /* Subsequent query should just get the response from the cache */
    PJ_LOG(3,(THIS_FILE, "  srv_resolve(): cache test"));
    g_server[0].pkt_count = 0;
    g_server[1].pkt_count = 0;

    PJ_TEST_SUCCESS(pj_dns_srv_resolve(
                        &domain, &res_name, PORT2, pool, resolver, PJ_TRUE,
                        &cb_err, &srv_cb_2, NULL),
                    NULL, return -610);

    pj_sem_wait(sem);

    PJ_TEST_EQ(cb_err,  0, "srv_resolve cb error", return -615);

    PJ_TEST_EQ(g_server[0].pkt_count, 0, "must be from cache", return -620);
    PJ_TEST_EQ(g_server[1].pkt_count, 0, "must be from cache", return -625);

    /* Clear cache */
    pj_thread_sleep(1000);

    /* Fallback with PJ_DNS_SRV_FALLBACK_A and PJ_DNS_SRV_FALLBACK_AAAA */
    PJ_LOG(3,(THIS_FILE, "  srv_resolve(): fallback to DNS A and AAAA"));

    g_server[0].action = ACTION_CB;
    g_server[0].action_cb = &action2_1;
    g_server[1].action = ACTION_CB;
    g_server[1].action_cb = &action2_1;

    PJ_TEST_SUCCESS(pj_dns_srv_resolve(
                        &domain, &res_name, PORT2, pool, resolver,
                        PJ_DNS_SRV_FALLBACK_A | PJ_DNS_SRV_FALLBACK_AAAA,
                        &cb_err, &srv_cb_2a, NULL),
                    NULL, return -630);

    pj_sem_wait(sem);

    PJ_TEST_EQ(cb_err, 0, "srv_resolve cb error", return -635);

    /* Clear cache */
    pj_thread_sleep(1000);

    /* Fallback with PJ_DNS_SRV_FALLBACK_AAAA only */
    PJ_LOG(3,(THIS_FILE, "  srv_resolve(): fallback to DNS AAAA only"));

    g_server[0].action = ACTION_CB;
    g_server[0].action_cb = &action2_1;
    g_server[1].action = ACTION_CB;
    g_server[1].action_cb = &action2_1;

    PJ_TEST_SUCCESS(pj_dns_srv_resolve(
                        &domain, &res_name, PORT2, pool, resolver,
                        PJ_DNS_SRV_FALLBACK_AAAA,
                        &cb_err, &srv_cb_2b, NULL),
                    NULL, return -640);

    pj_sem_wait(sem);

    PJ_TEST_EQ(cb_err, 0, "srv_resolve cb error", return -645);

    /* Clear cache */
    pj_thread_sleep(1000);

    return 0;
}


////////////////////////////////////////////////////////////////////////////
/* Too many SRV or A entries */
#define DOMAIN3     "d3"
#define SRV_COUNT3  (PJ_DNS_SRV_MAX_ADDR+1)
#define A_COUNT3    (PJ_DNS_MAX_IP_IN_A_REC+1)
#define PORT3       50063
#define IP_ADDR3    0x03030303

static void action3_1(const pj_dns_parsed_packet *pkt,
                      pj_dns_parsed_packet **p_res)
{
    pj_dns_parsed_packet *res;
    unsigned i;

    lock();
    res = PJ_POOL_ZALLOC_T(pool, pj_dns_parsed_packet);

    if (res->q == NULL) {
        res->q = PJ_POOL_ZALLOC_T(pool, pj_dns_parsed_query);
    }
    unlock();

    res->hdr.qdcount = 1;
    res->q[0].type = pkt->q[0].type;
    res->q[0].dnsclass = pkt->q[0].dnsclass;
    res->q[0].name = pkt->q[0].name;

    if (pkt->q[0].type == PJ_DNS_TYPE_SRV) {

        pj_assert(pj_strcmp2(&pkt->q[0].name, "_sip._udp." DOMAIN3)==0);

        res->hdr.anscount = SRV_COUNT3;
        lock();
        res->ans = (pj_dns_parsed_rr*) 
                   pj_pool_calloc(pool, SRV_COUNT3, sizeof(pj_dns_parsed_rr));
        unlock();

        for (i=0; i<SRV_COUNT3; ++i) {
            char *target;

            res->ans[i].type = PJ_DNS_TYPE_SRV;
            res->ans[i].dnsclass = 1;
            res->ans[i].name = res->q[0].name;
            res->ans[i].ttl = 1;
            res->ans[i].rdata.srv.prio = (pj_uint16_t)i;
            res->ans[i].rdata.srv.weight = 2;
            res->ans[i].rdata.srv.port = (pj_uint16_t)(PORT3+i);

            lock();
            target = (char*)pj_pool_alloc(pool, 16);
            unlock();
            pj_ansi_snprintf(target, 16, "sip%02d." DOMAIN3, i);
            res->ans[i].rdata.srv.target = pj_str(target);
        }

    } else if (pkt->q[0].type == PJ_DNS_TYPE_A) {

        //pj_assert(pj_strcmp2(&res->q[0].name, "sip." DOMAIN3)==0);

        res->hdr.anscount = A_COUNT3;
        lock();
        res->ans = (pj_dns_parsed_rr*) 
                   pj_pool_calloc(pool, A_COUNT3, sizeof(pj_dns_parsed_rr));
        unlock();

        for (i=0; i<A_COUNT3; ++i) {
            res->ans[i].type = PJ_DNS_TYPE_A;
            res->ans[i].dnsclass = 1;
            res->ans[i].ttl = 1;
            res->ans[i].name = res->q[0].name;
            res->ans[i].rdata.a.ip_addr.s_addr = IP_ADDR3+i;
        }
    }

    *p_res = res;
}

static void srv_cb_3(void *user_data,
                     pj_status_t status,
                     const pj_dns_srv_record *rec)
{
    unsigned i;
    int *cb_err = (int*)user_data;

    PJ_UNUSED_ARG(status);
    PJ_UNUSED_ARG(rec);

    SRV_CB_CHECK(status == PJ_SUCCESS, -10);
    SRV_CB_CHECK(rec->count == PJ_DNS_SRV_MAX_ADDR, -20);

    for (i=0; i<PJ_DNS_SRV_MAX_ADDR; ++i) {
        unsigned j;

        SRV_CB_CHECK(rec->entry[i].priority == i, -30);
        SRV_CB_CHECK(rec->entry[i].weight == 2, -40);
        //pj_assert(pj_strcmp2(&rec->entry[i].server.name, "sip." DOMAIN3)==0);
        SRV_CB_CHECK(rec->entry[i].server.alias.slen == 0, -50);
        SRV_CB_CHECK(rec->entry[i].port == PORT3+i, -60);

        SRV_CB_CHECK(rec->entry[i].server.addr_count == PJ_DNS_MAX_IP_IN_A_REC, -70);

        for (j=0; j<PJ_DNS_MAX_IP_IN_A_REC; ++j) {
            SRV_CB_CHECK(rec->entry[i].server.addr[j].ip.v4.s_addr == IP_ADDR3+j, -80);
        }
    }

on_return:
    pj_sem_post(sem);
}

static int srv_resolver_many_test(void)
{
    pj_str_t domain = pj_str(DOMAIN3);
    pj_str_t res_name = pj_str("_sip._udp.");
    int cb_err = 0;

    /* Successful scenario */
    PJ_LOG(3,(THIS_FILE, "  srv_resolve(): too many entries test"));

    g_server[0].action = ACTION_CB;
    g_server[0].action_cb = &action3_1;
    g_server[1].action = ACTION_CB;
    g_server[1].action_cb = &action3_1;

    g_server[0].pkt_count = 0;
    g_server[1].pkt_count = 0;

    PJ_TEST_SUCCESS(pj_dns_srv_resolve(
                        &domain, &res_name, 1, pool, resolver, PJ_TRUE,
                        &cb_err, &srv_cb_3, NULL),
                    NULL, return -700);

    pj_sem_wait(sem);

    PJ_TEST_EQ(cb_err, 0, "srv_resolve cb error", return -710);

    return 0;
}


////////////////////////////////////////////////////////////////////////////


int resolver_test(void)
{
    int rc;
    
    PJ_LOG(3,(THIS_FILE, "init"));
    rc = init(PJ_FALSE);
    if (rc != 0)
        goto on_error;

    PJ_LOG(3,(THIS_FILE, "a_parser_test"));
    rc = a_parser_test();
    if (rc != 0)
        goto on_error;

    PJ_LOG(3,(THIS_FILE, "addr_parser_test"));
    rc = addr_parser_test();
    if (rc != 0)
        goto on_error;

    PJ_LOG(3,(THIS_FILE, "simple_test"));
    rc = simple_test();
    if (rc != 0)
        goto on_error;

    PJ_LOG(3,(THIS_FILE, "dns_test"));
    rc = dns_test();
    if (rc != 0)
        goto on_error;

    PJ_LOG(3,(THIS_FILE, "dns_cancel_in_callback_test"));
    rc = dns_cancel_in_callback_test();
    if (rc != 0)
        goto on_error;

    PJ_LOG(3,(THIS_FILE, "dns_cancel_in_timeout_callback_test"));
    rc = dns_cancel_in_timeout_callback_test();
    if (rc != 0)
        goto on_error;

    PJ_LOG(3,(THIS_FILE, "dns_cancel_child_in_callback_test"));
    rc = dns_cancel_child_in_callback_test();
    if (rc != 0)
        goto on_error;

    PJ_LOG(3,(THIS_FILE, "srv_resolver_test"));
    rc = srv_resolver_test();
    if (rc != 0)
        goto on_error;

    PJ_LOG(3,(THIS_FILE, "srv_resolver_fallback_test"));
    rc = srv_resolver_fallback_test();
    if (rc != 0)
        goto on_error;

    PJ_LOG(3,(THIS_FILE, "srv_resolver_many_test"));
    rc = srv_resolver_many_test();
    if (rc != 0)
        goto on_error;

    PJ_LOG(3,(THIS_FILE, "dns_destroy_pending_test"));
    rc = dns_destroy_pending_test();
    if (rc != 0)
        goto on_error;

    PJ_LOG(3,(THIS_FILE, "dns_cancel_unlocked_test"));
    rc = dns_cancel_unlocked_test();
    if (rc != 0)
        goto on_error;

    PJ_LOG(3,(THIS_FILE, "dns_start_during_destroy_test"));
    rc = dns_start_during_destroy_test();
    if (rc != 0)
        goto on_error;

    destroy();


#if PJ_HAS_IPV6
    /* Similar tests using IPv6 socket and without parser tests */
    PJ_LOG(3,(THIS_FILE, "Re-run DNS resolution tests using IPv6 socket"));

    rc = init(PJ_TRUE);
    if (rc != 0)
        goto on_error;

    rc = simple_test();
    if (rc != 0)
        goto on_error;

    rc = dns_test();
    if (rc != 0)
        goto on_error;

    rc = srv_resolver_test();
    if (rc != 0)
        goto on_error;

    rc = srv_resolver_fallback_test();
    if (rc != 0)
        goto on_error;

    rc = srv_resolver_many_test();
    if (rc != 0)
        goto on_error;

    destroy();
#endif

    return 0;

on_error:
    destroy();
    return rc;
}

