/* 
 * Copyright (C) 2023 Teluu Inc. (http://www.teluu.com)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
#ifndef __PJ_COMPAT_CC_CLANG_H__
#define __PJ_COMPAT_CC_CLANG_H__

/**
 * @file cc_clang.h
 * @brief Describes CLANG compiler specifics.
 */

#ifndef __clang__
#  error "This file is only for clang!"
#endif

#define PJ_CC_NAME              "clang"
#define PJ_CC_VER_1             __clang_major__
#define PJ_CC_VER_2             __clang_minor__
#define PJ_CC_VER_3             __clang_patchlevel__

#define PJ_THREAD_FUNC
#define PJ_NORETURN

#define PJ_HAS_INT64            1

#ifdef __STRICT_ANSI__
  #include <inttypes.h>
  typedef int64_t               pj_int64_t;
  typedef uint64_t              pj_uint64_t;
  #define PJ_INLINE_SPECIFIER   static __inline
  #define PJ_ATTR_NORETURN
  #define PJ_ATTR_MAY_ALIAS
#else
  typedef long long             pj_int64_t;
  typedef unsigned long long    pj_uint64_t;
  #define PJ_INLINE_SPECIFIER   static inline
  /* Apple Clang ASan crashes on longjmp/noreturn, see #4846 */
  #if defined(__has_feature) && __has_feature(address_sanitizer) && \
      defined(__APPLE__) && defined(__aarch64__)
    #define PJ_ATTR_NORETURN
  #else
    #define PJ_ATTR_NORETURN    __attribute__ ((noreturn))
  #endif
  #define PJ_ATTR_MAY_ALIAS     __attribute__((__may_alias__))
#endif

#define PJ_INT64(val)           val##LL
#define PJ_UINT64(val)          val##ULL
#define PJ_INT64_FMT            "L"


#define PJ_UNREACHED(x)

/*
 * Usage example:
 *
 * typedef struct PJ_ALIGN_DATA_PREFIX(8) a { int value; } PJ_ALIGN_DATA_SUFFIX(8) a;
 * typedef struct PJ_ALIGN_DATA(a{ int value; }, 8) a;
 *
 * Both options are equivalent, but perhaps the first is a little more readable than the second.
 */
#define PJ_ALIGN_DATA_PREFIX(alignment)
#define PJ_ALIGN_DATA_SUFFIX(alignment) __attribute__((aligned (alignment)))
#define PJ_ALIGN_DATA(declaration, alignment) PJ_ALIGN_DATA_PREFIX(alignment) declaration PJ_ALIGN_DATA_SUFFIX(alignment)

/* Alignment requirement of a type, in bytes. */
#define PJ_ALIGNOF(type)                __alignof__(type)

#endif /* __PJ_COMPAT_CC_CLANG_H__ */
