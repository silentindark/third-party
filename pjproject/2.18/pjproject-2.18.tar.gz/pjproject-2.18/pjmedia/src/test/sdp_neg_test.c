/* 
 * Copyright (C) 2008-2011 Teluu Inc. (http://www.teluu.com)
 * Copyright (C) 2003-2008 Benny Prijono <benny@prijono.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms oa the GNU General Public License as published by
 * the Free Software Foundation; either version 2 oa the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty oa
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy oa the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
#include <pjmedia/sdp.h>
#include <pjmedia/sdp_neg.h>
#include "test.h"


#define THIS_FILE   "sdp_neg_test.c"
#define START_TEST  0

enum session_type
{
    REMOTE_OFFER,
    LOCAL_OFFER,
};

struct offer_answer
{                       
    enum session_type type;            /*  LOCAL_OFFER:        REMOTE_OFFER:   */
    pj_bool_t answer_multiple_codecs;  /* answer with multiple codecs?         */
    char *sdp1;                        /* local offer          remote offer    */
    char *sdp2;                        /* remote answer        initial local   */
    char *sdp3;                        /* local active media   local answer    */
};

static struct test
{
    const char          *title;
    unsigned             offer_answer_count;
    struct offer_answer  offer_answer[4];
} test[] = 
{
    /* test 0: */
    {
        /*********************************************************************
         * RFC 3264 examples, section 10.1 (Alice's view)
         *
         * Difference from the example:
         *  - Bob's port number of the third media stream in the first answer
         *    is changed (make it different than Alice's)
         *  - in the second offer/answer exchange, Alice can't accept the
         *    additional line since she didn't specify the capability
         *    in the initial negotiator creation.
         */

        "RFC 3264 example 10.1 (Alice's view)",
        2,
        {
          {
            LOCAL_OFFER,
            PJ_FALSE,
            /* Alice sends offer: */
            "v=0\r\n"
            "o=alice 2890844526 2890844526 IN IP4 host.anywhere.com\r\n"
            "s= \r\n"
            "c=IN IP4 host.anywhere.com\r\n"
            "t=0 0\r\n"
            "m=audio 49170 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 51372 RTP/AVP 31\r\n"
            "a=rtpmap:31 H261/90000\r\n"
            "m=video 53000 RTP/AVP 32\r\n"
            "a=rtpmap:32 MPV/90000\r\n",
            /* Received Bob's answer: */
            "v=0\r\n"
            "o=bob 2890844730 2890844730 IN IP4 host.example.com\r\n"
            "s= \r\n"
            "c=IN IP4 host.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 49920 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 0 RTP/AVP 31\r\n"
            "m=video 53002 RTP/AVP 32\r\n"
            "a=rtpmap:32 MPV/90000\r\n",
            /* Alice's SDP now: */
            "v=0\r\n"
            "o=alice 2890844526 2890844526 IN IP4 host.anywhere.com\r\n"
            "s= \r\n"
            "c=IN IP4 host.anywhere.com\r\n"
            "t=0 0\r\n"
            "m=audio 49170 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 0 RTP/AVP 31\r\n"
            //"a=rtpmap:31 H261/90000\r\n"      /* <-- this is not necessary (port 0) */
            "m=video 53000 RTP/AVP 32\r\n"
            "a=rtpmap:32 MPV/90000\r\n"
          },
          {
            REMOTE_OFFER,
            PJ_FALSE,
            /* Bob wants to change his local SDP 
             * (change local port for the first stream and add new stream)
             * Received SDP from Bob:
             */
            "v=0\r\n"
            "o=bob 2890844730 2890844731 IN IP4 host.example.com\r\n"
            "s=-\r\n"
            "c=IN IP4 host.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 65422 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 0 RTP/AVP 31\r\n"
            "m=video 53002 RTP/AVP 32\r\n"
            "a=rtpmap:32 MPV/90000\r\n"
            "m=audio 51434 RTP/AVP 110\r\n"
            "a=rtpmap:110 telephone-events/8000\r\n"
            "a=recvonly\r\n",
            NULL,
            /* Alice's SDP now */
            "v=0\r\n"
            "o=alice 2890844526 2890844527 IN IP4 host.anywhere.com\r\n"
            "s= \r\n"
            "c=IN IP4 host.anywhere.com\r\n"
            "t=0 0\r\n"
            "m=audio 49170 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 0 RTP/AVP 31\r\n"
            //"a=rtpmap:31 H261/90000\r\n"      /* <-- this is not necessary (port 0) */
            "m=video 53000 RTP/AVP 32\r\n"
            "a=rtpmap:32 MPV/90000\r\n"
            "m=audio 0 RTP/AVP 110\r\n"
            /* <-- the following attributes are not necessary (port 0) */
            //"a=rtpmap:110 telephone-events/8000\r\n"
            //"a=sendonly\r\n"
          }
        }
    },

    /* test 1: */
    {
        /*********************************************************************
         * RFC 3264 examples, section 10.1. (Bob's view)
         *
         * Difference:
         *  - the SDP version in Bob's capability is changed to ver-1.
         */

        "RFC 3264 example 10.1 (Bob's view)",
        2,
        {
          {
            REMOTE_OFFER,
            PJ_FALSE,
            /* Remote offer from Alice: */
            "v=0\r\n"
            "o=alice 2890844526 2890844526 IN IP4 host.anywhere.com\r\n"
            "s= \r\n"
            "c=IN IP4 host.anywhere.com\r\n"
            "t=0 0\r\n"
            "m=audio 49170 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 51372 RTP/AVP 31\r\n"
            "a=rtpmap:31 H261/90000\r\n"
            "m=video 53000 RTP/AVP 32\r\n"
            "a=rtpmap:32 MPV/90000\r\n",
            /* Bob's capability: */
            "v=0\r\n"
            "o=bob 2890844730 2890844729 IN IP4 host.example.com\r\n"
            "s= \r\n"
            "c=IN IP4 host.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 49920 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 0 RTP/AVP 31\r\n"
            "m=video 53000 RTP/AVP 32\r\n"
            "a=rtpmap:32 MPV/90000\r\n",
            /* This's how Bob's answer should look like: */
            "v=0\r\n"
            "o=bob 2890844730 2890844730 IN IP4 host.example.com\r\n"
            "s= \r\n"
            "c=IN IP4 host.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 49920 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 0 RTP/AVP 31\r\n"
            "m=video 53000 RTP/AVP 32\r\n"
            "a=rtpmap:32 MPV/90000\r\n"
          },
          {
            LOCAL_OFFER,
            PJ_FALSE,
            /* Bob wants to change his local SDP 
             * (change local port for the first stream and add new stream)
             */
            "v=0\r\n"
            "o=bob 2890844730 2890844731 IN IP4 host.example.com\r\n"
            "s=-\r\n"
            "c=IN IP4 host.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 65422 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 0 RTP/AVP 31\r\n"
            "m=video 53000 RTP/AVP 32\r\n"
            "a=rtpmap:32 MPV/90000\r\n"
            "m=audio 51434 RTP/AVP 110\r\n"
            "a=rtpmap:110 telephone-events/8000\r\n"
            "a=recvonly\r\n",
            /* Got answer from Alice */
            "v=0\r\n"
            "o=alice 2890844526 2890844527 IN IP4 host.anywhere.com\r\n"
            "s=-\r\n"
            "c=IN IP4 host.anywhere.com\r\n"
            "t=0 0\r\n"
            "m=audio 49170 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 0 RTP/AVP 31\r\n"
            "a=rtpmap:31 H261/90000\r\n"
            "m=video 53000 RTP/AVP 32\r\n"
            "a=rtpmap:32 MPV/90000\r\n"
            "m=audio 53122 RTP/AVP 110\r\n"
            "a=rtpmap:110 telephone-events/8000\r\n"
            "a=sendonly\r\n",
            /* This is how Bob's SDP should look like after negotiation */
            "v=0\r\n"
            "o=bob 2890844730 2890844731 IN IP4 host.example.com\r\n"
            "s=-\r\n"
            "c=IN IP4 host.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 65422 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 0 RTP/AVP 31\r\n"
            "m=video 53000 RTP/AVP 32\r\n"
            "a=rtpmap:32 MPV/90000\r\n"
            "m=audio 51434 RTP/AVP 110\r\n"
            "a=rtpmap:110 telephone-events/8000\r\n"
            "a=recvonly\r\n"
          }
        }
    },

    /* test 2: */
    {
        /*********************************************************************
         * RFC 3264 examples, section 10.2.
         * This is from Alice's point of view.
         */

        "RFC 3264 example 10.2 (Alice's view)",
        2,
        {
          {
            LOCAL_OFFER,
            PJ_FALSE,
            /* The initial offer from Alice to Bob indicates a single audio 
             * stream with the three audio codecs that are available in the 
             * DSP. The stream is marked as inactive, 
             */
            "v=0\r\n"
            "o=alice 2890844526 2890844526 IN IP4 host.anywhere.com\r\n"
            "s=-\r\n"
            "c=IN IP4 host.anywhere.com\r\n"
            "t=0 0\r\n"
            "m=audio 62986 RTP/AVP 0 4 18\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "a=rtpmap:4 G723/8000\r\n"
            "a=rtpmap:18 G729/8000\r\n"
            "a=inactive\r\n",
            /* Bob can support dynamic switching between PCMU and G.723. So, 
             * he sends the following answer:
             */
            "v=0\r\n"
            "o=bob 2890844730 2890844731 IN IP4 host.example.com\r\n"
            "s=-\r\n"
            "c=IN IP4 host.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 54344 RTP/AVP 0 4\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "a=rtpmap:4 G723/8000\r\n"
            "a=inactive\r\n",
            /* This is how Alice's media should look like after negotiation */
            "v=0\r\n"
            "o=alice 2890844526 2890844526 IN IP4 host.anywhere.com\r\n"
            "s=-\r\n"
            "c=IN IP4 host.anywhere.com\r\n"
            "t=0 0\r\n"
            "m=audio 62986 RTP/AVP 0 4\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "a=rtpmap:4 G723/8000\r\n"
            "a=inactive\r\n",
          },
          {
            LOCAL_OFFER,
            PJ_FALSE,
            /* Alice sends an updated offer with a sendrecv stream: */
            "v=0\r\n"
            "o=alice 2890844526 2890844527 IN IP4 host.anywhere.com\r\n"
            "s=-\r\n"
            "c=IN IP4 host.anywhere.com\r\n"
            "t=0 0\r\n"
            "m=audio 62986 RTP/AVP 4\r\n"
            "a=rtpmap:4 G723/8000\r\n"
            "a=sendrecv\r\n",
            /* Bob accepts the single codec: */
            "v=0\r\n"
            "o=bob 2890844730 2890844732 IN IP4 host.example.com\r\n"
            "s= \r\n"
            "c=IN IP4 host.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 54344 RTP/AVP 4\r\n"
            "a=rtpmap:4 G723/8000\r\n"
            "a=sendrecv\r\n",
            /* This is how Alice's media should look like after negotiation */
            "v=0\r\n"
            "o=alice 2890844526 2890844527 IN IP4 host.anywhere.com\r\n"
            "s=-\r\n"
            "c=IN IP4 host.anywhere.com\r\n"
            "t=0 0\r\n"
            "m=audio 62986 RTP/AVP 4\r\n"
            "a=rtpmap:4 G723/8000\r\n"
            "a=sendrecv\r\n"
          }
        }
    },

#if 0
    // this test is commented, this causes error: 
    // No suitable codec for remote offer (PJMEDIA_SDPNEG_NOANSCODEC),
    // since currently the negotiator always answer with one codec, 
    // PCMU in this case, while PCMU is not included in the second offer.

    /* test 3: */
    {
        /*********************************************************************
         * RFC 3264 examples, section 10.2.
         * This is from Bob's point of view.
         *
         * Difference:
         *  - The SDP version number in Bob's initial capability is ver-1
         */

        "RFC 3264 example 10.2 (Bob's view)",
        2,
        {
          {
            REMOTE_OFFER,
            PJ_FALSE,
            /* Bob received offer from Alice:
             */
            "v=0\r\n"
            "o=alice 2890844526 2890844526 IN IP4 host.anywhere.com\r\n"
            "s=-\r\n"
            "c=IN IP4 host.anywhere.com\r\n"
            "t=0 0\r\n"
            "m=audio 62986 RTP/AVP 0 4 18\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "a=rtpmap:4 G723/8000\r\n"
            "a=rtpmap:18 G729/8000\r\n"
            "a=inactive\r\n",
            /* Bob's capability:
             */
            "v=0\r\n"
            "o=bob 2890844730 2890844730 IN IP4 host.example.com\r\n"
            "s=-\r\n"
            "c=IN IP4 host.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 54344 RTP/AVP 0 4\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "a=rtpmap:4 G723/8000\r\n"
            "a=inactive\r\n",
            /* This is how Bob's media should look like after negotiation */
            "v=0\r\n"
            "o=bob 2890844730 2890844731 IN IP4 host.example.com\r\n"
            "s=-\r\n"
            "c=IN IP4 host.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 54344 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "a=inactive\r\n"
          },
          {
            REMOTE_OFFER,
            PJ_FALSE,
            /* Received updated Alice's SDP: offer with a sendrecv stream: */
            "v=0\r\n"
            "o=alice 2890844526 2890844527 IN IP4 host.anywhere.com\r\n"
            "s=-\r\n"
            "c=IN IP4 host.anywhere.com\r\n"
            "t=0 0\r\n"
            "m=audio 62986 RTP/AVP 4\r\n"
            "a=rtpmap:4 G723/8000\r\n"
            "a=sendrecv\r\n",
            /* Bob accepts the single codec: */
            NULL,
            /* This is how Bob's media should look like after negotiation */
            "v=0\r\n"
            "o=bob 2890844730 2890844732 IN IP4 host.example.com\r\n"
            "s=-\r\n"
            "c=IN IP4 host.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 54344 RTP/AVP 4\r\n"
            "a=rtpmap:4 G723/8000\r\n"
            "a=sendrecv\r\n",
          }
        }
    },
#endif

    /* test 4: */
    {
        /*********************************************************************
         * RFC 4317 Sample 2.1: Audio and Video 1 (Alice's view)
         *
         * This common scenario shows a video and audio session in which
         * multiple codecs are offered but only one is accepted.  As a result of
         * the exchange shown below, Alice and Bob may send only PCMU audio and
         * MPV video.  Note: Dynamic payload type 97 is used for iLBC codec
         */
        "RFC 4317 section 2.1: Audio and Video 1 (Alice's view)",
        1,
        {
          {
            LOCAL_OFFER,
            PJ_FALSE,
            /* Alice's local offer: */
            "v=0\r\n"
            "o=alice 2890844526 2890844526 IN IP4 host.atlanta.example.com\r\n"
            "s=-\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 49170 RTP/AVP 0 8 97\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "a=rtpmap:8 PCMA/8000\r\n"
            "a=rtpmap:97 iLBC/8000\r\n"
            "m=video 51372 RTP/AVP 31 32\r\n"
            "a=rtpmap:31 H261/90000\r\n"
            "a=rtpmap:32 MPV/90000\r\n",
            /* Received answer from Bob: */
            "v=0\r\n"
            "o=bob 2808844564 2808844564 IN IP4 host.biloxi.example.com\r\n"
            "s=-\r\n"
            "c=IN IP4 host.biloxi.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 49174 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 49170 RTP/AVP 32\r\n"
            "a=rtpmap:32 MPV/90000\r\n",
            /* This is how Alice's media should look like now: */
            "v=0\r\n"
            "o=alice 2890844526 2890844526 IN IP4 host.atlanta.example.com\r\n"
            "s=-\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 49170 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 51372 RTP/AVP 32\r\n"
            "a=rtpmap:32 MPV/90000\r\n"
          }
        }
    },

    /* test 5: */
    {
        /*********************************************************************
         * RFC 4317 Sample 2.1: Audio and Video 1 (Bob's view)
         *
         * This common scenario shows a video and audio session in which
         * multiple codecs are offered but only one is accepted.  As a result of
         * the exchange shown below, Alice and Bob may send only PCMU audio and
         * MPV video.  Note: Dynamic payload type 97 is used for iLBC codec
         *
         * Difference:
         *  - Bob's initial capability version number
         */
        "RFC 4317 section 2.1: Audio and Video 1 (Bob's view)",
        1,
        {
          {
            REMOTE_OFFER,
            PJ_FALSE,
            /* Received Alice's local offer: */
            "v=0\r\n"
            "o=alice 2890844526 2890844526 IN IP4 host.atlanta.example.com\r\n"
            "s=-\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 49170 RTP/AVP 0 8 97\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "a=rtpmap:8 PCMA/8000\r\n"
            "a=rtpmap:97 iLBC/8000\r\n"
            "m=video 51372 RTP/AVP 31 32\r\n"
            "a=rtpmap:31 H261/90000\r\n"
            "a=rtpmap:32 MPV/90000\r\n",
            /* Bob's capability: */
            "v=0\r\n"
            "o=bob 2808844564 2808844563 IN IP4 host.biloxi.example.com\r\n"
            "s=-\r\n"
            "c=IN IP4 host.biloxi.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 49174 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 49170 RTP/AVP 32\r\n"
            "a=rtpmap:32 MPV/90000\r\n",
            /* This is how Bob's media should look like now: */
            "v=0\r\n"
            "o=bob 2808844564 2808844564 IN IP4 host.biloxi.example.com\r\n"
            "s=-\r\n"
            "c=IN IP4 host.biloxi.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 49174 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 49170 RTP/AVP 32\r\n"
            "a=rtpmap:32 MPV/90000\r\n"
          }
        }
    },

    /* test 6: */
    {
        /*********************************************************************
         * RFC 4317 Sample 2.2: Audio and Video 2 (Alice's view)
         *
         * Difference:
         *  - Bob's initial capability version number
         */
        "RFC 4317 section 2.2: Audio and Video 2 (Alice's view)",
        2,
        {
          {
            LOCAL_OFFER,
            PJ_FALSE,
            /* Alice sends offer: */
            "v=0\r\n"
            "o=alice 2890844526 2890844526 IN IP4 host.atlanta.example.com\r\n"
            "s=alice\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 49170 RTP/AVP 0 8 97\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "a=rtpmap:8 PCMA/8000\r\n"
            "a=rtpmap:97 iLBC/8000\r\n"
            "m=video 51372 RTP/AVP 31 32\r\n"
            "a=rtpmap:31 H261/90000\r\n"
            "a=rtpmap:32 MPV/90000\r\n",
            /* Bob's answer: */
            "v=0\r\n"
            "o=bob 2808844564 2808844564 IN IP4 host.biloxi.example.com\r\n"
            "s=bob\r\n"
            "c=IN IP4 host.biloxi.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 49172 RTP/AVP 0 8\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "a=rtpmap:8 PCMA/8000\r\n"
            "m=video 0 RTP/AVP 31\r\n"
            "a=rtpmap:31 H261/90000\r\n",
            /* This is how Alice's media should look like now: */
            "v=0\r\n"
            "o=alice 2890844526 2890844526 IN IP4 host.atlanta.example.com\r\n"
            "s=alice\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 49170 RTP/AVP 0 8\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "a=rtpmap:8 PCMA/8000\r\n"
            // By #1088, the formats won't be negotiated when the media has port 0.
            //"m=video 0 RTP/AVP 31\r\n"
            "m=video 0 RTP/AVP 31 32\r\n"
            //"a=rtpmap:31 H261/90000\r\n"  /* <-- this is not necessary (port 0) */
          },
          {
            LOCAL_OFFER,
            PJ_FALSE,
            /* Alice sends updated offer: */
            "v=0\r\n"
            "o=alice 2890844526 2890844527 IN IP4 host.atlanta.example.com\r\n"
            "s=alice\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 51372 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 0 RTP/AVP 31\r\n"
            "a=rtpmap:31 H261/90000\r\n",
            /* Bob's answer: */
            "v=0\r\n"
            "o=bob 2808844564 2808844565 IN IP4 host.biloxi.example.com\r\n"
            "s=bob\r\n"
            "c=IN IP4 host.biloxi.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 49172 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 0 RTP/AVP 31\r\n"
            "a=rtpmap:31 H261/90000\r\n",
            /* This is how Alice's SDP should look like: */
            "v=0\r\n"
            "o=alice 2890844526 2890844527 IN IP4 host.atlanta.example.com\r\n"
            "s=alice\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 51372 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 0 RTP/AVP 31\r\n"
            //"a=rtpmap:31 H261/90000\r\n"  /* <-- this is not necessary (port 0) */
          }
        }
    },

    /* test 7: */
    {
        /*********************************************************************
         * RFC 4317 Sample 2.2: Audio and Video 2 (Bob's view)
         *
         * Difference:
         *  - Bob's initial capability version number
         */
        "RFC 4317 section 2.2: Audio and Video 2 (Bob's view)",
        3,
        {
          {
            REMOTE_OFFER,
            PJ_TRUE,
            /* Received offer from alice: */
            "v=0\r\n"
            "o=alice 2890844526 2890844526 IN IP4 host.atlanta.example.com\r\n"
            "s=alice\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 49170 RTP/AVP 0 8 97\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "a=rtpmap:8 PCMA/8000\r\n"
            "a=rtpmap:97 iLBC/8000\r\n"
            "m=video 51372 RTP/AVP 31 32\r\n"
            "a=rtpmap:31 H261/90000\r\n"
            "a=rtpmap:32 MPV/90000\r\n",
            /* Bob's initial capability: */
            "v=0\r\n"
            "o=bob 2808844564 2808844563 IN IP4 host.biloxi.example.com\r\n"
            "s=bob\r\n"
            "c=IN IP4 host.biloxi.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 49172 RTP/AVP 0 8\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "a=rtpmap:8 PCMA/8000\r\n"
            "m=video 0 RTP/AVP 31\r\n"
            "a=rtpmap:31 H261/90000\r\n",
            /* This is how Bob's answer should look like now: */
            "v=0\r\n"
            "o=bob 2808844564 2808844564 IN IP4 host.biloxi.example.com\r\n"
            "s=bob\r\n"
            "c=IN IP4 host.biloxi.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 49172 RTP/AVP 0 8\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "a=rtpmap:8 PCMA/8000\r\n"
            "m=video 0 RTP/AVP 31\r\n"
            "a=rtpmap:31 H261/90000\r\n"
          },
          {
            REMOTE_OFFER,
            PJ_FALSE,
            /* Received offer from alice: */
            "v=0\r\n"
            "o=alice 2890844526 2890844526 IN IP4 host.atlanta.example.com\r\n"
            "s=alice\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 49170 RTP/AVP 0 8 97\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "a=rtpmap:8 PCMA/8000\r\n"
            "a=rtpmap:97 iLBC/8000\r\n"
            "m=video 51372 RTP/AVP 31 32\r\n"
            "a=rtpmap:31 H261/90000\r\n"
            "a=rtpmap:32 MPV/90000\r\n",
            /* Bob's initial capability: */
            "v=0\r\n"
            "o=bob 2808844564 2808844563 IN IP4 host.biloxi.example.com\r\n"
            "s=bob\r\n"
            "c=IN IP4 host.biloxi.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 49172 RTP/AVP 0 8\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "a=rtpmap:8 PCMA/8000\r\n"
            "m=video 0 RTP/AVP 31\r\n"
            "a=rtpmap:31 H261/90000\r\n",
            /* This is how Bob's answer should look like now: */
            "v=0\r\n"
            "o=bob 2808844564 2808844565 IN IP4 host.biloxi.example.com\r\n"
            "s=bob\r\n"
            "c=IN IP4 host.biloxi.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 49172 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 0 RTP/AVP 31\r\n"
            "a=rtpmap:31 H261/90000\r\n"
          },
          {
            REMOTE_OFFER,
            PJ_FALSE,
            /* Received updated offer from Alice: */
            "v=0\r\n"
            "o=alice 2890844526 2890844527 IN IP4 host.atlanta.example.com\r\n"
            "s=alice\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 51372 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 0 RTP/AVP 31\r\n"
            "a=rtpmap:31 H261/90000\r\n",
            /* Bob's answer: */
            NULL,
            /* This is how Bob's answer should look like: */
            "v=0\r\n"
            "o=bob 2808844564 2808844565 IN IP4 host.biloxi.example.com\r\n"
            "s=bob\r\n"
            "c=IN IP4 host.biloxi.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 49172 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 0 RTP/AVP 31\r\n"
            //"a=rtpmap:31 H261/90000\r\n"  /* <-- this is not necessary (port 0) */
          }
        }
    },

    /* test 8: */
    {
        /*********************************************************************
         * RFC 4317 Sample 2.4: Audio and Telephone-Events (Alice's view)
         *
         */

        "RFC 4317 section 2.4: Audio and Telephone-Events (Alice's view)",
        1,
        {
          {
            LOCAL_OFFER,
            PJ_FALSE,
            /* Alice sends offer: */
            "v=0\r\n"
            "o=alice 2890844526 2890844526 IN IP4 host.atlanta.example.com\r\n"
            "s=alice\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 49170 RTP/AVP 0 97\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "a=rtpmap:97 iLBC/8000\r\n"
            "m=audio 49172 RTP/AVP 98\r\n"
            "a=rtpmap:98 telephone-event/8000\r\n"
            "a=sendonly\r\n",
            /* Received Bob's answer: */
            "v=0\r\n"
            "o=bob 2808844564 2808844564 IN IP4 host.biloxi.example.com\r\n"
            "s=bob\r\n"
            "c=IN IP4 host.biloxi.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 49172 RTP/AVP 97\r\n"
            "a=rtpmap:97 iLBC/8000\r\n"
            "m=audio 49174 RTP/AVP 98\r\n"
            "a=rtpmap:98 telephone-event/8000\r\n"
            "a=recvonly\r\n",
            /* Alice's SDP now: */
            "v=0\r\n"
            "o=alice 2890844526 2890844526 IN IP4 host.atlanta.example.com\r\n"
            "s=alice\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 49170 RTP/AVP 97\r\n"
            "a=rtpmap:97 iLBC/8000\r\n"
            "m=audio 49172 RTP/AVP 98\r\n"
            "a=rtpmap:98 telephone-event/8000\r\n"
            "a=sendonly\r\n"
          }
        }
    },


    /* test 9: */
    {
        /*********************************************************************
         * RFC 4317 Sample 2.4: Audio and Telephone-Events (Bob's view)
         *
         * Difference:
         *  - Bob's initial SDP version number
         *  - Bob's capability are added with more formats, and the
         *    stream order is interchanged to test the negotiator.
         */

        "RFC 4317 section 2.4: Audio and Telephone-Events (Bob's view)",
        1,
        {
          {
            REMOTE_OFFER,
            PJ_FALSE,
            /* Received Alice's offer: */
            "v=0\r\n"
            "o=alice 2890844526 2890844526 IN IP4 host.atlanta.example.com\r\n"
            "s=alice\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 49170 RTP/AVP 0 97\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "a=rtpmap:97 iLBC/8000\r\n"
            "m=audio 49172 RTP/AVP 98\r\n"
            "a=rtpmap:98 telephone-event/8000\r\n"
            "a=sendonly\r\n",
            /* Bob's initial capability: */
            "v=0\r\n"
            "o=bob 2808844564 2808844563 IN IP4 host.biloxi.example.com\r\n"
            "s=bob\r\n"
            "c=IN IP4 host.biloxi.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 49174 RTP/AVP 4 98\r\n"
            "a=rtpmap:98 telephone-event/8000\r\n"
            "m=audio 49172 RTP/AVP 97 8 99\r\n"
            "a=rtpmap:97 iLBC/8000\r\n"
            "a=rtpmap:99 telephone-event/8000\r\n",
            /* Bob's answer should be: */
            "v=0\r\n"
            "o=bob 2808844564 2808844564 IN IP4 host.biloxi.example.com\r\n"
            "s=bob\r\n"
            "c=IN IP4 host.biloxi.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 49172 RTP/AVP 97\r\n"
            "a=rtpmap:97 iLBC/8000\r\n"
            "m=audio 49174 RTP/AVP 98\r\n"
            "a=rtpmap:98 telephone-event/8000\r\n"
            "a=recvonly\r\n"
          }
        }
    },

    /* test 10: */
    {
        /*********************************************************************
         * RFC 4317 Sample 2.6: Audio with Telephone-Events (Alice's view)
         *
         */

        "RFC 4317 section 2.6: Audio with Telephone-Events (Alice's view)",
        1,
        {
          {
            LOCAL_OFFER,
            PJ_FALSE,
            /* Alice sends offer: */
            "v=0\r\n"
            "o=alice 2890844526 2890844526 IN IP4 host.atlanta.example.com\r\n"
            "s=alice\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 49170 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=audio 51372 RTP/AVP 97 101\r\n"
            "a=rtpmap:97 iLBC/8000\r\n"
            "a=rtpmap:101 telephone-event/8000\r\n",
            /* Received bob's answer: */
            "v=0\r\n"
            "o=bob 2808844564 2808844564 IN IP4 host.biloxi.example.com\r\n"
            "s=bob\r\n"
            "c=IN IP4 host.biloxi.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 0 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=audio 49170 RTP/AVP 97 101\r\n"
            "a=rtpmap:97 iLBC/8000\r\n"
            "a=rtpmap:101 telephone-event/8000\r\n",
            /* Alice's local SDP should be: */
            "v=0\r\n"
            "o=alice 2890844526 2890844526 IN IP4 host.atlanta.example.com\r\n"
            "s=alice\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 0 RTP/AVP 0\r\n"
            //"a=rtpmap:0 PCMU/8000\r\n"          /* <-- this is not necessary (port 0) */
            "m=audio 51372 RTP/AVP 97 101\r\n"
            "a=rtpmap:97 iLBC/8000\r\n"
            "a=rtpmap:101 telephone-event/8000\r\n"
          }
        }
    },

    /* test 11: */
    {
        /*********************************************************************
         * RFC 4317 Sample 2.6: Audio with Telephone-Events (Bob's view)
         *
         * Difference:
         *  - Bob's SDP version number
         *  - Bob's initial capability are expanded with multiple m lines
         *    and more formats
         */

        "RFC 4317 section 2.6: Audio with Telephone-Events (Bob's view)",
        1,
        {
          {
            REMOTE_OFFER,
            PJ_FALSE,
            /* Received Alice's offer: */
            "v=0\r\n"
            "o=alice 2890844526 2890844526 IN IP4 host.atlanta.example.com\r\n"
            "s=alice\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 49170 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=audio 51372 RTP/AVP 97 101\r\n"
            "a=rtpmap:97 iLBC/8000\r\n"
            "a=rtpmap:101 telephone-event/8000\r\n",
            /* Bob's initial capability also has video: */
            "v=0\r\n"
            "o=bob 2808844564 2808844563 IN IP4 host.biloxi.example.com\r\n"
            "s=bob\r\n"
            "c=IN IP4 host.biloxi.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 49170 RTP/AVP 4 97 101\r\n"
            "a=rtpmap:4 G723/8000\r\n"
            "a=rtpmap:97 iLBC/8000\r\n"
            "a=rtpmap:101 telephone-event/8000\r\n"
            "m=video 1000 RTP/AVP 31\r\n"
            "a=rtpmap:31 H261/90000\r\n",
            /* Bob's answer should be: */
            "v=0\r\n"
            "o=bob 2808844564 2808844564 IN IP4 host.biloxi.example.com\r\n"
            "s=bob\r\n"
            "c=IN IP4 host.biloxi.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 0 RTP/AVP 0\r\n"
            //"a=rtpmap:0 PCMU/8000\r\n"      /* <-- this is not necessary (port 0) */
            "m=audio 49170 RTP/AVP 97 101\r\n"
            "a=rtpmap:97 iLBC/8000\r\n"
            "a=rtpmap:101 telephone-event/8000\r\n",
          }
        }
    },

    /* test 12: */
    {
        /*********************************************************************
         * Ticket #527: More lenient SDP negotiator.
         */

        "Ticket #527 scenario #1: Partial answer",
        1,
        {
          {
            LOCAL_OFFER,
            PJ_FALSE,
            /* Alice sends offer audio and video: */
            "v=0\r\n"
            "o=alice 2890844526 2890844526 IN IP4 host.atlanta.example.com\r\n"
            "s=alice\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 49170 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 4000 RTP/AVP 31\r\n"
            "a=rtpmap:31 H261/90000\r\n",
            /* Receive Bob's answer only audio: */
            "v=0\r\n"
            "o=bob 2808844564 2808844563 IN IP4 host.biloxi.example.com\r\n"
            "s=bob\r\n"
            "c=IN IP4 host.biloxi.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 49170 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n",
            /* Alice's local SDP should be: */
            "v=0\r\n"
            "o=alice 2890844526 2890844526 IN IP4 host.atlanta.example.com\r\n"
            "s=alice\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 49170 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 0 RTP/AVP 31\r\n"
            //"a=rtpmap:31 H261/90000\r\n"    /* <-- this is not necessary (port 0) */
            "",
          }
        }
    },

    /* test 13: */
    {
        /*********************************************************************
         * Ticket #527: More lenient SDP negotiator.
         */

        "Ticket #527 scenario #1: Media mismatch in answer",
        1,
        {
          {
            LOCAL_OFFER,
            PJ_FALSE,
            /* Alice sends offer audio and video: */
            "v=0\r\n"
            "o=alice 2890844526 2890844526 IN IP4 host.atlanta.example.com\r\n"
            "s=alice\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 3000 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 4000 RTP/AVP 31\r\n"
            "a=rtpmap:31 H261/90000\r\n",
            /* Receive Bob's answer two audio: */
            "v=0\r\n"
            "o=bob 2808844564 2808844563 IN IP4 host.biloxi.example.com\r\n"
            "s=bob\r\n"
            "c=IN IP4 host.biloxi.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 49170 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=audio 49172 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n",
            /* Alice's local SDP should be: */
            "v=0\r\n"
            "o=alice 2890844526 2890844526 IN IP4 host.atlanta.example.com\r\n"
            "s=alice\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 3000 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 0 RTP/AVP 31\r\n"
            //"a=rtpmap:31 H261/90000\r\n"    /* <-- this is not necessary (port 0) */
            "",
          }
        }
    },

    /* test 14: */
    {
        /*********************************************************************
         * Ticket #527: More lenient SDP negotiator.
         */

        "Ticket #527 scenario #2: Modify offer - partial streams",
        2,
        {
          {
            LOCAL_OFFER,
            PJ_FALSE,
            /* Alice sends offer: */
            "v=0\r\n"
            "o=alice 2890844526 2890844526 IN IP4 host.atlanta.example.com\r\n"
            "s=alice\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 3000 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=audio 3100 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 3200 RTP/AVP 31\r\n"
            "a=rtpmap:31 H261/90000\r\n"
            "",
            /* Receive Bob's answer: */
            "v=0\r\n"
            "o=bob 2808844564 2808844563 IN IP4 host.biloxi.example.com\r\n"
            "s=bob\r\n"
            "c=IN IP4 host.biloxi.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 4000 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=audio 4100 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 4200 RTP/AVP 31\r\n"
            "a=rtpmap:31 H261/90000\r\n"
            "",
            /* Alice's local SDP should be: */
            "v=0\r\n"
            "o=alice 2890844526 2890844526 IN IP4 host.atlanta.example.com\r\n"
            "s=alice\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 3000 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=audio 3100 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 3200 RTP/AVP 31\r\n"
            "a=rtpmap:31 H261/90000\r\n"
            "",
          },
          {
            LOCAL_OFFER,
            PJ_FALSE,
            /* Alice modifies offer with only specify one audio: */
            "v=0\r\n"
            "o=alice 2890844526 2890844526 IN IP4 host.atlanta.example.com\r\n"
            "s=alice\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 5200 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "",
            /* Receive Bob's answer: */
            "v=0\r\n"
            "o=bob 2808844564 2808844563 IN IP4 host.biloxi.example.com\r\n"
            "s=bob\r\n"
            "c=IN IP4 host.biloxi.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 7000 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=audio 0 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 0 RTP/AVP 31\r\n"
            "a=rtpmap:31 H261/90000\r\n"
            "",
            /* Alice's local SDP should be: */
            "v=0\r\n"
            "o=alice 2890844526 2890844527 IN IP4 host.atlanta.example.com\r\n"
            "s=alice\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 5200 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=audio 0 RTP/AVP 0\r\n"
            //"a=rtpmap:0 PCMU/8000\r\n"      /* <-- this is not necessary (port 0) */
            "m=video 0 RTP/AVP 31\r\n"
            //"a=rtpmap:31 H261/90000\r\n"    /* <-- this is not necessary (port 0) */
            "",
          }
        }
    },

    /* test 15: */
    {
        /*********************************************************************
         * Ticket #527: More lenient SDP negotiator.
         */

        "Ticket #527 scenario #2: Modify offer - unordered m= lines",
        2,
        {
          {
            LOCAL_OFFER,
            PJ_FALSE,
            /* Alice sends offer: */
            "v=0\r\n"
            "o=alice 2890844526 2890844526 IN IP4 host.atlanta.example.com\r\n"
            "s=alice\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 3000 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 3200 RTP/AVP 31\r\n"
            "a=rtpmap:31 H261/90000\r\n"
            "",
            /* Receive Bob's answer: */
            "v=0\r\n"
            "o=bob 2808844564 2808844563 IN IP4 host.biloxi.example.com\r\n"
            "s=bob\r\n"
            "c=IN IP4 host.biloxi.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 4000 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 4200 RTP/AVP 31\r\n"
            "a=rtpmap:31 H261/90000\r\n"
            "",
            /* Alice's local SDP should be: */
            "v=0\r\n"
            "o=alice 2890844526 2890844526 IN IP4 host.atlanta.example.com\r\n"
            "s=alice\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 3000 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 3200 RTP/AVP 31\r\n"
            "a=rtpmap:31 H261/90000\r\n"
            "",
          },
          {
            LOCAL_OFFER,
            PJ_FALSE,
            /* Alice modifies offer with unordered m= lines: */
            "v=0\r\n"
            "o=alice 2890844526 2890844526 IN IP4 host.atlanta.example.com\r\n"
            "s=alice\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=video 5000 RTP/AVP 31\r\n"
            "a=rtpmap:31 H261/90000\r\n"
            "m=audio 5200 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "",
            /* Receive Bob's answer: */
            "v=0\r\n"
            "o=bob 2808844564 2808844563 IN IP4 host.biloxi.example.com\r\n"
            "s=bob\r\n"
            "c=IN IP4 host.biloxi.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 7000 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 2000 RTP/AVP 31\r\n"
            "a=rtpmap:31 H261/90000\r\n"
            "",
            /* Alice's local SDP should be: */
            "v=0\r\n"
            "o=alice 2890844526 2890844527 IN IP4 host.atlanta.example.com\r\n"
            "s=alice\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 5200 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 5000 RTP/AVP 31\r\n"
            "a=rtpmap:31 H261/90000\r\n"
            "",
          }
        }
    },

    /* test 16: */
    {
        /*********************************************************************
         * Ticket #527: More lenient SDP negotiator.
         */

        "Ticket #527 scenario #2: Modify offer - partial & unordered streams",
        2,
        {
          {
            LOCAL_OFFER,
            PJ_FALSE,
            /* Alice sends offer: */
            "v=0\r\n"
            "o=alice 2890844526 2890844526 IN IP4 host.atlanta.example.com\r\n"
            "s=alice\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 3000 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=audio 3200 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 3400 RTP/AVP 31\r\n"
            "a=rtpmap:31 H261/90000\r\n"
            "",
            /* Receive Bob's answer: */
            "v=0\r\n"
            "o=bob 2808844564 2808844563 IN IP4 host.biloxi.example.com\r\n"
            "s=bob\r\n"
            "c=IN IP4 host.biloxi.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 4000 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=audio 4200 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 4400 RTP/AVP 31\r\n"
            "a=rtpmap:31 H261/90000\r\n"
            "",
            /* Alice's local SDP should be: */
            "v=0\r\n"
            "o=alice 2890844526 2890844526 IN IP4 host.atlanta.example.com\r\n"
            "s=alice\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 3000 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=audio 3200 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 3400 RTP/AVP 31\r\n"
            "a=rtpmap:31 H261/90000\r\n"
            "",
          },
          {
            LOCAL_OFFER,
            PJ_FALSE,
            /* Alice modifies offer by specifying partial and unordered media: */
            "v=0\r\n"
            "o=alice 2890844526 2890844526 IN IP4 host.atlanta.example.com\r\n"
            "s=alice\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=video 5000 RTP/AVP 31\r\n"
            "a=rtpmap:31 H261/90000\r\n"
            "m=audio 7000 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "",
            /* Receive Bob's answer: */
            "v=0\r\n"
            "o=bob 2808844564 2808844563 IN IP4 host.biloxi.example.com\r\n"
            "s=bob\r\n"
            "c=IN IP4 host.biloxi.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 4000 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=audio 0 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=video 4400 RTP/AVP 31\r\n"
            "a=rtpmap:31 H261/90000\r\n"
            "",
            /* Alice's local SDP should be: */
            "v=0\r\n"
            "o=alice 2890844526 2890844527 IN IP4 host.atlanta.example.com\r\n"
            "s=alice\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 7000 RTP/AVP 0\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "m=audio 0 RTP/AVP 0\r\n"
            //"a=rtpmap:0 PCMU/8000\r\n"      /* <-- this is not necessary (port 0) */
            "m=video 5000 RTP/AVP 31\r\n"
            "a=rtpmap:31 H261/90000\r\n"
            "",
          }
        }
    },

    /* test 17: */
    {
        /*********************************************************************
         * Ticket #2088: : Handle multiple telephone-event formats.
         */

        "Ticket #2088: Handle multiple telephone-event formats",
        3,
        {
          {
            REMOTE_OFFER,
            PJ_TRUE,
            /* Bob sends offer: */
            "v=0\r\n"
            "o=bob 2808844564 2808844563 IN IP4 host.biloxi.example.com\r\n"
            "s=bob\r\n"
            "c=IN IP4 host.biloxi.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 3000 RTP/AVP 97 0 98 99\r\n"
            "a=rtpmap:97 Speex/16000\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "a=rtpmap:98 telephone-event/8000\r\n"
            "a=rtpmap:99 telephone-event/16000\r\n"
            "",
            /* Alice initial capability: */
            "v=0\r\n"
            "o=alice 2890844526 2890844526 IN IP4 host.atlanta.example.com\r\n"
            "s=alice\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 4000 RTP/AVP 0 100 96 98\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "a=rtpmap:100 Speex/16000\r\n"
            "a=rtpmap:96 telephone-event/8000\r\n"
            "a=rtpmap:98 telephone-event/16000\r\n"
            "",
            /* Alice's local SDP should be: */
            "v=0\r\n"
            "o=alice 2890844526 2890844527 IN IP4 host.atlanta.example.com\r\n"
            "s=alice\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 4000 RTP/AVP 97 0 98 99\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "a=rtpmap:97 Speex/16000\r\n"
            "a=rtpmap:98 telephone-event/8000\r\n"
            "a=rtpmap:99 telephone-event/16000\r\n"
            ""
          },
          {
            REMOTE_OFFER,
            PJ_FALSE,
            /* Bob sends offer: */
            "v=0\r\n"
            "o=bob 2808844564 2808844563 IN IP4 host.biloxi.example.com\r\n"
            "s=bob\r\n"
            "c=IN IP4 host.biloxi.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 3000 RTP/AVP 97 0 98 99\r\n"
            "a=rtpmap:97 Speex/16000\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "a=rtpmap:98 telephone-event/8000\r\n"
            "a=rtpmap:99 telephone-event/16000\r\n"
            "",
            /* Alice initial capability: */
            "v=0\r\n"
            "o=alice 2890844526 2890844526 IN IP4 host.atlanta.example.com\r\n"
            "s=alice\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 4000 RTP/AVP 0 100 96 98\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "a=rtpmap:100 Speex/16000\r\n"
            "a=rtpmap:96 telephone-event/8000\r\n"
            "a=rtpmap:98 telephone-event/16000\r\n"
            "",
            /* Alice's local SDP should be: */
            "v=0\r\n"
            "o=alice 2890844526 2890844528 IN IP4 host.atlanta.example.com\r\n"
            "s=alice\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 4000 RTP/AVP 97 99\r\n"
            "a=rtpmap:97 Speex/16000\r\n"
            "a=rtpmap:99 telephone-event/16000\r\n"
            ""
          },

          {
            LOCAL_OFFER,
            PJ_FALSE,
            /* Alice updates offer */
            "v=0\r\n"
            "o=alice 2890844526 2890844528 IN IP4 host.atlanta.example.com\r\n"
            "s=alice\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 4000 RTP/AVP 0 97 98 99\r\n"
            "a=rtpmap:0 PCMU/8000\r\n"
            "a=rtpmap:97 Speex/16000\r\n"
            "a=rtpmap:98 telephone-event/8000\r\n"
            "a=rtpmap:99 telephone-event/16000\r\n"
            "",
            /* Receive Bob's answer: */
            "v=0\r\n"
            "o=bob 2808844564 2808844563 IN IP4 host.biloxi.example.com\r\n"
            "s=bob\r\n"
            "c=IN IP4 host.biloxi.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 3000 RTP/AVP 99 100\r\n"
            "a=rtpmap:99 Speex/16000\r\n"
            "a=rtpmap:100 telephone-event/16000\r\n"
            "",
            /* Alice's local SDP should be: */
            "v=0\r\n"
            "o=alice 2890844526 2890844529 IN IP4 host.atlanta.example.com\r\n"
            "s=alice\r\n"
            "c=IN IP4 host.atlanta.example.com\r\n"
            "t=0 0\r\n"
            "m=audio 4000 RTP/AVP 97 99\r\n"
            "a=rtpmap:97 Speex/16000\r\n"
            "a=rtpmap:99 telephone-event/16000\r\n"
            "",
          }
        }
    },

    /* test 18: */
    {
        /*********************************************************************
         * AMR/AMR-WB offer with QoS preconditions: answerer only supports
         * AMR/8000 (octet-align=0) and telephone-event/8000.
         */

        "AMR/AMR-WB offer, answerer picks AMR/8000 + telephone-event",
        1,
        {
          {
            REMOTE_OFFER,
            PJ_TRUE,
            /* Remote offer: */
            "v=0\r\n"
            "o=- 3832217418 3832217418 IN IP4 10.162.173.4\r\n"
            "s=SS VOIP\r\n"
            "c=IN IP4 10.186.98.37\r\n"
            "t=0 0\r\n"
            "m=audio 4000 RTP/AVP 116 107 118 9 111 110\r\n"
            "b=AS:41\r\n"
            "b=RS:512\r\n"
            "b=RR:1537\r\n"
            "a=rtpmap:116 AMR-WB/16000\r\n"
            "a=fmtp:116 mode-change-capability=2;max-red=220\r\n"
            "a=rtpmap:107 AMR-WB/16000\r\n"
            "a=fmtp:107 octet-align=1;mode-change-capability=2;max-red=220\r\n"
            "a=rtpmap:118 AMR/8000\r\n"
            "a=fmtp:118 octet-align=0;mode-change-capability=2;max-red=220\r\n"
            /* For the following to work, pjmedia_codec_amr_match_sdp() must be registered first.
               "a=rtpmap:96 AMR/8000\r\n"
               "a=fmtp:96 octet-align=1;mode-change-capability=2;max-red=220\r\n"
            */
            "a=rtpmap:9 G722/8000\r\n"
            "a=rtpmap:111 telephone-event/16000\r\n"
            "a=fmtp:111 0-15\r\n"
            "a=rtpmap:110 telephone-event/8000\r\n"
            "a=fmtp:110 0-15\r\n"
            "a=curr:qos local none\r\n"
            "a=curr:qos remote none\r\n"
            "a=des:qos mandatory local sendrecv\r\n"
            "a=des:qos optional remote sendrecv\r\n"
            "a=rtcp:4001 IN IP4 10.186.98.37\r\n"
            "a=sendrecv\r\n"
            "a=ptime:20\r\n"
            "a=maxptime:240\r\n",
            /* Answerer initial capability: */
            "v=0\r\n"
            "o=- 3832217418 3832217419 IN IP4 10.162.173.125\r\n"
            "s=-\r\n"
            "c=IN IP4 10.186.99.39\r\n"
            "t=0 0\r\n"
            "m=audio 4002 RTP/AVP 118 110\r\n"
            "b=AS:29\r\n"
            "a=rtpmap:118 AMR/8000\r\n"
            "a=fmtp:118 octet-align=0;mode-change-capability=2;max-red=0\r\n"
            "a=rtpmap:110 telephone-event/8000\r\n"
            "a=fmtp:110 0-15\r\n"
            "a=rtcp:4003 IN IP4 10.186.99.39\r\n"
            "a=sendrecv\r\n"
            "a=ptime:20\r\n"
            "a=maxptime:40\r\n",
            /* Answerer's negotiated local SDP should be: */
            "v=0\r\n"
            "o=- 3832217418 3832217420 IN IP4 10.162.173.125\r\n"
            "s=-\r\n"
            "c=IN IP4 10.186.99.39\r\n"
            "t=0 0\r\n"
            "m=audio 4002 RTP/AVP 118 110\r\n"
            "b=AS:29\r\n"
            "a=rtpmap:118 AMR/8000\r\n"
            "a=fmtp:118 octet-align=0;mode-change-capability=2;max-red=0\r\n"
            "a=rtpmap:110 telephone-event/8000\r\n"
            "a=fmtp:110 0-15\r\n"
            "a=rtcp:4003 IN IP4 10.186.99.39\r\n"
            "a=sendrecv\r\n"
            "a=ptime:20\r\n"
            "a=maxptime:40\r\n",
          }
        }
    },

};

static const char *find_diff(const char *s1, const char *s2,
                             int *line)
{
    *line = 1;
    while (*s2 && *s1) {
        if (*s2 != *s1)
            return s2;
        if (*s2 == '\n')
            ++*line;
        ++s2, ++s1;
    }

    return s2;
}

static int compare_sdp_string(const char *cmp_title,
                              const char *title1,
                              const pjmedia_sdp_session *sdp1,
                              const char *title2,
                              const pjmedia_sdp_session *sdp2,
                              pj_status_t logical_cmp)
{
    char sdpbuf1[1024], sdpbuf2[1024];
    pj_ssize_t len1, len2;

    len1 = pjmedia_sdp_print(sdp1, sdpbuf1, sizeof(sdpbuf1));
    if (len1 < 1) {
        PJ_LOG(3,(THIS_FILE,"   error: printing sdp1"));
        return -1;
    }
    sdpbuf1[len1] = '\0';

    len2 = pjmedia_sdp_print(sdp2, sdpbuf2, sizeof(sdpbuf2));
    if (len2 < 1) {
        PJ_LOG(3,(THIS_FILE,"   error: printing sdp2"));
        return -1;
    }
    sdpbuf2[len2] = '\0';

    if (logical_cmp != PJ_SUCCESS) {
        char errbuf[80];

        pjmedia_strerror(logical_cmp, errbuf, sizeof(errbuf));

        PJ_LOG(3,(THIS_FILE,"%s mismatch: %s\n"
                            "%s:\n"
                            "%s\n"
                            "%s:\n"
                            "%s\n",
                            cmp_title,
                            errbuf,
                            title1, sdpbuf1, 
                            title2, sdpbuf2));

        return -1;

    } else if (strcmp(sdpbuf1, sdpbuf2) != 0) {
        int line;
        const char *diff;

        PJ_LOG(3,(THIS_FILE,"%s mismatch:\n"
                            "%s:\n"
                            "%s\n"
                            "%s:\n"
                            "%s\n",
                            cmp_title,
                            title1, sdpbuf1, 
                            title2, sdpbuf2));

        diff = find_diff(sdpbuf1, sdpbuf2, &line);
        PJ_LOG(3,(THIS_FILE,"Difference: line %d:\n"
                            "%s",
                            line, diff));
        return -1;

    } else {
        return 0;
    }

}

static int offer_answer_test(pj_pool_t *pool, pjmedia_sdp_neg **p_neg,
                             struct offer_answer *oa)
{
    pjmedia_sdp_session *sdp1;
    pjmedia_sdp_neg *neg;
    pj_status_t status;

    status = pjmedia_sdp_parse(pool, oa->sdp1, pj_ansi_strlen(oa->sdp1),
                                &sdp1);
    if (status != PJ_SUCCESS) {
        app_perror(status, "   error: unexpected parse status for sdp1");
        return -10;
    }

    status = pjmedia_sdp_validate(sdp1);
    if (status != PJ_SUCCESS) {
        app_perror(status, "   error: sdp1 validation failed");
        return -15;
    }

    neg = *p_neg;

    if (oa->type == LOCAL_OFFER) {
        
        /* 
         * Local creates offer first. 
         */
        pjmedia_sdp_session *sdp2, *sdp3;
        const pjmedia_sdp_session *active;

        if (neg == NULL) {
            /* Create negotiator with local offer. */
            status = pjmedia_sdp_neg_create_w_local_offer(pool, sdp1, &neg);
            if (status != PJ_SUCCESS) {
                app_perror(status, "   error: pjmedia_sdp_neg_create_w_local_offer");
                return -20;
            }
            *p_neg = neg;

        } else {
            /* Modify local offer */
            status = pjmedia_sdp_neg_modify_local_offer(pool, neg, sdp1);
            if (status != PJ_SUCCESS) {
                app_perror(status, "   error: pjmedia_sdp_neg_modify_local_offer");
                return -30;
            }
        }

        pjmedia_sdp_neg_set_answer_multiple_codecs(neg, oa->answer_multiple_codecs);

        /* Parse and validate remote answer */
        status = pjmedia_sdp_parse(pool, oa->sdp2, pj_ansi_strlen(oa->sdp2),
                                   &sdp2);
        if (status != PJ_SUCCESS) {
            app_perror(status, "   error: parsing sdp2");
            return -40;
        }

        status = pjmedia_sdp_validate(sdp2);
        if (status != PJ_SUCCESS) {
            app_perror(status, "   error: sdp2 validation failed");
            return -50;
        }

        /* Give the answer to negotiator. */
        status = pjmedia_sdp_neg_set_remote_answer(pool, neg, sdp2);
        if (status != PJ_SUCCESS) {
            app_perror(status, "   error: pjmedia_sdp_neg_rx_remote_answer");
            return -60;
        }

        /* Negotiate remote answer with local answer */
        status = pjmedia_sdp_neg_negotiate(pool, neg, 0);
        if (status != PJ_SUCCESS) {
            app_perror(status, "   error: pjmedia_sdp_neg_negotiate");
            return -70;
        }

        /* Get the local active media. */
        status = pjmedia_sdp_neg_get_active_local(neg, &active);
        if (status != PJ_SUCCESS) {
            app_perror(status, "   error: pjmedia_sdp_neg_get_local");
            return -80;
        }

        /* Parse and validate the correct active media. */
        status = pjmedia_sdp_parse(pool, oa->sdp3, pj_ansi_strlen(oa->sdp3),
                                   &sdp3);
        if (status != PJ_SUCCESS) {
            app_perror(status, "   error: parsing sdp3");
            return -90;
        }

        status = pjmedia_sdp_validate(sdp3);
        if (status != PJ_SUCCESS) {
            app_perror(status, "   error: sdp3 validation failed");
            return -100;
        }

        /* Compare active with sdp3 */
        status = pjmedia_sdp_session_cmp(active, sdp3, 0);
        if (status != PJ_SUCCESS) {
            app_perror(status, "   error: active local comparison mismatch");
            compare_sdp_string("Logical cmp after negotiatin remote answer",
                               "Active local sdp from negotiator", active,
                               "The correct active local sdp", sdp3,
                               status);
            return -110;
        }

        /* Compare the string representation oa both sdps */
        status = compare_sdp_string("String cmp after negotiatin remote answer",
                                    "Active local sdp from negotiator", active,
                                    "The correct active local sdp", sdp3,
                                    PJ_SUCCESS);
        if (status != 0)
            return -120;

    } else {
        /* 
         * Remote creates offer first. 
         */

        pjmedia_sdp_session *sdp2 = NULL, *sdp3;
        const pjmedia_sdp_session *answer;

        if (oa->sdp2) {
            /* Parse and validate initial local capability */
            status = pjmedia_sdp_parse(pool, oa->sdp2, pj_ansi_strlen(oa->sdp2),
                                       &sdp2);
            if (status != PJ_SUCCESS) {
                app_perror(status, "   error: parsing sdp2");
                return -200;
            }

            status = pjmedia_sdp_validate(sdp2);
            if (status != PJ_SUCCESS) {
                app_perror(status, "   error: sdp2 validation failed");
                return -210;
            }
        } else if (neg) {
            const pjmedia_sdp_session *lsdp;
            status = pjmedia_sdp_neg_get_active_local(neg, &lsdp);
            if (status != PJ_SUCCESS) {
                app_perror(status, 
                           "   error: pjmedia_sdp_neg_get_active_local");
                return -215;
            }
            sdp2 = (pjmedia_sdp_session*)lsdp;
        }

        if (neg == NULL) {
            /* Create negotiator with remote offer. */
            status = pjmedia_sdp_neg_create_w_remote_offer(pool, sdp2, sdp1, &neg);
            if (status != PJ_SUCCESS) {
                app_perror(status, "   error: pjmedia_sdp_neg_create_w_remote_offer");
                return -220;
            }
            *p_neg = neg;

        } else {
            /* Received subsequent offer from remote. */
            status = pjmedia_sdp_neg_set_remote_offer(pool, neg, sdp1);
            if (status != PJ_SUCCESS) {
                app_perror(status, "   error: pjmedia_sdp_neg_rx_remote_offer");
                return -230;
            }

            status = pjmedia_sdp_neg_set_local_answer(pool, neg, sdp2);
            if (status != PJ_SUCCESS) {
                app_perror(status, "   error: pjmedia_sdp_neg_set_local_answer");
                return -235;
            }
        }

        pjmedia_sdp_neg_set_answer_multiple_codecs(neg, oa->answer_multiple_codecs);

        /* Negotiate. */
        status = pjmedia_sdp_neg_negotiate(pool, neg, 0);
        if (status != PJ_SUCCESS) {
            app_perror(status, "   error: pjmedia_sdp_neg_negotiate");
            return -240;
        }
        
        /* Get our answer. */
        status = pjmedia_sdp_neg_get_active_local(neg, &answer);
        if (status != PJ_SUCCESS) {
            app_perror(status, "   error: pjmedia_sdp_neg_get_local");
            return -250;
        }

        /* Parse the correct answer. */
        status = pjmedia_sdp_parse(pool, oa->sdp3, pj_ansi_strlen(oa->sdp3),
                                   &sdp3);
        if (status != PJ_SUCCESS) {
            app_perror(status, "   error: parsing sdp3");
            return -260;
        }

        /* Validate the correct answer. */
        status = pjmedia_sdp_validate(sdp3);
        if (status != PJ_SUCCESS) {
            app_perror(status, "   error: sdp3 validation failed");
            return -270;
        }

        /* Compare answer from negotiator and the correct answer */
        status = pjmedia_sdp_session_cmp(sdp3, answer, 0);
        if (status != PJ_SUCCESS) {
            compare_sdp_string("Logical cmp after negotiating remote offer",
                               "Local answer from negotiator", answer,
                               "The correct local answer", sdp3,
                               status);

            return -280;
        }

        /* Compare the string representation oa both answers */
        status = compare_sdp_string("String cmp after negotiating remote offer",
                                    "Local answer from negotiator", answer,
                                    "The correct local answer", sdp3,
                                    PJ_SUCCESS);
        if (status != 0)
            return -290;

    }

    return 0;
}

static int perform_test(pj_pool_t *pool, int test_index)
{
    pjmedia_sdp_neg *neg = NULL;
    unsigned i;
    int rc;

    for (i=0; i<test[test_index].offer_answer_count; ++i) {

        rc = offer_answer_test(pool, &neg, &test[test_index].offer_answer[i]);
        if (rc != 0) {
            PJ_LOG(3,(THIS_FILE, "  test %s %d offer answer %d failed with status %d",
                      test[test_index].title, test_index, i, rc));
            return rc;
        }
    }

    return 0;
}

/* Regression: static PT with different string spellings (offer "0" vs
 * preanswer "00") must not trigger the reorder-loop assertion. */
static int sdp_neg_static_pt_repr_test(pj_pool_t *pool)
{
    static char offer_str[] =
        "v=0\r\n"
        "o=- 1 1 IN IP4 127.0.0.1\r\n"
        "s=-\r\nc=IN IP4 127.0.0.1\r\n"
        "t=0 0\r\n"
        "m=audio 4000 RTP/AVP 0\r\n";

    static char local_str[] =
        "v=0\r\n"
        "o=- 2 1 IN IP4 127.0.0.1\r\n"
        "s=-\r\nc=IN IP4 127.0.0.1\r\n"
        "t=0 0\r\n"
        "m=audio 5000 RTP/AVP 00\r\n";

    pjmedia_sdp_session *offer, *local;
    pjmedia_sdp_neg *neg;
    const pjmedia_sdp_session *active_local;
    pj_status_t status;
    char b1[sizeof(offer_str)], b2[sizeof(local_str)];

    pj_memcpy(b1, offer_str, sizeof(offer_str));
    pj_memcpy(b2, local_str, sizeof(local_str));
    if (pjmedia_sdp_parse(pool, b1, pj_ansi_strlen(b1), &offer) != PJ_SUCCESS)
        return -2000;
    if (pjmedia_sdp_parse(pool, b2, pj_ansi_strlen(b2), &local) != PJ_SUCCESS)
        return -2010;
    if (pjmedia_sdp_neg_create_w_remote_offer(pool, local, offer, &neg) != PJ_SUCCESS)
        return -2020;
    pjmedia_sdp_neg_set_prefer_remote_codec_order(neg, PJ_FALSE);

    status = pjmedia_sdp_neg_negotiate(pool, neg, 0);
    if (status != PJ_SUCCESS) {
        app_perror(status, "   sdp_neg_static_pt_repr_test: negotiate failed");
        return -2030;
    }

    /* apply_answer_symmetric_pt rewrites the answer fmt to the offer's PT
     * string — verify the active local SDP carries the offer-side spelling. */
    pjmedia_sdp_neg_get_active_local(neg, &active_local);
    if (pj_strcmp2(&active_local->media[0]->desc.fmt[0], "0") != 0)
        return -2040;

    return 0;
}

/* Regression: offer without c= on a port=0 media (passes lenient validation,
 * fails strict) must leave the negotiator in DONE state, not stuck in WAIT_NEGO. */
static int sdp_neg_strict_validate_test(pj_pool_t *pool)
{
    /* No c= anywhere; port=0 — passes validate2(PJ_FALSE), fails validate(). */
    static char offer_str[] =
        "v=0\r\n"
        "o=- 0 0 IN IP4 127.0.0.1\r\n"
        "s=-\r\n"
        "t=0 0\r\n"
        "m=audio 0 RTP/AVP 0\r\n";

    static char local_str[] =
        "v=0\r\n"
        "o=- 1 1 IN IP4 127.0.0.1\r\n"
        "s=-\r\n"
        "c=IN IP4 127.0.0.1\r\n"
        "t=0 0\r\n"
        "m=audio 4000 RTP/AVP 0\r\n";

    pjmedia_sdp_session *offer, *local;
    pjmedia_sdp_neg *neg;
    pj_status_t status;
    char b1[sizeof(offer_str)], b2[sizeof(local_str)];

    pj_memcpy(b1, offer_str, sizeof(offer_str));
    pj_memcpy(b2, local_str, sizeof(local_str));
    if (pjmedia_sdp_parse(pool, b1, pj_ansi_strlen(b1), &offer) != PJ_SUCCESS)
        return -1000;
    if (pjmedia_sdp_parse(pool, b2, pj_ansi_strlen(b2), &local) != PJ_SUCCESS)
        return -1010;
    if (pjmedia_sdp_neg_create_w_remote_offer(pool, local, offer, &neg) != PJ_SUCCESS)
        return -1020;

    status = pjmedia_sdp_neg_negotiate(pool, neg, 0);
    if (status != PJ_SUCCESS)
        return -1030;

    if (pjmedia_sdp_neg_get_state(neg) != PJMEDIA_SDP_NEG_STATE_DONE)
        return -1040;

    return 0;
}


/* RFC 9143: an offered media section using port zero is not rejected when
 * it has a=bundle-only and its MID belongs to the BUNDLE group.
 */
static int sdp_neg_bundle_only_test(pj_pool_t *pool)
{
    static char offer_str[] =
        "v=0\r\n"
        "o=- 0 0 IN IP4 127.0.0.1\r\n"
        "s=-\r\n"
        "c=IN IP4 127.0.0.1\r\n"
        "t=0 0\r\n"
        "a=group:BUNDLE 0 1\r\n"
        "m=audio 4000 RTP/AVP 0\r\n"
        "a=mid:0\r\n"
        "m=video 0 RTP/AVP 96\r\n"
        "a=mid:1\r\n"
        "a=bundle-only\r\n"
        "a=rtpmap:96 VP8/90000\r\n";

    static char local_str[] =
        "v=0\r\n"
        "o=- 1 1 IN IP4 127.0.0.1\r\n"
        "s=-\r\n"
        "c=IN IP4 127.0.0.1\r\n"
        "t=0 0\r\n"
        "a=group:BUNDLE 0 1\r\n"
        "m=audio 5000 RTP/AVP 0\r\n"
        "a=mid:0\r\n"
        "m=video 5002 RTP/AVP 96\r\n"
        "a=mid:1\r\n"
        "a=rtpmap:96 VP8/90000\r\n";

    pjmedia_sdp_session *offer, *local;
    pjmedia_sdp_neg *neg;
    const pjmedia_sdp_session *active_local;
    pj_status_t status;
    char b1[sizeof(offer_str)], b2[sizeof(local_str)];

    pj_memcpy(b1, offer_str, sizeof(offer_str));
    pj_memcpy(b2, local_str, sizeof(local_str));

    if (pjmedia_sdp_parse(pool, b1, pj_ansi_strlen(b1), &offer) !=
        PJ_SUCCESS)
    {
        return -3000;
    }

    if (pjmedia_sdp_parse(pool, b2, pj_ansi_strlen(b2), &local) !=
        PJ_SUCCESS)
    {
        return -3010;
    }

    if (pjmedia_sdp_neg_create_w_remote_offer(pool, local, offer, &neg) !=
        PJ_SUCCESS)
    {
        return -3020;
    }

    status = pjmedia_sdp_neg_negotiate(pool, neg, 0);
    if (status != PJ_SUCCESS) {
        app_perror(status, "   sdp_neg_bundle_only_test: negotiate failed");
        return -3030;
    }

    pjmedia_sdp_neg_get_active_local(neg, &active_local);

    if (active_local->media_count != 2)
        return -3040;

    if (active_local->media[1]->desc.port == 0)
        return -3050;

    return 0;
}


/* A bundle-only media is not disabled, so it must be validated as any
 * active media, i.e. it must have format and rtpmap for dynamic payload
 * type. Otherwise the offer must be rejected, instead of being negotiated
 * as if it was validated.
 */
static int sdp_neg_bundle_only_invalid_test(pj_pool_t *pool)
{
    /* Bundle-only media without rtpmap for its dynamic payload type. */
    static char no_rtpmap_str[] =
        "v=0\r\n"
        "o=- 0 0 IN IP4 127.0.0.1\r\n"
        "s=-\r\n"
        "c=IN IP4 127.0.0.1\r\n"
        "t=0 0\r\n"
        "a=group:BUNDLE 0 1\r\n"
        "m=audio 4000 RTP/AVP 0\r\n"
        "a=mid:0\r\n"
        "m=video 0 RTP/AVP 96\r\n"
        "a=mid:1\r\n"
        "a=bundle-only\r\n";

    /* Bundle-only media without any format. */
    static char no_fmt_str[] =
        "v=0\r\n"
        "o=- 0 0 IN IP4 127.0.0.1\r\n"
        "s=-\r\n"
        "c=IN IP4 127.0.0.1\r\n"
        "t=0 0\r\n"
        "a=group:BUNDLE 0 1\r\n"
        "m=audio 4000 RTP/AVP 0\r\n"
        "a=mid:0\r\n"
        "m=video 0 RTP/AVP\r\n"
        "a=mid:1\r\n"
        "a=bundle-only\r\n";

    static char local_str[] =
        "v=0\r\n"
        "o=- 1 1 IN IP4 127.0.0.1\r\n"
        "s=-\r\n"
        "c=IN IP4 127.0.0.1\r\n"
        "t=0 0\r\n"
        "a=group:BUNDLE 0 1\r\n"
        "m=audio 5000 RTP/AVP 0\r\n"
        "a=mid:0\r\n"
        "m=video 5002 RTP/AVP 96\r\n"
        "a=mid:1\r\n"
        "a=rtpmap:96 VP8/90000\r\n";

    struct {
        char        *sdp;
        unsigned     len;
        pj_status_t  exp_status;
    } offers[] = {
        { no_rtpmap_str, sizeof(no_rtpmap_str)-1, PJMEDIA_SDP_EMISSINGRTPMAP },
        { no_fmt_str,    sizeof(no_fmt_str)-1,    PJMEDIA_SDP_ENOFMT }
    };
    pjmedia_sdp_session *offer, *local;
    pjmedia_sdp_neg *neg;
    pj_status_t status;
    unsigned i;
    char b1[sizeof(no_rtpmap_str) > sizeof(no_fmt_str) ?
            sizeof(no_rtpmap_str) : sizeof(no_fmt_str)];
    char b2[sizeof(local_str)];

    pj_memcpy(b2, local_str, sizeof(local_str));
    if (pjmedia_sdp_parse(pool, b2, pj_ansi_strlen(b2), &local) != PJ_SUCCESS)
        return -3060;

    for (i=0; i<PJ_ARRAY_SIZE(offers); ++i) {
        pj_memcpy(b1, offers[i].sdp, offers[i].len + 1);

        if (pjmedia_sdp_parse(pool, b1, offers[i].len, &offer) != PJ_SUCCESS)
            return -3070 - i*10;

        status = pjmedia_sdp_validate2(offer, PJ_FALSE);
        if (status != offers[i].exp_status)
            return -3072 - i*10;

        status = pjmedia_sdp_neg_create_w_remote_offer(pool, local, offer,
                                                       &neg);
        if (status != offers[i].exp_status)
            return -3074 - i*10;
    }

    return 0;
}


/* A zero port media having a=bundle-only is not a bundle-only media when
 * its MID is missing or is not listed in the session level BUNDLE group,
 * so it is just an ordinary disabled media, i.e. the validation relaxations
 * still apply and it is simply rejected in the answer.
 */
static int sdp_neg_bundle_only_relaxed_test(pj_pool_t *pool)
{
    /* Zero port media with a=bundle-only, but without a=mid. */
    static char no_mid_str[] =
        "v=0\r\n"
        "o=- 0 0 IN IP4 127.0.0.1\r\n"
        "s=-\r\n"
        "c=IN IP4 127.0.0.1\r\n"
        "t=0 0\r\n"
        "a=group:BUNDLE 0\r\n"
        "m=audio 4000 RTP/AVP 0\r\n"
        "a=mid:0\r\n"
        "m=video 0 RTP/AVP 96\r\n"
        "a=bundle-only\r\n";

    /* Zero port media with a=bundle-only and a=mid, but the MID is not
     * listed in the session level BUNDLE group.
     */
    static char no_group_str[] =
        "v=0\r\n"
        "o=- 0 0 IN IP4 127.0.0.1\r\n"
        "s=-\r\n"
        "c=IN IP4 127.0.0.1\r\n"
        "t=0 0\r\n"
        "a=group:BUNDLE 0\r\n"
        "m=audio 4000 RTP/AVP 0\r\n"
        "a=mid:0\r\n"
        "m=video 0 RTP/AVP 96\r\n"
        "a=mid:1\r\n"
        "a=bundle-only\r\n";

    static char local_str[] =
        "v=0\r\n"
        "o=- 1 1 IN IP4 127.0.0.1\r\n"
        "s=-\r\n"
        "c=IN IP4 127.0.0.1\r\n"
        "t=0 0\r\n"
        "a=group:BUNDLE 0 1\r\n"
        "m=audio 5000 RTP/AVP 0\r\n"
        "a=mid:0\r\n"
        "m=video 5002 RTP/AVP 96\r\n"
        "a=mid:1\r\n"
        "a=rtpmap:96 VP8/90000\r\n";

    struct {
        char        *sdp;
        unsigned     len;
    } offers[] = {
        { no_mid_str,   sizeof(no_mid_str)-1 },
        { no_group_str, sizeof(no_group_str)-1 }
    };
    pjmedia_sdp_session *offer, *local;
    pjmedia_sdp_neg *neg;
    const pjmedia_sdp_session *active_local;
    pj_status_t status;
    unsigned i;
    char *b1;
    char b2[sizeof(local_str)];

    pj_memcpy(b2, local_str, sizeof(local_str));
    if (pjmedia_sdp_parse(pool, b2, pj_ansi_strlen(b2), &local) != PJ_SUCCESS)
        return -3080;

    for (i=0; i<PJ_ARRAY_SIZE(offers); ++i) {
        b1 = (char*)pj_pool_alloc(pool, offers[i].len + 1);
        pj_memcpy(b1, offers[i].sdp, offers[i].len + 1);

        if (pjmedia_sdp_parse(pool, b1, offers[i].len, &offer) != PJ_SUCCESS)
            return -3090 - i*10;

        /* The media is not bundle-only, so the missing rtpmap for its
         * dynamic payload type must still be tolerated.
         */
        status = pjmedia_sdp_validate2(offer, PJ_FALSE);
        if (status != PJ_SUCCESS)
            return -3092 - i*10;

        status = pjmedia_sdp_neg_create_w_remote_offer(pool, local, offer,
                                                       &neg);
        if (status != PJ_SUCCESS)
            return -3094 - i*10;

        status = pjmedia_sdp_neg_negotiate(pool, neg, 0);
        if (status != PJ_SUCCESS)
            return -3096 - i*10;

        pjmedia_sdp_neg_get_active_local(neg, &active_local);

        /* The media must be rejected as any other disabled media. */
        if (active_local->media_count != 2 ||
            active_local->media[1]->desc.port != 0)
        {
            return -3098 - i*10;
        }
    }

    return 0;
}

int sdp_neg_test()
{
    unsigned i;
    int status;

    for (i=START_TEST; i<PJ_ARRAY_SIZE(test); ++i) {
        pj_pool_t *pool;

        pool = pj_pool_create(mem, "sdp_neg_test", 4000, 4000, NULL);
        if (!pool)
            return PJ_ENOMEM;

        PJ_LOG(3,(THIS_FILE,"  test %d: %s", i, test[i].title));
        status = perform_test(pool, i);

        pj_pool_release(pool);

        if (status != 0) {
            return status;
        }
    }

    {
        pj_pool_t *pool;

        pool = pj_pool_create(mem, "sdp_neg_pt_repr", 4000, 4000, NULL);
        if (!pool)
            return PJ_ENOMEM;

        PJ_LOG(3,(THIS_FILE, "  sdp_neg_static_pt_repr_test"));
        status = sdp_neg_static_pt_repr_test(pool);
        pj_pool_release(pool);

        if (status != 0)
            return status;
    }

    {
        pj_pool_t *pool;

        pool = pj_pool_create(mem, "sdp_neg_bundle", 4000, 4000, NULL);
        if (!pool)
            return PJ_ENOMEM;

        PJ_LOG(3,(THIS_FILE, "  sdp_neg_bundle_only_test"));
        status = sdp_neg_bundle_only_test(pool);
        if (status == 0) {
            PJ_LOG(3,(THIS_FILE, "  sdp_neg_bundle_only_invalid_test"));
            status = sdp_neg_bundle_only_invalid_test(pool);
        }
        if (status == 0) {
            PJ_LOG(3,(THIS_FILE, "  sdp_neg_bundle_only_relaxed_test"));
            status = sdp_neg_bundle_only_relaxed_test(pool);
        }
        pj_pool_release(pool);

        if (status != 0)
            return status;
    }

    {
        pj_pool_t *pool;

        pool = pj_pool_create(mem, "sdp_neg_strict_val", 4000, 4000, NULL);
        if (!pool)
            return PJ_ENOMEM;

        PJ_LOG(3,(THIS_FILE, "  sdp_neg_strict_validate_test"));
        status = sdp_neg_strict_validate_test(pool);
        pj_pool_release(pool);

        if (status != 0)
            return status;
    }

    return 0;
}
