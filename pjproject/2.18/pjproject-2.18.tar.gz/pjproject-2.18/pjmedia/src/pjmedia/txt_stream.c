/*
 * Copyright (C) 2024-2025 Teluu Inc. (http://www.teluu.com)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <pj/assert.h>
#include <pj/ctype.h>
#include <pj/errno.h>
#include <pj/log.h>
#include <pj/os.h>
#include <pj/pool.h>
#include <pj/rand.h>
#include <pjmedia/clock.h>
#include <pjmedia/errno.h>
#include <pjmedia/jbuf.h>
#include <pjmedia/port.h>
#include <pjmedia/rtcp.h>
#include <pjmedia/rtp.h>
#include <pjmedia/sdp_neg.h>
#include <pjmedia/transport.h>
#include <pjmedia/transport_ice.h>
#include <pjmedia/txt_stream.h>

#define THIS_FILE "txt_stream.c"
#define LOGERR_(expr) PJ_PERROR(4, expr)
#define TRC_(expr) PJ_LOG(5, expr)

#if 0
#define TRACE_(log) PJ_LOG(3, log)
#else
#define TRACE_(log)
#endif

/* Default and max buffering time if not specified.
 * The RFC recommends a buffering time of 300 ms. Note that the maximum
 * according to the RFC is 500 ms.
 */
#define BUFFERING_TIME 300
#define MAX_BUFFERING_TIME 500

/* Buffer size to store the characters buffered during BUFFERING_TIME.
 * The default cps (character per second) is 30, but it's over a 10-second
 * interval, so we need a larger buffer to handle the burst.
 */
#define BUFFER_SIZE 64

/* The number of buffers must be the max redundancy we want to support +
 * plus one more to store the primary data.
 */
#define NUM_BUFFERS PJMEDIA_TXT_STREAM_MAX_RED_LEVELS + 1

/* 5.4. Compensation for Packets Out of Order:
 * If analysis of a received packet reveals a gap in the sequence,
 * we need to wait for the missing packet(s) to arrive.  It is
 * RECOMMENDED the waiting time be limited to 1 second (1000 ms).
 */
#define MAX_RX_WAITING_TIME 1000

/* Maximum number of text packets that can be kept in the jitter buffer.
 * The value should be roughly our MAX_RX_WAITING_TIME over remote's
 * buffering time (which unfortunately we don't know).
 */
#define JBUF_MAX_COUNT 8

/* Maximum size of a single text frame in bytes */
#define MAX_TEXT_FRAME_SIZE PJMEDIA_MAX_MTU

/* Sanity bounds for the start-of-stream keep-alive settings. */
#define START_KA_MAX_CNT 10
#define START_KA_MIN_INTERVAL_MSEC 500

/* Buffer to store redundancy and primary data. */
typedef struct red_buf {
    unsigned timestamp;
    unsigned length;
    char buf[BUFFER_SIZE];
} red_buf;

typedef struct pjmedia_txt_stream {
    pjmedia_stream_common base;
    pjmedia_txt_stream_info si; /**< Creation parameter.    */

    pjmedia_clock *clock; /**< Clock.                 */
    unsigned buf_time;    /**< Buffering time.        */
    pj_bool_t is_idle;    /**< Is idle?               */

    pj_timestamp rtcp_last_tx;   /**< Last RTCP tx time.     */
    pj_timestamp tx_last_ts;     /**< Timestamp of last tx.  */

    unsigned start_ka_left;        /**< Remaining start-of-stream
                                        keep-alives to send.      */
    unsigned start_ka_msec;        /**< Effective start keep-alive
                                        interval, in msec.        */
    pj_timestamp start_ka_last_tx; /**< Last start keep-alive tx. */
    red_buf tx_buf[NUM_BUFFERS]; /**< Tx buffer.         */
    int tx_nred;                 /**< Num of redundant data. */

    int rx_last_seq; /**< Sequence of last rx.   */

    /* Incoming text callback. */
    void (*cb)(pjmedia_txt_stream *, void *, const pjmedia_txt_stream_data *);
    void *cb_user_data;

} pjmedia_txt_stream;

static void clock_cb(const pj_timestamp *ts, void *user_data);

#include "stream_imp_common.c"

/*
 * Set up the start-of-stream keep-alive burst, see check_start_ka().
 * Must be called after the transport is attached.
 */
static void init_start_ka(pjmedia_txt_stream *stream)
{
    pjmedia_stream_common *c_strm = &stream->base;
    pjmedia_transport_info tpinfo;
    pjmedia_ice_transport_info *ice_info;

#if defined(PJMEDIA_STREAM_ENABLE_KA) && PJMEDIA_STREAM_ENABLE_KA != 0
    /* Take the runtime settings, already set from info->ka_cfg above. */
    stream->start_ka_left = c_strm->use_ka ? c_strm->start_ka_count : 0;
    stream->start_ka_msec = c_strm->start_ka_interval;
#else
    /* No runtime settings in this build, they are compiled out. */
    stream->start_ka_left = PJMEDIA_STREAM_START_KA_CNT;
    stream->start_ka_msec = PJMEDIA_STREAM_START_KA_INTERVAL_MSEC;
#endif

    if (stream->start_ka_left > START_KA_MAX_CNT)
        stream->start_ka_left = START_KA_MAX_CNT;
    if (stream->start_ka_msec < START_KA_MIN_INTERVAL_MSEC)
        stream->start_ka_msec = START_KA_MIN_INTERVAL_MSEC;

    if (stream->start_ka_left == 0)
        return;

    /* ICE connectivity checks already create the NAT bindings. */
    pjmedia_transport_info_init(&tpinfo);
    if (pjmedia_transport_get_info(c_strm->transport, &tpinfo) == PJ_SUCCESS)
    {
        ice_info = (pjmedia_ice_transport_info *)
                   pjmedia_transport_info_get_spc_info(
                       &tpinfo, PJMEDIA_TRANSPORT_TYPE_ICE);
        if (ice_info && ice_info->active)
            stream->start_ka_left = 0;
    }
}

static void on_stream_destroy(void *arg)
{
    pjmedia_txt_stream *stream = (pjmedia_txt_stream *) arg;

    if (stream->clock) {
        pjmedia_clock_destroy(stream->clock);
        stream->clock = NULL;
    }
}

/*
 * Destroy stream.
 */
PJ_DEF(pj_status_t) pjmedia_txt_stream_destroy(pjmedia_txt_stream *stream)
{
    pjmedia_stream_common *c_strm = (pjmedia_stream_common *) stream;

    PJ_ASSERT_RETURN(stream != NULL, PJ_EINVAL);

    PJ_LOG(4, (c_strm->port.info.name.ptr, "Stream destroying"));

    stream->cb = NULL;

    if (stream->clock)
        pjmedia_clock_stop(stream->clock);

    /* Send RTCP BYE (also SDES & XR) */
    if (c_strm->transport && !c_strm->rtcp_sdes_bye_disabled) {
#if defined(PJMEDIA_HAS_RTCP_XR) && (PJMEDIA_HAS_RTCP_XR != 0)
        send_rtcp(c_strm, PJ_TRUE, PJ_TRUE, c_strm->rtcp.xr_enabled, PJ_FALSE,
                  PJ_FALSE, PJ_FALSE);
#else
        send_rtcp(c_strm, PJ_TRUE, PJ_TRUE, PJ_FALSE, PJ_FALSE, PJ_FALSE,
                  PJ_FALSE);
#endif
    }

    /* Unsubscribe from RTCP session events
     * Currently unused
     */
    // pjmedia_event_unsubscribe(NULL, &stream_event_cb, stream, &c_strm->rtcp);

    /* Detach from transport
     * MUST NOT hold stream mutex while detaching from transport, as
     * it may cause deadlock. See ticket #460 for the details.
     */
    if (c_strm->transport) {
        pjmedia_transport_detach(c_strm->transport, c_strm);
        // c_strm->transport = NULL;
    }

    if (c_strm->grp_lock) {
        pj_grp_lock_dec_ref(c_strm->grp_lock);
    } else {
        on_destroy(c_strm);
    }

    return PJ_SUCCESS;
}

PJ_DEF(pj_status_t)
pjmedia_txt_stream_create(pjmedia_endpt *endpt, pj_pool_t *pool,
                          const pjmedia_txt_stream_info *info,
                          pjmedia_transport *tp, void *user_data,
                          pjmedia_txt_stream **p_stream)

{
    enum { M = 32 };
    pjmedia_txt_stream *stream;
    pjmedia_stream_common *c_strm;
    pj_str_t name;
    pj_pool_t *own_pool = NULL;
    char *p;
    unsigned buf_size;
    unsigned i;
    pj_status_t status;
    pjmedia_transport_attach_param att_param;
    pjmedia_clock_param cparam;

    PJ_ASSERT_RETURN(endpt && info && tp && p_stream, PJ_EINVAL);

    if (pool == NULL) {
        own_pool = pjmedia_endpt_create_pool(endpt, "tstrm%p", 2000, 2000);
        PJ_ASSERT_RETURN(own_pool != NULL, PJ_ENOMEM);
        pool = own_pool;
    }

    /* Allocate the text stream: */
    stream = PJ_POOL_ZALLOC_T(pool, pjmedia_txt_stream);
    PJ_ASSERT_RETURN(stream != NULL, PJ_ENOMEM);
    c_strm = &stream->base;
    c_strm->own_pool = own_pool;

    /* Duplicate stream info */
    pj_memcpy(&stream->si, info, sizeof(*info));
    c_strm->si = (pjmedia_stream_info_common *) &stream->si;
    pj_strdup(pool, &stream->si.fmt.encoding_name, &info->fmt.encoding_name);
    pjmedia_rtcp_fb_info_dup(pool, &c_strm->si->loc_rtcp_fb,
                             &info->loc_rtcp_fb);
    pjmedia_rtcp_fb_info_dup(pool, &c_strm->si->rem_rtcp_fb,
                             &info->rem_rtcp_fb);

    for (i = 0; i < stream->si.enc_fmtp.cnt; ++i) {
        pj_strdup(pool, &stream->si.enc_fmtp.param[i].name,
                  &info->enc_fmtp.param[i].name);
        pj_strdup(pool, &stream->si.enc_fmtp.param[i].val,
                  &info->enc_fmtp.param[i].val);
    }
    for (i = 0; i < stream->si.dec_fmtp.cnt; ++i) {
        pj_strdup(pool, &stream->si.dec_fmtp.param[i].name,
                  &info->dec_fmtp.param[i].name);
        pj_strdup(pool, &stream->si.dec_fmtp.param[i].val,
                  &info->dec_fmtp.param[i].val);
    }

    /* Init stream/port name */
    name.ptr = (char *) pj_pool_alloc(pool, M);
    name.slen = pj_ansi_snprintf(name.ptr, M, "tstrm%p", stream);
    c_strm->port.info.name = name;

    /* Init stream: */
    c_strm->endpt = endpt;
    c_strm->dir = info->dir;
    c_strm->user_data = user_data;
    c_strm->rtcp_interval = (PJMEDIA_RTCP_INTERVAL - 500 + (pj_rand() % 1000)) *
                            info->fmt.clock_rate / 1000;
    c_strm->rtcp_sdes_bye_disabled = info->rtcp_sdes_bye_disabled;

    c_strm->jb_last_frm = PJMEDIA_JB_NORMAL_FRAME;
    c_strm->rtcp_fb_nack.pid = -1;
    stream->rx_last_seq = -1;
    stream->is_idle = PJ_TRUE;

#if defined(PJMEDIA_STREAM_ENABLE_KA) && PJMEDIA_STREAM_ENABLE_KA != 0
    c_strm->use_ka = info->use_ka;
    c_strm->ka_interval = info->ka_cfg.ka_interval;
    c_strm->start_ka_count = info->ka_cfg.start_count;
    c_strm->start_ka_interval = info->ka_cfg.start_interval;
#endif

    c_strm->cname = info->cname;
    if (c_strm->cname.slen == 0) {
        /* Build random RTCP CNAME. CNAME has user@host format */
        c_strm->cname.ptr = p = (char *) pj_pool_alloc(pool, 20);
        pj_create_random_string(p, 5);
        p += 5;
        *p++ = '@';
        *p++ = 'p';
        *p++ = 'j';
        pj_create_random_string(p, 6);
        p += 6;
        *p++ = '.';
        *p++ = 'o';
        *p++ = 'r';
        *p++ = 'g';
        c_strm->cname.slen = p - c_strm->cname.ptr;
    }

    /* Init buffering time and create clock. */
    stream->buf_time = info->buffer_time;
    if (stream->buf_time == 0)
        stream->buf_time = BUFFERING_TIME;
    cparam.usec_interval = stream->buf_time * 1000;
    cparam.clock_rate = 1000;
    status = pjmedia_clock_create2(pool, &cparam, PJMEDIA_CLOCK_NO_HIGHEST_PRIO,
                                   clock_cb, stream, &stream->clock);
    if (status != PJ_SUCCESS)
        goto err_cleanup;

    /* Create mutex to protect jitter buffer: */
    status = pj_mutex_create_recursive(pool, NULL, &c_strm->jb_mutex);
    if (status != PJ_SUCCESS)
        goto err_cleanup;

    /* Create jitter buffer */
    status =
        pjmedia_jbuf_create(pool, &c_strm->port.info.name, MAX_TEXT_FRAME_SIZE,
                            stream->buf_time, JBUF_MAX_COUNT, &c_strm->jb);
    if (status != PJ_SUCCESS)
        goto err_cleanup;

    /* Set up jitter buffer */
    pjmedia_jbuf_set_fixed(c_strm->jb, 0);
    pjmedia_jbuf_set_discard(c_strm->jb, PJMEDIA_JB_DISCARD_NONE);

    /* Create decoder channel: */
    status = create_channel(pool, c_strm, PJMEDIA_DIR_DECODING, info->rx_pt, 0,
                            c_strm->si, &c_strm->dec);
    if (status != PJ_SUCCESS)
        goto err_cleanup;

    /* Create encoder channel: accommodate full RED headers and history */
    buf_size = PJMEDIA_MAX_MTU;
    status = create_channel(pool, c_strm, PJMEDIA_DIR_ENCODING, info->tx_pt,
                            buf_size, c_strm->si, &c_strm->enc);
    if (status != PJ_SUCCESS)
        goto err_cleanup;

    /* Init RTCP session: */
    {
        pjmedia_rtcp_session_setting rtcp_setting;

        pjmedia_rtcp_session_setting_default(&rtcp_setting);
        rtcp_setting.name = c_strm->port.info.name.ptr;
        rtcp_setting.ssrc = info->ssrc;
        rtcp_setting.rtp_ts_base = pj_ntohl(c_strm->enc->rtp.out_hdr.ts);
        /* Fallback to T.140 standard */
        rtcp_setting.clock_rate =
            info->fmt.clock_rate > 0 ? info->fmt.clock_rate : 1000;
        rtcp_setting.samples_per_frame = 1;

        pjmedia_rtcp_init2(&c_strm->rtcp, &rtcp_setting);

        if (info->rtp_seq_ts_set) {
            c_strm->rtcp.stat.rtp_tx_last_seq = info->rtp_seq;
            c_strm->rtcp.stat.rtp_tx_last_ts = info->rtp_ts;
        }

        /* Subscribe to RTCP events */
        // Currently not needed, perhaps for future use.
        // pjmedia_event_subscribe(NULL, &stream_event_cb, stream,
        //                        &c_strm->rtcp);
    }

    /* Allocate outgoing RTCP buffer, should be enough to hold SR/RR, SDES,
     * BYE, and XR.
     */
    c_strm->out_rtcp_pkt_size = sizeof(pjmedia_rtcp_sr_pkt) +
                                sizeof(pjmedia_rtcp_common) +
                                (4 + (unsigned) c_strm->cname.slen) + 32;

    if (c_strm->out_rtcp_pkt_size > PJMEDIA_MAX_MTU)
        c_strm->out_rtcp_pkt_size = PJMEDIA_MAX_MTU;

    c_strm->out_rtcp_pkt = pj_pool_alloc(pool, c_strm->out_rtcp_pkt_size);
    pj_bzero(&att_param, sizeof(att_param));
    att_param.stream = stream;
    att_param.media_type = PJMEDIA_TYPE_TEXT;
    att_param.user_data = stream;

    pj_sockaddr_cp(&att_param.rem_addr, &info->rem_addr);
    pj_sockaddr_cp(&c_strm->rem_rtp_addr, &info->rem_addr);
    if (stream->si.rtcp_mux) {
        pj_sockaddr_cp(&att_param.rem_rtcp, &info->rem_addr);
    } else if (pj_sockaddr_has_addr(&info->rem_rtcp)) {
        pj_sockaddr_cp(&att_param.rem_rtcp, &info->rem_rtcp);
    }
    att_param.addr_len = pj_sockaddr_get_len(&info->rem_addr);
    att_param.rtp_cb2 = &on_rx_rtp;
    att_param.rtcp_cb = &on_rx_rtcp;

    /* Create group lock & attach handler */
    status = pj_grp_lock_create_w_handler(pool, NULL, stream, &on_destroy,
                                          &c_strm->grp_lock);
    if (status != PJ_SUCCESS)
        goto err_cleanup;

    /* Add ref */
    pj_grp_lock_add_ref(c_strm->grp_lock);
    c_strm->port.grp_lock = c_strm->grp_lock;

    /* Only attach transport when stream is ready. Publish the transport and
     * ref its group lock before attaching: once attached, an rx callback may
     * arrive immediately and dereference c_strm->transport.
     */
    c_strm->transport = tp;
    if (tp->grp_lock)
        pj_grp_lock_add_ref(tp->grp_lock);

    /* Let the transport hold a reference on the stream's group lock across
     * each rx callback, so the stream cannot be destroyed while an in-flight
     * RTP/RTCP callback is running on it.
     */
    att_param.grp_lock = c_strm->grp_lock;
    status = pjmedia_transport_attach2(tp, &att_param);
    if (status != PJ_SUCCESS) {
        /* Unpublish, so cleanup below won't send RTCP BYE nor detach from a
         * transport we are not attached to.
         */
        c_strm->transport = NULL;
        if (tp->grp_lock)
            pj_grp_lock_dec_ref(tp->grp_lock);
        goto err_cleanup;
    }

    /* Send RTCP SDES */
    if (!c_strm->rtcp_sdes_bye_disabled) {
        pjmedia_stream_common_send_rtcp_sdes(c_strm);
    }

    init_start_ka(stream);

#if defined(PJMEDIA_STREAM_ENABLE_KA) && PJMEDIA_STREAM_ENABLE_KA != 0
    /* NAT hole punching by sending KA packet via RTP transport. */
    if (c_strm->use_ka) {
        send_keep_alive_packet(c_strm);
        pj_get_timestamp(&stream->start_ka_last_tx);
    }
#endif

    /* Success! */
    *p_stream = stream;

    PJ_LOG(3,
           (THIS_FILE, "Text stream %s created", c_strm->port.info.name.ptr));

    return PJ_SUCCESS;

err_cleanup:
    pjmedia_txt_stream_destroy(stream);
    return status;
}

PJ_DEF(pj_status_t) pjmedia_txt_stream_start(pjmedia_txt_stream *stream)
{
    pjmedia_stream_common *c_strm = (pjmedia_stream_common *) stream;
    pj_status_t status;

    pjmedia_stream_common_start(c_strm);

    /* Run the clock even for inactive direction, RTCP and start-of-stream
     * keep-alives are still needed (RFC 3264 5.1, RFC 6263 1).
     */
    status = pjmedia_clock_start(stream->clock);

    return status;
}

PJ_DEF(pj_status_t)
pjmedia_txt_stream_get_info(const pjmedia_txt_stream *stream,
                            pjmedia_txt_stream_info *info)
{
    PJ_ASSERT_RETURN(stream && info, PJ_EINVAL);

    pj_memcpy(info, &stream->si, sizeof(pjmedia_txt_stream_info));
    return PJ_SUCCESS;
}

static void call_cb(pjmedia_txt_stream *stream, pj_bool_t now)
{
    pjmedia_stream_common *c_strm = &stream->base;

    char frm_type;
    char frm_buf[MAX_TEXT_FRAME_SIZE];
    pj_size_t frm_size;
    pj_uint32_t ts;
    int popped_seq;
    char *text_ptr = NULL;

    PJ_UNUSED_ARG(now);

    pj_mutex_lock(c_strm->jb_mutex);

    do {
        /* Initialize state to detect uninitialized returns */
        popped_seq = -1;
        ts = 0;
        frm_size = sizeof(frm_buf);

        /* Pop the frame from the jitter buffer */
        pjmedia_jbuf_get_frame3(c_strm->jb, frm_buf, &frm_size, &frm_type, NULL,
                                &ts, &popped_seq);

        /* PJSIP empty frame validation */
        if (frm_type == PJMEDIA_JB_ZERO_EMPTY_FRAME ||
            frm_type == PJMEDIA_JB_ZERO_PREFETCH_FRAME) {
            break;
        }

        /* Handle missing frames */
        if (frm_type != PJMEDIA_JB_NORMAL_FRAME) {
            if (frm_type == PJMEDIA_JB_MISSING_FRAME) {
                /* break if jitter buffer didn't provide a sequence */
                if (popped_seq == -1) {
                    break;
                }

                if (stream->cb) {
                    /* Inject U+FFFD (replacement char) for lost packets */
                    pjmedia_txt_stream_data data;
                    data.seq = popped_seq;
                    data.ts = ts;
                    data.text.ptr = "\xEF\xBF\xBD";
                    data.text.slen = 3;

                    pj_mutex_unlock(c_strm->jb_mutex);
                    (*stream->cb)(stream, stream->cb_user_data, &data);
                    pj_mutex_lock(c_strm->jb_mutex);
                }
            }
            continue;
        }

        /* Strip the UTF-8 BOM if it exists at the start of the frame */
        text_ptr = frm_buf;
        if (frm_size >= 3 && (unsigned char) text_ptr[0] == 0xEF &&
            (unsigned char) text_ptr[1] == 0xBB &&
            (unsigned char) text_ptr[2] == 0xBF) {
            text_ptr += 3;
            frm_size -= 3;
        }

        /* Prevent zero-length frames from waking up the UI */
        pj_mutex_unlock(c_strm->jb_mutex);
        if (stream->cb && frm_size > 0) {
            pjmedia_txt_stream_data data;

            data.seq = popped_seq;
            data.ts = ts;
            data.text.ptr = text_ptr;
            data.text.slen = frm_size;
            (*stream->cb)(stream, stream->cb_user_data, &data);

        } else if (!stream->cb && frm_size > 0) {
            /* Debug trace if callback isn't set */
            TRACE_((THIS_FILE, "Text frame popped: %.*s", (int) frm_size,
                    text_ptr));
        }
        pj_mutex_lock(c_strm->jb_mutex);

    } while (1);

    pj_mutex_unlock(c_strm->jb_mutex);
}

static pj_status_t decode_red(pjmedia_txt_stream *stream, unsigned pt, int seq,
                              const char *buf, unsigned buflen,
                              unsigned *red_len)
{
    pj_uint32_t hdr[NUM_BUFFERS];
    const char *payload_ptr = NULL;
    const char *data_ptr = NULL;
    int i, level = 0;
    unsigned consumed = 0;
    unsigned length = 0;
    unsigned data_len = 0;
    unsigned primary_len = 0;
    pj_uint16_t block_seq = 0;
    pj_int16_t diff = 0;
    pj_uint8_t b = 0;
    unsigned total_red_len = 0;

    /* Parse headers */
    while (1) {
        if (consumed + 1 > buflen)
            return PJ_ETOOBIG;
        b = (pj_uint8_t) buf[consumed];
        if ((b & 0x7F) != (pj_uint8_t) pt)
            return PJMEDIA_EINVALIDPT;
        if ((b & 0x80) == 0) {
            consumed += 1;
            break;
        }
        if (consumed + 4 > buflen || level >= NUM_BUFFERS)
            return PJ_ETOOBIG;
        pj_memcpy(&hdr[level], &buf[consumed], 4);
        hdr[level] = pj_ntohl(hdr[level]);
        consumed += 4;
        level++;
    }

    for (i = 0; i < level; i++) {
        total_red_len += (hdr[i] & 0x3FF);
    }
    if (consumed + total_red_len > buflen) {
        return PJ_ETOOBIG;
    }

    /* Parse redundant history blocks */
    payload_ptr = buf + consumed;
    for (i = 0; i < level; i++) {
        length = (hdr[i] & 0x3FF);
        block_seq = (pj_uint16_t) (seq - (level - i));

        data_ptr = payload_ptr;
        data_len = length;

        if (length > 0) {
            /* Strip native BOM if it got trapped in history */
            if (data_len >= 3 && (pj_uint8_t) data_ptr[0] == 0xEF &&
                (pj_uint8_t) data_ptr[1] == 0xBB &&
                (pj_uint8_t) data_ptr[2] == 0xBF) {
                data_ptr += 3;
                data_len -= 3;
            }
        }

        /* Report sequences not covered by this RED packet as lost. */
        diff = (pj_int16_t) (block_seq - stream->rx_last_seq);
        if (stream->rx_last_seq != -1 && diff > 1) {
            pj_uint16_t missing_seq = stream->rx_last_seq + 1;
            while (missing_seq != block_seq) {
                pjmedia_jbuf_put_frame(stream->base.jb, "\xEF\xBF\xBD", 3,
                                       missing_seq);
                missing_seq++;
            }
        }

        /* Inject everything we missed, even length=0 frames! */
        if (stream->rx_last_seq != -1 && diff > 0) {
            pjmedia_jbuf_put_frame(stream->base.jb, data_ptr, data_len,
                                   block_seq);
            stream->rx_last_seq = block_seq; /* Update tracker */
        }

        if (length > 0) {
            payload_ptr += length;
            consumed += length;
        }
    }

    /* Parse primary block */
    primary_len = buflen - consumed;
    data_ptr = payload_ptr;
    data_len = primary_len;

    if (primary_len > 0) {
        /* Strip native BOM if present */
        if (data_len >= 3 && (pj_uint8_t) data_ptr[0] == 0xEF &&
            (pj_uint8_t) data_ptr[1] == 0xBB &&
            (pj_uint8_t) data_ptr[2] == 0xBF) {
            data_ptr += 3;
            data_len -= 3;
        }
    }

    /* Detect gaps for primary */
    diff = (pj_int16_t) (seq - stream->rx_last_seq);
    if (stream->rx_last_seq == -1 || diff > 0) {
        pjmedia_jbuf_put_frame(stream->base.jb, data_ptr, data_len,
                               (pj_uint16_t) seq);
        stream->rx_last_seq = (pj_uint16_t) seq;
    }

    consumed += primary_len;
    *red_len = consumed;
    return PJ_SUCCESS;
}

static pj_status_t on_stream_rx_rtp(pjmedia_stream_common *c_strm,
                                    const pjmedia_rtp_hdr *hdr,
                                    const void *payload, unsigned payloadlen,
                                    pjmedia_rtp_status seq_st,
                                    pj_bool_t *pkt_discarded)
{
    pjmedia_txt_stream *stream = (pjmedia_txt_stream *) c_strm;
    unsigned consumed = 0;
    pj_uint16_t seq = pj_ntohs(hdr->seq);
    pj_int16_t diff = 0;
    pj_status_t status = PJ_SUCCESS;

    /* Initialize to prevent uninitialized memory reads on success paths */
    *pkt_discarded = PJ_FALSE;

    pj_mutex_lock(c_strm->jb_mutex);
    if (seq_st.status.flag.restart) {
        stream->rx_last_seq = -1;
        pjmedia_jbuf_reset(c_strm->jb);
    }

    if (hdr->pt == c_strm->si->rx_red_pt) {
        status = decode_red(stream, c_strm->si->rx_pt, seq,
                            (const char *) payload, payloadlen, &consumed);

        /* Mark packet as discarded if RED decoding fails */
        if (status != PJ_SUCCESS) {
            *pkt_discarded = PJ_TRUE;
        }

    } else if (hdr->pt == c_strm->si->rx_pt) {
        /* Fallback: Route T.140 directly to Jitter Buffer */
        diff = (pj_int16_t) (seq - stream->rx_last_seq);

        /* Report missing T.140 packets as lost text. */
        if (stream->rx_last_seq != -1 && diff > 1) {
            pj_uint16_t missing_seq = stream->rx_last_seq + 1;
            while (missing_seq != seq) {
                pjmedia_jbuf_put_frame(c_strm->jb, "\xEF\xBF\xBD", 3,
                                       missing_seq);
                missing_seq++;
            }
        }

        if (stream->rx_last_seq == -1 || diff > 0) {
            pjmedia_jbuf_put_frame(c_strm->jb, payload, payloadlen, seq);
            stream->rx_last_seq = seq;
        } else {
            *pkt_discarded = PJ_TRUE;
        }
    } else {
        /* Unknown Payload Type */
        status = PJMEDIA_EINVALIDPT;
        *pkt_discarded = PJ_TRUE;
    }

    /* Unlock mutex before calling the UI callback to prevent deadlocks */
    pj_mutex_unlock(c_strm->jb_mutex);

    /* Trigger the UI callback if we got a packet */
    if (!(*pkt_discarded))
        call_cb(stream, PJ_FALSE);

    return status;
}

static pj_status_t encode_red(pjmedia_txt_stream *stream, unsigned pt,
                              char *buf, int *size,
                              pj_bool_t force_empty_history)
{
    int i;
    unsigned len = 0;
    unsigned hist_len = 0;
    pj_uint8_t *p_hdr = (pj_uint8_t *) buf;
    pj_uint8_t *p_data = NULL;
    pj_uint32_t offset = 0;
    pj_uint32_t off = 0;

    unsigned level = stream->si.tx_red_level;
    if (level >= NUM_BUFFERS)
        level = NUM_BUFFERS - 1;

    /* Write redundant headers */
    for (i = level; i > 0; i--) {
        offset = 0;
        hist_len = 0;

        /* Enforce empty history if requested */
        if (!force_empty_history) {
            offset = stream->tx_buf[0].timestamp - stream->tx_buf[i].timestamp;
            if (offset > 16383) {
                offset = 0;
                hist_len = 0;
            } else {
                hist_len = stream->tx_buf[i].length;
            }
        }

        if (len + 4 > (unsigned) *size)
            return PJ_ETOOBIG;

        *p_hdr++ = (pj_uint8_t) (0x80 | (pt & 0x7F));
        *p_hdr++ = (pj_uint8_t) ((offset >> 6) & 0xFF);
        *p_hdr++ =
            (pj_uint8_t) (((offset << 2) & 0xFC) | ((hist_len >> 8) & 0x03));
        *p_hdr++ = (pj_uint8_t) (hist_len & 0xFF);
        len += 4;
    }

    /* Primary header */
    if (len + 1 > (unsigned) *size)
        return PJ_ETOOBIG;
    *p_hdr++ = (pj_uint8_t) (pt & 0x7F);
    len += 1;

    /* Payloads */
    p_data = p_hdr;
    for (i = level; i >= 0; i--) {
        unsigned payload_len =
            (force_empty_history && i > 0) ? 0 : stream->tx_buf[i].length;

        if (payload_len == 0)
            continue;

        if (!force_empty_history && i > 0) {
            off = stream->tx_buf[0].timestamp - stream->tx_buf[i].timestamp;
            if (off > 16383)
                continue;
        }

        if (len + payload_len > (unsigned) *size)
            return PJ_ETOOBIG;

        pj_memcpy(p_data, stream->tx_buf[i].buf, payload_len);
        p_data += payload_len;
        len += payload_len;
    }

    *size = len;
    return PJ_SUCCESS;
}

static pj_status_t send_text_locked(pjmedia_txt_stream *stream,
                                    unsigned rtp_ts_len)
{
    /* C90 compliant: All declarations must be at the top */
    pjmedia_stream_common *c_strm = &stream->base;
    pjmedia_channel *channel = c_strm->enc;
    pj_status_t status = PJ_SUCCESS;
    pj_bool_t is_keepalive = PJ_FALSE;
    pj_timestamp now;
    pj_bool_t is_first_packet;
    pj_bool_t use_red;
    pj_bool_t has_deferred_char = PJ_FALSE;

    void *rtphdr;
    char deferred_char_buf[PJMEDIA_MAX_MTU];
    int deferred_char_len = 0;
    int size, i;
    int pass = 0;
    int max_pass = 1;
    unsigned pt_to_use;

    pj_get_timestamp(&now);

    is_first_packet =
        (stream->tx_last_ts.u32.hi == 0 && stream->tx_last_ts.u32.lo == 0);
    use_red = (stream->si.tx_red_pt > 0) ? PJ_TRUE : PJ_FALSE;
    pt_to_use = use_red ? stream->si.tx_red_pt : channel->pt;

    /* RTP timestamp calculation */
    if (is_first_packet) {
        rtp_ts_len = 20;
    } else if (rtp_ts_len == 0) {
        rtp_ts_len = pj_elapsed_msec(&stream->tx_last_ts, &now);
        if (rtp_ts_len == 0)
            rtp_ts_len = 1;
    }

    /* Keep-alive check */
    if (stream->is_idle && stream->tx_buf[0].length == 0) {
        if (!is_first_packet &&
            pj_elapsed_msec(&stream->tx_last_ts, &now) >= 10000) {
            is_keepalive = PJ_TRUE;
        } else {
            return PJ_SUCCESS; /* Clean return */
        }
    }

    /* BOM logic */
    if (stream->tx_buf[0].length >= 3 &&
        (pj_uint8_t) stream->tx_buf[0].buf[0] == 0xEF &&
        (pj_uint8_t) stream->tx_buf[0].buf[1] == 0xBB &&
        (pj_uint8_t) stream->tx_buf[0].buf[2] == 0xBF) {
        stream->tx_buf[0].length -= 3;
        pj_memmove(stream->tx_buf[0].buf, stream->tx_buf[0].buf + 3,
                   stream->tx_buf[0].length);
    }

    if (is_first_packet && stream->tx_buf[0].length > 0) {
        deferred_char_len = stream->tx_buf[0].length;
        pj_memcpy(deferred_char_buf, stream->tx_buf[0].buf, deferred_char_len);

        stream->tx_buf[0].buf[0] = (char) 0xEF;
        stream->tx_buf[0].buf[1] = (char) 0xBB;
        stream->tx_buf[0].buf[2] = (char) 0xBF;
        stream->tx_buf[0].length = 3;
        has_deferred_char = PJ_TRUE;
        max_pass = 2; /* Need a second pass for the user data */
    }

    /* Loop for passes (1: BOM, 2: User Data) */
    while (pass < max_pass) {
        /* Check if we have data to send */
        if (stream->tx_buf[0].length == 0 && !is_keepalive &&
            (!use_red || stream->tx_nred == 0)) {
            status = PJ_SUCCESS;
            break;
        }

        /* Encode RTP */
        status = pjmedia_rtp_encode_rtp(&channel->rtp, pt_to_use, 0,
                                        (int) channel->buf_size, rtp_ts_len,
                                        (const void **) &rtphdr, &size);
        if (status != PJ_SUCCESS)
            break;

        pj_memcpy(channel->buf, rtphdr, sizeof(pjmedia_rtp_hdr));
        stream->tx_buf[0].timestamp =
            pj_ntohl(((pjmedia_rtp_hdr *) rtphdr)->ts);

        if (stream->is_idle && !is_keepalive) {
            stream->is_idle = PJ_FALSE;
            ((pjmedia_rtp_hdr *) channel->buf)->m = 1;
        }

        /* Redundancy and Copy */
        if (use_red) {
            size = (int) channel->buf_size - sizeof(pjmedia_rtp_hdr);
            status =
                encode_red(stream, (unsigned) stream->si.tx_pt,
                           ((char *) channel->buf) + sizeof(pjmedia_rtp_hdr),
                           &size, PJ_FALSE);
            if (status != PJ_SUCCESS)
                break;
        } else {
            if (stream->tx_buf[0].length > 0) {
                size = stream->tx_buf[0].length;
                pj_memcpy(((char *) channel->buf) + sizeof(pjmedia_rtp_hdr),
                          stream->tx_buf[0].buf, size);
            } else {
                size = 0;
            }
        }

        /* Shift Buffer */
        if (stream->tx_buf[0].length > 0) {
            if (use_red)
                stream->tx_nred = stream->si.tx_red_level;
            else {
                stream->tx_nred = 0;
                stream->is_idle = PJ_TRUE;
            }
            for (i = NUM_BUFFERS - 1; i > 0; i--)
                stream->tx_buf[i] = stream->tx_buf[i - 1];
            stream->tx_buf[0].length = 0;
        } else if (use_red && stream->tx_nred > 0) {
            stream->tx_nred--;
            if (stream->tx_nred == 0)
                stream->is_idle = PJ_TRUE;
            for (i = NUM_BUFFERS - 1; i > 0; i--)
                stream->tx_buf[i] = stream->tx_buf[i - 1];
            stream->tx_buf[0].length = 0;
        } else if (is_keepalive) {
            stream->is_idle = PJ_TRUE;
        }

        /* Network Transmission */
        {
            char tx_pkt[PJMEDIA_MAX_MTU];
            int tx_size = size + sizeof(pjmedia_rtp_hdr);
            pj_memcpy(tx_pkt, channel->buf, tx_size);

            stream->tx_last_ts = now;
            pj_mutex_unlock(c_strm->jb_mutex);
            status =
                pjmedia_transport_send_rtp(c_strm->transport, tx_pkt, tx_size);
            pj_mutex_lock(c_strm->jb_mutex);
        }

        /* Prepare second pass if needed */
        pass++;
        if (pass == 1 && has_deferred_char) {
            stream->tx_buf[0].length = deferred_char_len;
            pj_memcpy(stream->tx_buf[0].buf, deferred_char_buf,
                      deferred_char_len);
            rtp_ts_len = 10;
        }
    }

    return status;
}

static pj_status_t send_text(pjmedia_txt_stream *stream, unsigned rtp_ts_len)
{
    pjmedia_stream_common *c_strm = &stream->base;
    pj_status_t status;

    pj_mutex_lock(c_strm->jb_mutex);
    status = send_text_locked(stream, rtp_ts_len);
    pj_mutex_unlock(c_strm->jb_mutex);

    return status;
}

/**
 * check_tx_rtcp()
 * This function is for transmitting periodic RTCP SR/RR report.
 */
static void check_tx_rtcp(pjmedia_txt_stream *stream)
{
    pjmedia_stream_common *c_strm = &stream->base;
    pj_timestamp now;
    pj_status_t status;

    pj_get_timestamp(&now);
    if (stream->rtcp_last_tx.u64 == 0) {
        stream->rtcp_last_tx = now;
    } else if (pj_elapsed_msec(&stream->rtcp_last_tx, &now) >=
               c_strm->rtcp_interval) {
        status = send_rtcp(c_strm, !c_strm->rtcp_sdes_bye_disabled, PJ_FALSE,
                           PJ_FALSE, PJ_FALSE, PJ_FALSE, PJ_FALSE);
        if (status == PJ_SUCCESS) {
            stream->rtcp_last_tx = now;
        }
    }
}

/*
 * check_start_ka()
 * Punch NAT holes at stream start by sending a few empty RTP packets (plus
 * RTCP) spaced start_ka_msec apart, so the bindings exist before any
 * text is typed and survive a lost packet. Kept out of send_text_locked()
 * so it doesn't disturb the first-packet (BOM) logic there.
 */
static void check_start_ka(pjmedia_txt_stream *stream)
{
    pjmedia_stream_common *c_strm = &stream->base;
    pjmedia_channel *channel = c_strm->enc;
    pjmedia_rtp_hdr hdr;
    const void *rtphdr;
    int hdrlen;
    pj_timestamp now;
    pj_status_t status;

    if (stream->start_ka_left == 0)
        return;

    pj_get_timestamp(&now);
    if (stream->start_ka_last_tx.u64 != 0 &&
        pj_elapsed_msec(&stream->start_ka_last_tx, &now) <
            stream->start_ka_msec)
    {
        return;
    }
    stream->start_ka_last_tx = now;

    /* The RTP session is shared with send_text_locked(). */
    pj_mutex_lock(c_strm->jb_mutex);
    status = pjmedia_rtp_encode_rtp(&channel->rtp, channel->pt, 0, 1, 0,
                                    &rtphdr, &hdrlen);
    if (status == PJ_SUCCESS)
        pj_memcpy(&hdr, rtphdr, sizeof(hdr));
    pj_mutex_unlock(c_strm->jb_mutex);
    if (status != PJ_SUCCESS)
        return;

    TRC_((c_strm->port.info.name.ptr, "Sending start keep-alive"));

    /* On failure (e.g. SRTP keys not ready yet), retry at next interval. */
    status = pjmedia_transport_send_rtp(c_strm->transport, &hdr, sizeof(hdr));
    if (status != PJ_SUCCESS)
        return;

    status = send_rtcp(c_strm, !c_strm->rtcp_sdes_bye_disabled, PJ_FALSE,
                       PJ_FALSE, PJ_FALSE, PJ_FALSE, PJ_FALSE);
    if (status != PJ_SUCCESS) {
        PJ_PERROR(4, (c_strm->port.info.name.ptr, status,
                      "Error sending start keep-alive RTCP"));
    }

    stream->start_ka_left--;
}

/* Clock callback */
static void clock_cb(const pj_timestamp *ts, void *user_data)
{
    pjmedia_txt_stream *stream = (pjmedia_txt_stream *) user_data;
    pj_timestamp now;
    unsigned interval;

    PJ_UNUSED_ARG(ts);

    pj_get_timestamp(&now);
    interval = pj_elapsed_msec(&stream->tx_last_ts, &now);
    /* If the interval is at least the buffering time, or
     * if the next clock callback occurs past the maximum buffering
     * time, send the text now.
     */
    if (interval >= stream->buf_time ||
        interval + stream->buf_time > MAX_BUFFERING_TIME) {
        send_text(stream, interval);
    }

    /* Check if now is the time to transmit RTCP SR/RR report. */
    check_tx_rtcp(stream);

    check_start_ka(stream);
}

PJ_DEF(pj_status_t)
pjmedia_txt_stream_send_text(pjmedia_txt_stream *stream, const pj_str_t *text)
{
    pjmedia_stream_common *c_strm = &stream->base;
    pj_timestamp now;
    unsigned interval;
    pj_status_t status = PJ_SUCCESS;

    PJ_ASSERT_RETURN(stream, PJ_EINVAL);

    pj_mutex_lock(c_strm->jb_mutex);

    if (stream->tx_buf[0].length + text->slen > BUFFER_SIZE) {
        pj_mutex_unlock(c_strm->jb_mutex);
        return PJ_ETOOMANY;
    }

    pj_memcpy(stream->tx_buf[0].buf + stream->tx_buf[0].length, text->ptr,
              text->slen);
    stream->tx_buf[0].length += (unsigned) text->slen;

    /* Decide if we should send the text immediately or just buffer it. */
    pj_get_timestamp(&now);
    interval = pj_elapsed_msec(&stream->tx_last_ts, &now);
    if (interval >= stream->buf_time) {
        status = send_text_locked(stream, interval);
    }

    pj_mutex_unlock(c_strm->jb_mutex);

    return status;
}

PJ_DEF(pj_status_t)
pjmedia_txt_stream_set_rx_callback(
    pjmedia_txt_stream *stream,
    void (*cb)(pjmedia_txt_stream *, void *user_data,
               const pjmedia_txt_stream_data *data),
    void *user_data, unsigned option)
{
    pjmedia_stream_common *c_strm = (pjmedia_stream_common *) stream;

    PJ_ASSERT_RETURN(stream, PJ_EINVAL);

    PJ_UNUSED_ARG(option);

    pj_mutex_lock(c_strm->jb_mutex);

    stream->cb = cb;
    stream->cb_user_data = user_data;

    pj_mutex_unlock(c_strm->jb_mutex);

    return PJ_SUCCESS;
}

/**
 * Internal function for collecting codec info from the SDP media.
 */
static pj_status_t get_codec_info(pjmedia_txt_stream_info *si, pj_pool_t *pool,
                                  const pjmedia_sdp_media *local_m,
                                  const pjmedia_sdp_media *rem_m)
{
    static const pj_str_t ID_RTPMAP = {"rtpmap", 6};
    static const pj_str_t ID_REDUNDANCY = {"red", 3};
    static const pj_str_t ID_RED_PARAM = {"redundancy", 10};
    const pjmedia_sdp_attr *attr;
    unsigned i, fmti, r;
    unsigned rem_red_pt = 0;
    unsigned rem_t140_pt = 0;
    unsigned pt = 0;
    pjmedia_sdp_rtpmap rtpmap;
    
    /* Parse Remote PTs */
    for (i = 0; i < rem_m->desc.fmt_count; ++i) {
        pt = (unsigned) pj_strtoul(&rem_m->desc.fmt[i]);
        attr =
            pjmedia_sdp_media_find_attr(rem_m, &ID_RTPMAP, &rem_m->desc.fmt[i]);
        if (attr && pjmedia_sdp_attr_get_rtpmap(attr, &rtpmap) == PJ_SUCCESS) {
            if (pj_stricmp(&rtpmap.enc_name, &ID_REDUNDANCY) == 0) {
                rem_red_pt = pt;
            } else {
                rem_t140_pt = pt;
            }
        }
    }
    
    si->tx_pt = (pj_uint8_t) rem_t140_pt;

    /* Parse Local PTs */
    for (fmti = 0; fmti < local_m->desc.fmt_count; ++fmti) {
        pt = (unsigned) pj_strtoul(&local_m->desc.fmt[fmti]);
        attr = pjmedia_sdp_media_find_attr(local_m, &ID_RTPMAP,
                                           &local_m->desc.fmt[fmti]);
        if (attr && pjmedia_sdp_attr_get_rtpmap(attr, &rtpmap) == PJ_SUCCESS) {
            if (pj_stricmp(&rtpmap.enc_name, &ID_REDUNDANCY) == 0) {
                si->rx_red_pt = (pj_uint8_t) pt;
            } else {
                si->rx_pt = (pj_uint8_t) pt;
            }
        }
    }

    /* Parse Redundancy Level using a temporary struct */
    if (rem_red_pt > 0) {
        pjmedia_codec_fmtp red_fmtp;
        pj_bzero(&red_fmtp, sizeof(red_fmtp));

        if (pjmedia_stream_info_parse_fmtp(pool, rem_m, rem_red_pt,
                                           &red_fmtp) == PJ_SUCCESS) {
            si->tx_red_level = 0;
            for (i = 0; i < red_fmtp.cnt; ++i) {
                const char *p;
                /* Accept either a non-standard named parameter (redundancy=)
                 * or the standard RFC 2198 slash-separated PT list.
                 */
                if (red_fmtp.param[i].name.slen != 0 &&
                    pj_strcmp(&red_fmtp.param[i].name, &ID_RED_PARAM) != 0) {
                    continue;
                }

                p = red_fmtp.param[i].val.ptr;
                for (r = 0; r < red_fmtp.param[i].val.slen; ++r) {
                    if (p[r] == '/')
                        si->tx_red_level++;
                }

                /* If fmtp was tokenized into multiple params */
                if (si->tx_red_level == 0 && red_fmtp.cnt > 1)
                    si->tx_red_level = (int) red_fmtp.cnt - 1;
                break;
            }
        }
    }
    /* Only activate red when we DO have redundancy */
    if (si->tx_red_level > 0) 
        si->tx_red_pt = (pj_uint8_t) rem_red_pt;

    /* Populate enc_fmtp/dec_fmtp with the BASE T.140 codec parameters */
    if (si->tx_pt > 0) {
        pjmedia_stream_info_parse_fmtp(pool, rem_m, si->tx_pt, &si->enc_fmtp);
    }
    if (si->rx_pt > 0) {
        pjmedia_stream_info_parse_fmtp(pool, local_m, si->rx_pt, &si->dec_fmtp);
    }

    /* Set fmt */
    si->fmt.type = PJMEDIA_TYPE_TEXT;
    si->fmt.pt = si->rx_pt;
    pj_strset2(&si->fmt.encoding_name, "t140");
    /*RFC 4103 recommends a clock frequency of 1000 Hz */
    si->fmt.clock_rate = 1000;
    /* RFC 4103 defines the payload as a single, sequential stream of text */
    si->fmt.channel_cnt = 1;

    return (si->tx_pt < 96 || si->rx_pt < 96) ? PJMEDIA_EINVALIDPT : PJ_SUCCESS;
}

/**
 * Create stream info from SDP media line.
 */
PJ_DEF(pj_status_t)
pjmedia_txt_stream_info_from_sdp(pjmedia_txt_stream_info *si, pj_pool_t *pool,
                                 pjmedia_endpt *endpt,
                                 const pjmedia_sdp_session *local,
                                 const pjmedia_sdp_session *remote,
                                 unsigned stream_idx)
{
    pjmedia_stream_info_common *csi = (pjmedia_stream_info_common *) si;
    const pjmedia_sdp_media *local_m;
    const pjmedia_sdp_media *rem_m;
    pj_bool_t active;
    pj_status_t status;

    PJ_ASSERT_RETURN(si, PJ_EINVAL);

    pj_bzero(si, sizeof(*si));
    status = pjmedia_stream_info_common_from_sdp(csi, pool, endpt, local,
                                                 remote, stream_idx, &active);
    if (status != PJ_SUCCESS || !active)
        return status;

    /* Keep SDP shortcuts */
    local_m = local->media[stream_idx];
    rem_m = remote->media[stream_idx];

    /* Media type must be text */
    if (pjmedia_get_type(&local_m->desc.media) != PJMEDIA_TYPE_TEXT)
        return PJMEDIA_EINVALIMEDIATYPE;

    /* Get codec info */
    status = get_codec_info(si, pool, local_m, rem_m);

    /* Get redundancy info */
    pjmedia_stream_info_common_parse_redundancy(csi, pool, local_m, rem_m);

    return status;
}
